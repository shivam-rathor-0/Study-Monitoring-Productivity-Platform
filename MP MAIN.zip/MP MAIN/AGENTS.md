# AGENTS.md

Local-first vanilla JS study app (FocusFlow). Static, no-build. There is no package.json, bundler,
test runner, linter or typechecker. To verify a change, open index.html through Live Server
(camera needs localhost) and exercise the UI. Do not add tooling or npm dependencies unless asked.

## Load order is load-bearing
- index.html loads classic (non-module) scripts that share globals. Order matters.
- Current order: core, audio, music, guard, tracker, tasks, quiz, quizdata, quizdata-biology,
  quizdata-english, quizdata-cs, quizdata-history, quizdata-geography, quizdata-economics,
  runners, code, rooms, profile, dashboard, tips, demo, app.
- music.js MUST load right after audio.js: both read window.Music / Sound.syncUI at runtime.
- app.js MUST stay last (boots on DOMContentLoaded).
- tips.js MUST load after dashboard.js and before app.js (it monkey-patches Dashboard.refresh).
- quizdata.js MUST load after quiz.js (it calls Quiz.addBank). code.js loads after quiz.js.
- runners.js exists (window.Runners) and loads before code.js. There is no export.js unless added later.
- Keep new files as classic scripts, never type="module".

## Modules
Each module is an IIFE exposed on window: App, Tracker, Guard, Sound, Music, Tasks, Rooms,
Dashboard, Profile, Tips, Quiz, Code, Export, Demo. No new globals except the module name.
Music also assigns window.Music explicitly because audio.js and app.js feature-detect it.
Music API: init(), onShow(), stop(), isPlaying(), nowTitle().

Demo.load() backs up real data to ff_demobackup, Demo.restore() puts it back.

Code practice runs through language adapters in js/runners.js (window.Runners). JavaScript and Python (Pyodide) run in a Web Worker. C, C++ and Java use an OPTIONAL online runner that is OFF by default and needs explicit user consent each session, because code leaves the device. Timeouts: JavaScript 2s, Python 5s, online runner 10s.

core.js helpers: $, $$, el(), escapeHTML(), fmtDur/fmtClock/fmtAgo, dateKey(), hueFor(),
Store (localStorage, keys prefixed "ff_"), toast(), State, applyTheme(), SUBJECTS, PALETTE.

## Architecture
- Views are <section id="view-<route>">. Navigation uses data-route attributes and hash routing
  (#/route, #/rooms/<code>, #/join/<code>). Valid routes are fixed in app.js ROUTES.
  Current routes: home, focus, tasks, practice, rooms, sounds.
- The Practice view has sub-tabs (Quiz | Code) inside #view-practice. Do not add more top-level
  nav items without asking.
- The Sounds route is branded "Tape Deck" (route stays #/sounds). It has two sub-tabs: Sounds
  (synthesized noise / instrumental / nature channels) and Music (stations + My Files).
  The tape player bar and the hidden #yt-dock are static markup, not rebuilt per render.
- Minimal mode (`body.focus-zen`) strips a live session down to the timer ring, Pause/Finish and a
  top-right exit control: chrome, background art, Guard panel, rail, stats and session log hide.
  Always keep a visible way out whenever that class is on.
- CSS: css/base.css (tokens, reset, chrome, themes) and css/views.css (per-view styles).
- Themes are [data-theme="..."] blocks that override the same CSS variables. Never hardcode a
  color in JS or CSS if a variable exists. Check every view in all themes after a theme change.
- Storage keys (always via Store, never raw localStorage): user, sessions, tasks, settings, rooms,
  stats, theme, volume, chanvol, distractions, distractCats, quizzes, codesolved, customSubjects,
  practiceTab, musicvol, musicShuffle, musicRepeat, ytConsent, bgart (legacy bgvideo is read as a
  fallback).
- Tape Deck local tracks live in IndexedDB database ff_tape_v1, store tracks (id, name, blob, dur,
  size, type, added) — not in localStorage, and never uploaded.
- Static media lives in assets/ as optimized still images (WebP), real royalty-free footage only. Every background must have a CSS gradient fallback. The six themed backgrounds are stills; do not reintroduce autoplaying background videos.

## Coding rules
- Use 'use strict'. Every Store.get has a fallback.
- All user text goes through escapeHTML().
- Reuse existing CSS variables and class names (.card, .pad, .btn, .chip, .segmented, .modal-overlay).
- Store.get returns the fallback on null or type mismatch; room codes must match safeCode; hues must go through safeColor.
- User-written code (Code practice) runs ONLY inside a Web Worker created from a Blob with a
  2 second timeout. Never eval or new Function on the main page.
- New quiz subjects go in separate files js/quizdata-<subject>.js, loaded after quiz.js.

## Runtime constraints
- AI Focus Guard (guard.js) uses MediaPipe FaceMesh from jsDelivr and getUserMedia. It must fail
  gracefully offline or without camera permission. That is not a bug. FaceMesh is lazy-loaded only
  while the Guard is on, and the phone detector (COCO-SSD) is optional and delayed.
- Guard shows one signal: green (focused) or red (looking away, eyes closed, away, phone).
  Head-down reading counts as focus. Do not flag it as a distraction.
- Posture tracking and the 20-20-20 eye-break modal were removed in v2. Do not add them back
  without asking.
- Study rooms are a demo: peers are simulated locally, no backend.
- Tape Deck sounds are generated live with Web Audio. No audio assets.
- Tape Deck music uses the official YouTube IFrame API only (no audio extraction, no scraping).
  Streaming is off until the user accepts the consent modal (ytConsent = 'yes') and can be turned
  off again from the Music tab. Only hand-verified video ids ship; on YouTube error 100/101/150 the
  player marks the track dead, toasts, and skips. Never ship unverified ids — old Bollywood uploads
  die often. The #yt-dock iframe must never be reparented (moving an iframe reloads it and cuts
  playback); it stays at body level, fixed off-screen.
- YouTube playback needs a real user gesture: after every play request music.js re-issues
  playVideo() a few times in the first ~1.6s while the clock has not moved. If nothing has played
  after ~4.5s it marks the bar "Did not start — tap play" and shows the video player (same iframe,
  only CSS position changes) so one tap on YouTube's own button starts it. Do not remove these
  retries/fallback — browsers refuse scripted autoplay in cross-origin iframes, and headless
  Chrome hides that (it ignores autoplay policy, so "it plays in headless" proves nothing).
- YouTube embeds refuse to work from file:// (no origin). music.js detects that, shows a Live
  Server notice in the Music tab and refuses to pretend to stream.
- Reduced motion: decorative animations and transitions are disabled. The background is a still
  image controlled by the Background art chip, so it needs no motion exception.

## Guardrails
- Camera is opt-in only, with an off switch. Nothing leaves the device.
- Object detection runs only while AI Focus Guard is on; video frames never leave the device, only the model files are downloaded from a CDN on first use.
- Nothing leaves the device unless the user explicitly enables the online code runner or the
  Tape Deck YouTube streaming (opt-in, revocable, explained in the consent modal). Animations must
  never block input and must be disabled by prefers-reduced-motion.
- No ads of our own, minimal notifications. YouTube itself may show ads inside its own player;
  that is why streaming is opt-in and labelled.
- XP and badges must never outrank study time. Quiz and Code practice do not give XP in v1.
- Keep the UI uncluttered: prefer popovers, sub-tabs and collapsible sections over new buttons.

## Working rules
- Make small focused edits only. Never rewrite a working file.
- One feature per task.
- After each task, tell me exactly how to test it in the browser.
