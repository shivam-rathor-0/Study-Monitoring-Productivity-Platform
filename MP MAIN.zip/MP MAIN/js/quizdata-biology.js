'use strict';

Quiz.addBank([
  {
    q: 'Which organelle is the primary site of ATP production in eukaryotic cells?',
    options: ['Ribosome', 'Mitochondrion', 'Golgi apparatus', 'Lysosome'],
    answer: 1,
    subject: 'Biology',
    explain: 'Mitochondria carry out oxidative phosphorylation and produce most of the ATP used by the cell.'
  },
  {
    q: 'Which structure controls the movement of substances into and out of a cell?',
    options: ['Cell membrane', 'Cell wall', 'Nucleus', 'Cytoplasm'],
    answer: 0,
    subject: 'Biology',
    explain: 'The selectively permeable cell membrane regulates what enters and leaves the cell.'
  },
  {
    q: 'In which organelle does photosynthesis take place?',
    options: ['Mitochondrion', 'Ribosome', 'Chloroplast', 'Nucleus'],
    answer: 2,
    subject: 'Biology',
    explain: 'Chloroplasts contain chlorophyll and are the site of photosynthesis.'
  },
  {
    q: 'Which organelle is continuous with the nuclear envelope and has ribosomes attached to its surface?',
    options: ['Smooth endoplasmic reticulum', 'Golgi apparatus', 'Lysosome', 'Rough endoplasmic reticulum'],
    answer: 3,
    subject: 'Biology',
    explain: 'The rough endoplasmic reticulum is studded with ribosomes and connected to the nuclear envelope.'
  },
  {
    q: 'Which molecule carries genetic information from DNA to the ribosome?',
    options: ['tRNA', 'mRNA', 'rRNA', 'DNA polymerase'],
    answer: 1,
    subject: 'Biology',
    explain: 'Messenger RNA (mRNA) carries the genetic message from DNA to the ribosome.'
  },
  {
    q: 'In a cross between two heterozygous pea plants (Tt × Tt), what is the expected phenotypic ratio for the dominant trait?',
    options: ['1:1', '1:2:1', '3:1', '9:3:3:1'],
    answer: 2,
    subject: 'Biology',
    explain: 'The genotypes are 1 TT : 2 Tt : 1 tt, so the dominant phenotype appears in 3 out of 4 offspring.'
  },
  {
    q: 'How many chromosomes are there in a normal human body cell?',
    options: ['46', '23', '22', '92'],
    answer: 0,
    subject: 'Biology',
    explain: 'Human body cells are diploid and contain 23 pairs, or 46 chromosomes.'
  },
  {
    q: 'Which of these is a sex-linked trait in humans?',
    options: ['ABO blood group', 'Huntington disease', 'Sickle-cell anaemia', 'Red-green colour blindness'],
    answer: 3,
    subject: 'Biology',
    explain: 'Red-green colour blindness is caused by a recessive allele on the X chromosome.'
  },
  {
    q: 'Which organ produces insulin?',
    options: ['Liver', 'Kidney', 'Stomach', 'Pancreas'],
    answer: 3,
    subject: 'Biology',
    explain: 'Insulin is produced by the beta cells of the pancreas.'
  },
  {
    q: 'Which part of the brain controls balance and coordination?',
    options: ['Cerebellum', 'Cerebrum', 'Medulla oblongata', 'Hypothalamus'],
    answer: 0,
    subject: 'Biology',
    explain: 'The cerebellum coordinates voluntary movements, balance, and posture.'
  },
  {
    q: 'Which chamber of the heart pumps oxygenated blood to the body?',
    options: ['Right atrium', 'Right ventricle', 'Left atrium', 'Left ventricle'],
    answer: 3,
    subject: 'Biology',
    explain: 'The left ventricle pumps oxygenated blood into the aorta and around the body.'
  },
  {
    q: 'Which tissue transports water and minerals from the roots to the leaves?',
    options: ['Phloem', 'Xylem', 'Cambium', 'Epidermis'],
    answer: 1,
    subject: 'Biology',
    explain: 'Xylem vessels carry water and dissolved minerals upward from the roots.'
  },
  {
    q: 'What is the main function of stomata in leaves?',
    options: ['Water absorption', 'Food storage', 'Gas exchange', 'Support'],
    answer: 2,
    subject: 'Biology',
    explain: 'Stomata are pores that allow carbon dioxide, oxygen, and water vapour to move in and out of the leaf.'
  },
  {
    q: 'Which process converts light energy into chemical energy in plants?',
    options: ['Photosynthesis', 'Respiration', 'Transpiration', 'Translocation'],
    answer: 0,
    subject: 'Biology',
    explain: 'Photosynthesis uses light energy to make glucose from carbon dioxide and water.'
  },
  {
    q: 'Which of the following is a producer in an ecosystem?',
    options: ['Grasshopper', 'Frog', 'Snake', 'Grass'],
    answer: 3,
    subject: 'Biology',
    explain: 'Grass is a photosynthetic organism, so it produces its own food and is a producer.'
  },
  {
    q: 'Which organisms break down dead organic matter and recycle nutrients?',
    options: ['Producers', 'Decomposers', 'Primary consumers', 'Predators'],
    answer: 1,
    subject: 'Biology',
    explain: 'Decomposers such as bacteria and fungi break down dead matter and release nutrients.'
  },
  {
    q: 'Approximately what percentage of energy is transferred from one trophic level to the next in a food chain?',
    options: ['1%', '50%', '10%', '90%'],
    answer: 2,
    subject: 'Biology',
    explain: 'The 10% law estimates that only about 10% of energy passes to the next trophic level.'
  },
  {
    q: 'Which scientist is best known for proposing the theory of natural selection?',
    options: ['Charles Darwin', 'Gregor Mendel', 'Louis Pasteur', 'Robert Hooke'],
    answer: 0,
    subject: 'Biology',
    explain: 'Charles Darwin proposed natural selection in his book On the Origin of Species.'
  },
  {
    q: 'The forelimbs of humans, whales, and bats have a similar bone structure. What kind of structures are these?',
    options: ['Analogous structures', 'Vestigial structures', 'Homologous structures', 'Identical structures'],
    answer: 2,
    subject: 'Biology',
    explain: 'Homologous structures share a common evolutionary origin even when their functions differ.'
  },
  {
    q: 'What is a vestigial structure?',
    options: ['A newly evolved organ', 'A structure with no apparent function', 'A structure found only in embryos', 'A structure used for camouflage'],
    answer: 1,
    subject: 'Biology',
    explain: 'Vestigial structures are reduced or functionless remnants of organs that had a role in ancestors.'
  }
]);
