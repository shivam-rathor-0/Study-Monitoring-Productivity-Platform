'use strict';

const Runners = (function(){

  const PYODIDE_VERSION = 'v0.26.4';
  const PYODIDE_BASE = 'https://cdn.jsdelivr.net/pyodide/' + PYODIDE_VERSION + '/full/';
  const JS_TIMEOUT = 2000;
  const PY_TIMEOUT = 5000;
  const ONLINE_TIMEOUT = 10000;

  let jsRun = null;
  let onlineRun = null;
  let pyWorker = null;
  let pyUrl = '';
  let pyReady = null;
  let pyReadyResolve = null;
  let pyReadyReject = null;
  let pyLoaded = false;
  let pyRun = null;

  function errorText(err){
    return err && err.message ? String(err.message) : String(err || 'Unknown error');
  }

  function cancelledError(){
    const err = new Error('Run cancelled');
    err.cancelled = true;
    return err;
  }

  function timeoutError(ms){
    const err = new Error('Time limit exceeded');
    err.timeout = true;
    err.ms = ms;
    return err;
  }

  function normalizeValue(value, mode){
    if(mode === 'sort' && Array.isArray(value)) return value.slice().sort((a, b) => a - b);
    return value;
  }

  function sameJSON(a, b){
    try{ return JSON.stringify(a) === JSON.stringify(b); }catch(e){ return false; }
  }

  function workerScript(problem, code){
    const tests = problem.tests.map(t => ({
      name: t.name,
      args: t.args,
      expected: t.expected,
      normalize: t.normalize || null
    }));
    const fn = problem.fn;

    return "'use strict';\n" +
      'const __tests = ' + JSON.stringify(tests) + ';\n' +
      'function __norm(v, mode){ if(mode === "sort" && Array.isArray(v)) return v.slice().sort(function(a, b){ return a - b; }); return v; }\n' +
      'function __safe(v){ try{ if(typeof v === "undefined") return "undefined"; return JSON.parse(JSON.stringify(v)); }catch(e){ return String(v); } }\n' +
      'function __same(a, b){ try{ return JSON.stringify(a) === JSON.stringify(b); }catch(e){ return false; } }\n' +
      code + '\n' +
      'const __start = performance.now();\n' +
      'const __results = [];\n' +
      'let __fn = null;\n' +
      'try{ __fn = typeof ' + fn + ' === "function" ? ' + fn + ' : null; }catch(e){}\n' +
      'for(let __i = 0; __i < __tests.length; __i++){\n' +
      '  const __t = __tests[__i];\n' +
      '  const __t0 = performance.now();\n' +
      '  let __ok = false, __got, __err = null;\n' +
      '  try{\n' +
      '    if(typeof __fn !== "function") throw new Error("Function ' + fn + ' is not defined");\n' +
      '    __got = __fn.apply(null, __t.args);\n' +
      '    __ok = __same(__norm(__got, __t.normalize), __norm(__t.expected, __t.normalize));\n' +
      '  }catch(e){ __err = e && e.message ? String(e.message) : String(e); }\n' +
      '  __results.push({ name: __t.name, pass: __ok, got: __safe(__got), expected: __t.expected, error: __err, ms: performance.now() - __t0 });\n' +
      '}\n' +
      'postMessage({ type: "done", results: __results, totalMs: performance.now() - __start });\n';
  }

  function finishJS(state, ok, value){
    if(jsRun !== state) return;
    jsRun = null;
    if(state.timer) clearTimeout(state.timer);
    try{ state.worker.terminate(); }catch(e){}
    try{ URL.revokeObjectURL(state.url); }catch(e){}
    if(ok) state.resolve(value); else state.reject(value);
  }

  function runJS(problem, code){
    return new Promise((resolve, reject) => {
      const started = performance.now();
      let url = '', worker = null;

      try{
        url = URL.createObjectURL(new Blob([workerScript(problem, code)], { type: 'application/javascript' }));
        worker = new Worker(url);
      }catch(err){
        if(url){ try{ URL.revokeObjectURL(url); }catch(e){} }
        const failure = new Error('Could not start the code runner: ' + errorText(err));
        failure.ms = performance.now() - started;
        reject(failure);
        return;
      }

      const state = { worker, url, timer: null, resolve, reject, started };
      jsRun = state;

      state.timer = setTimeout(() => {
        finishJS(state, false, timeoutError(JS_TIMEOUT));
      }, JS_TIMEOUT);

      worker.onmessage = e => {
        if(jsRun !== state) return;
        const data = e.data || {};
        if(data.type === 'done'){
          finishJS(state, true, { results: data.results, totalMs: data.totalMs });
        }else if(data.type === 'error'){
          const err = new Error(data.error || 'Unknown worker error');
          err.ms = performance.now() - started;
          finishJS(state, false, err);
        }else{
          const err = new Error('Unexpected response from the code runner');
          err.ms = performance.now() - started;
          finishJS(state, false, err);
        }
      };

      worker.onerror = e => {
        if(jsRun !== state) return;
        if(e && e.preventDefault) e.preventDefault();
        const err = new Error(errorText(e));
        err.ms = performance.now() - started;
        finishJS(state, false, err);
      };
    });
  }

  function isOnlineLang(lang){
    return lang === 'c' || lang === 'cpp' || lang === 'java';
  }

  function normalizeStdout(value){
    return String(value == null ? '' : value).replace(/\r\n/g, '\n').replace(/\s+$/, '');
  }

  function onlineResult(problem, data, elapsed){
    const stdout = typeof data === 'string' ? data :
      (data && data.stdout != null ? String(data.stdout) :
        (data && data.output != null ? String(data.output) : ''));
    const stderr = data && data.stderr != null ? String(data.stderr) : '';
    const serviceError = data && data.error != null ? String(data.error) : '';
    const exitCode = data && data.exitCode != null ? Number(data.exitCode) : 0;
    const expected = problem.io && typeof problem.io.expected === 'string' ? problem.io.expected : '';
    const error = (data && data.timedOut ? 'Remote runner timed out' : '') || serviceError ||
      (exitCode ? (stderr || 'Exited with code ' + exitCode) : (!stdout && stderr ? stderr : '')) || null;
    const pass = !error && normalizeStdout(stdout) === normalizeStdout(expected);
    return {
      results: [{ name: 'Sample I/O', pass, got: stdout, expected, error, ms: elapsed }],
      totalMs: elapsed
    };
  }

  function finishOnline(state, ok, value){
    if(onlineRun !== state) return;
    onlineRun = null;
    if(state.timer) clearTimeout(state.timer);
    if(ok) state.resolve(value); else state.reject(value);
  }

  function runOnline(lang, problem, code){
    return new Promise((resolve, reject) => {
      const stored = Store.get('runnerurl', '');
      const endpoint = typeof stored === 'string' ? stored.trim() : '';
      if(!endpoint){
        reject(new Error('No online runner endpoint is configured. Set Store \'runnerurl\' (localStorage key ff_runnerurl) to your remote runner URL.'));
        return;
      }
      if(typeof fetch !== 'function' || typeof AbortController !== 'function'){
        reject(new Error('This browser cannot run code online'));
        return;
      }

      const controller = new AbortController();
      const state = { controller, timer: null, started: performance.now(), resolve, reject, timedOut: false };
      onlineRun = state;

      state.timer = setTimeout(() => {
        if(onlineRun !== state) return;
        state.timedOut = true;
        controller.abort();
      }, ONLINE_TIMEOUT);

      /* UNVERIFIED: The remote runner request/response shape is a placeholder.
         Confirm the payload fields, language names, and stdout/stderr mapping against the real service. */
      const payload = {
        language: lang,
        code,
        stdin: problem.io && typeof problem.io.stdin === 'string' ? problem.io.stdin : ''
      };

      let request;
      try{
        request = fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
          body: JSON.stringify(payload),
          signal: controller.signal
        });
      }catch(err){
        const failure = new Error(errorText(err));
        failure.ms = performance.now() - state.started;
        finishOnline(state, false, failure);
        return;
      }

      request.then(response => {
        if(onlineRun !== state) return null;
        if(!response.ok) throw new Error('Online runner returned HTTP ' + response.status);
        return response.json().catch(() => { throw new Error('Online runner returned an invalid response'); });
      }).then(data => {
        if(onlineRun !== state) return;
        const elapsed = performance.now() - state.started;
        finishOnline(state, true, onlineResult(problem, data, elapsed));
      }).catch(err => {
        if(onlineRun !== state) return;
        if(err && err.name === 'AbortError'){
          finishOnline(state, false, state.timedOut ? timeoutError(ONLINE_TIMEOUT) : cancelledError());
          return;
        }
        const failure = err instanceof Error ? err : new Error(errorText(err));
        if(typeof failure.ms !== 'number') failure.ms = performance.now() - state.started;
        finishOnline(state, false, failure);
      });
    });
  }

  function pythonHarness(problem, code){
    const tests = problem.tests.map(t => ({ name: t.name, args: t.args }));
    return [
      'import json, time',
      '_ns = {}',
      'exec(' + JSON.stringify(String(code)) + ', _ns)',
      '_fn_name = ' + JSON.stringify(String(problem.fn)),
      '_fn = _ns.get(_fn_name)',
      '_tests = json.loads(' + JSON.stringify(JSON.stringify(tests)) + ')',
      '_results = []',
      'for _t in _tests:',
      '    _t0 = time.perf_counter()',
      '    _got = None',
      '    _err = None',
      '    try:',
      '        if not callable(_fn):',
      '            raise NameError("Function " + _fn_name + " is not defined")',
      '        _got = _fn(*_t.get("args", []))',
      '        _got = json.loads(json.dumps(_got, ensure_ascii=False, allow_nan=False))',
      '    except BaseException as _e:',
      '        _err = str(_e) or _e.__class__.__name__',
      '        _got = None',
      '    _results.append({',
      '        "name": _t.get("name") or ("Test " + str(len(_results) + 1)),',
      '        "got": _got,',
      '        "error": _err,',
      '        "ms": (time.perf_counter() - _t0) * 1000',
      '    })',
      'json.dumps(_results, ensure_ascii=False, allow_nan=False)'
    ].join('\n');
  }

  function pythonWorkerScript(){
    return "'use strict';\n" +
      'const PYODIDE_BASE = ' + JSON.stringify(PYODIDE_BASE) + ';\n' +
      'let pyodide = null;\n' +
      'let loadPosted = false;\n' +
      'function errText(err){ return err && err.message ? String(err.message) : String(err || "Unknown error"); }\n' +
      'function loadFailed(){ if(loadPosted) return; loadPosted = true; self.postMessage({ type: "load-error", error: "Could not load the Python runtime. Check your internet connection and try again." }); }\n' +
      'try{\n' +
      '  importScripts(PYODIDE_BASE + "pyodide.js");\n' +
      '  loadPyodide({ indexURL: PYODIDE_BASE }).then(function(py){ pyodide = py; self.postMessage({ type: "ready" }); }).catch(loadFailed);\n' +
      '}catch(err){ loadFailed(); }\n' +
      'self.onmessage = function(e){\n' +
      '  const msg = e.data || {};\n' +
      '  if(msg.type !== "run") return;\n' +
      '  if(!pyodide){ self.postMessage({ type: "error", error: "Python runtime is not ready" }); return; }\n' +
      '  const started = performance.now();\n' +
      '  try{\n' +
      '    const output = pyodide.runPython(msg.script);\n' +
      '    self.postMessage({ type: "done", results: JSON.parse(output), totalMs: performance.now() - started });\n' +
      '  }catch(err){ self.postMessage({ type: "error", error: errText(err) }); }\n' +
      '};\n';
  }

  function resetPythonWorker(){
    if(pyWorker){ try{ pyWorker.terminate(); }catch(e){} }
    if(pyUrl){ try{ URL.revokeObjectURL(pyUrl); }catch(e){} }
    pyWorker = null;
    pyUrl = '';
    pyReady = null;
    pyReadyResolve = null;
    pyReadyReject = null;
    pyLoaded = false;
  }

  function pythonResults(problem, data){
    const raw = Array.isArray(data.results) ? data.results : [];
    return problem.tests.map((test, i) => {
      const row = raw[i];
      let error = row && row.error ? String(row.error) : null;
      if(!row) error = 'No result returned';
      const got = row ? row.got : undefined;
      const pass = !error && sameJSON(normalizeValue(got, test.normalize), normalizeValue(test.expected, test.normalize));
      return {
        name: test.name,
        pass,
        got,
        expected: test.expected,
        error,
        ms: Math.max(0, Number(row && row.ms) || 0)
      };
    });
  }

  function handlePythonMessage(e, source){
    if(pyWorker !== source) return;
    const data = e.data || {};

    if(data.type === 'ready'){
      pyLoaded = true;
      if(pyReadyResolve) pyReadyResolve();
      pyReadyResolve = null;
      pyReadyReject = null;
      return;
    }

    if(data.type === 'load-error'){
      const err = new Error(data.error || 'Could not load the Python runtime. Check your internet connection and try again.');
      if(pyReadyReject) pyReadyReject(err);
      pyReadyResolve = null;
      pyReadyReject = null;
      if(pyRun){
        const state = pyRun;
        pyRun = null;
        if(state.timer) clearTimeout(state.timer);
        state.reject(err);
      }
      resetPythonWorker();
      return;
    }

    if(data.type === 'done'){
      if(!pyRun) return;
      const state = pyRun;
      pyRun = null;
      if(state.timer) clearTimeout(state.timer);
      state.resolve({ results: pythonResults(state.problem, data), totalMs: data.totalMs });
      return;
    }

    if(data.type === 'error'){
      if(!pyRun) return;
      const state = pyRun;
      pyRun = null;
      if(state.timer) clearTimeout(state.timer);
      const err = new Error(data.error || 'Unknown Python error');
      err.ms = performance.now() - state.started;
      state.reject(err);
    }
  }

  function ensurePythonWorker(){
    if(pyWorker) return pyReady || Promise.resolve();

    pyLoaded = false;
    pyReady = new Promise((resolve, reject) => {
      pyReadyResolve = resolve;
      pyReadyReject = reject;
    });

    let worker = null;
    try{
      pyUrl = URL.createObjectURL(new Blob([pythonWorkerScript()], { type: 'application/javascript' }));
      worker = new Worker(pyUrl);
    }catch(err){
      resetPythonWorker();
      return Promise.reject(new Error('Could not start the Python runner: ' + errorText(err)));
    }

    pyWorker = worker;
    worker.onmessage = e => handlePythonMessage(e, worker);
    worker.onerror = e => {
      if(pyWorker !== worker) return;
      if(e && e.preventDefault) e.preventDefault();
      const err = new Error(errorText(e));
      if(!pyLoaded && pyReadyReject) pyReadyReject(err);
      if(pyRun){
        const state = pyRun;
        pyRun = null;
        if(state.timer) clearTimeout(state.timer);
        state.reject(err);
      }
      resetPythonWorker();
    };

    return pyReady;
  }

  function runPython(problem, code){
    return new Promise((resolve, reject) => {
      if(pyRun){
        const previous = pyRun;
        pyRun = null;
        if(previous.timer) clearTimeout(previous.timer);
        previous.reject(cancelledError());
        resetPythonWorker();
      }

      const state = { resolve, reject, timer: null, started: performance.now(), problem };
      pyRun = state;

      ensurePythonWorker().then(() => {
        if(pyRun !== state) return;
        try{
          pyWorker.postMessage({ type: 'run', script: pythonHarness(problem, code) });
        }catch(err){
          resetPythonWorker();
          throw err;
        }
        state.timer = setTimeout(() => {
          if(pyRun !== state) return;
          pyRun = null;
          resetPythonWorker();
          state.reject(timeoutError(PY_TIMEOUT));
        }, PY_TIMEOUT);
      }).catch(err => {
        if(pyRun !== state) return;
        pyRun = null;
        if(state.timer) clearTimeout(state.timer);
        if(!err.ms) err.ms = performance.now() - state.started;
        state.reject(err);
      });
    });
  }

  function run(lang, problem, code, opts){
    if(isOnlineLang(lang)){
      if(!opts || opts.consent !== true) return Promise.reject(new Error('Online runner needs consent'));
      return runOnline(lang, problem, code);
    }
    if(lang === 'python') return runPython(problem, code);
    if(lang === 'javascript') return runJS(problem, code);
    return Promise.reject(new Error('Unsupported language: ' + lang));
  }

  function cancel(){
    if(jsRun){
      const state = jsRun;
      jsRun = null;
      if(state.timer) clearTimeout(state.timer);
      try{ state.worker.terminate(); }catch(e){}
      try{ URL.revokeObjectURL(state.url); }catch(e){}
      state.reject(cancelledError());
    }
    if(onlineRun){
      const state = onlineRun;
      try{ state.controller.abort(); }catch(e){}
      finishOnline(state, false, cancelledError());
    }
    if(pyRun){
      const state = pyRun;
      pyRun = null;
      if(state.timer) clearTimeout(state.timer);
      resetPythonWorker();
      state.reject(cancelledError());
    }
  }

  function isPythonReady(){
    return !!(pyWorker && pyLoaded);
  }

  return { run, cancel, isPythonReady };
})();

window.Runners = Runners;
