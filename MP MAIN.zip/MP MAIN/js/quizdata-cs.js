'use strict';

Quiz.addBank([
  {
    q: 'What does CPU stand for?',
    options: ['Central Processing Unit', 'Central Program Unit', 'Computer Personal Unit', 'Control Processing Utility'],
    answer: 0,
    subject: 'Computer Science',
    explain: 'CPU stands for Central Processing Unit, the main processor of a computer.'
  },
  {
    q: 'Which type of memory is volatile, meaning it loses its contents when power is turned off?',
    options: ['ROM', 'RAM', 'Hard disk', 'Flash drive'],
    answer: 1,
    subject: 'Computer Science',
    explain: 'RAM is volatile memory and loses its data when power is removed.'
  },
  {
    q: 'Which part of the CPU performs arithmetic and logical operations?',
    options: ['Arithmetic Logic Unit (ALU)', 'Control Unit', 'Register file', 'Cache memory'],
    answer: 0,
    subject: 'Computer Science',
    explain: 'The ALU performs calculations and logical comparisons.'
  },
  {
    q: 'What does "WWW" stand for?',
    options: ['World Wide Web', 'World Wireless Web', 'Web Wide World', 'Wide World Web'],
    answer: 0,
    subject: 'Computer Science',
    explain: 'WWW stands for World Wide Web.'
  },
  {
    q: 'Which protocol is mainly used to transfer web pages between a browser and a web server?',
    options: ['FTP', 'HTTP', 'SMTP', 'DNS'],
    answer: 1,
    subject: 'Computer Science',
    explain: 'HTTP, and its secure form HTTPS, is used to transfer web pages.'
  },
  {
    q: 'Which device connects different networks and routes packets between them?',
    options: ['Switch', 'Hub', 'Router', 'Repeater'],
    answer: 2,
    subject: 'Computer Science',
    explain: 'A router forwards packets between different networks.'
  },
  {
    q: 'What is the main purpose of DNS?',
    options: ['Assign IP addresses to devices', 'Encrypt web traffic', 'Block malicious websites', 'Translate domain names into IP addresses'],
    answer: 3,
    subject: 'Computer Science',
    explain: 'DNS translates human-readable domain names into IP addresses.'
  },
  {
    q: 'What is the decimal value of the binary number 1010?',
    options: ['8', '10', '12', '16'],
    answer: 1,
    subject: 'Computer Science',
    explain: '1010 in binary equals 8 + 2 = 10 in decimal.'
  },
  {
    q: 'What is the binary representation of the decimal number 5?',
    options: ['100', '110', '101', '111'],
    answer: 2,
    subject: 'Computer Science',
    explain: '5 = 4 + 1, which is 101 in binary.'
  },
  {
    q: 'What is the binary equivalent of the hexadecimal digit F?',
    options: ['1111', '1010', '1100', '1000'],
    answer: 0,
    subject: 'Computer Science',
    explain: 'The hexadecimal digit F represents decimal 15, which is 1111 in binary.'
  },
  {
    q: 'Which of these is a loop construct in most programming languages?',
    options: ['if', 'for', 'switch', 'return'],
    answer: 1,
    subject: 'Computer Science',
    explain: 'A "for" loop repeats a block of code a specified number of times.'
  },
  {
    q: 'What is the main purpose of an if statement in programming?',
    options: ['To repeat a block of code', 'To store a value in memory', 'To define a class', 'To execute code conditionally'],
    answer: 3,
    subject: 'Computer Science',
    explain: 'An if statement runs a block of code only when a condition is true.'
  },
  {
    q: 'Which of these is a high-level programming language?',
    options: ['Machine code', 'Assembly language', 'Python', 'Binary code'],
    answer: 2,
    subject: 'Computer Science',
    explain: 'Python is a high-level language that is easier for humans to read and write.'
  },
  {
    q: 'What is an algorithm?',
    options: ['A programming language', 'A hardware component', 'A database', 'A step-by-step procedure for solving a problem'],
    answer: 3,
    subject: 'Computer Science',
    explain: 'An algorithm is a finite sequence of steps used to solve a problem.'
  },
  {
    q: 'Which data structure follows the First-In, First-Out (FIFO) principle?',
    options: ['Stack', 'Tree', 'Queue', 'Graph'],
    answer: 2,
    subject: 'Computer Science',
    explain: 'A queue removes elements in the same order in which they were added.'
  },
  {
    q: 'Which data structure follows the Last-In, First-Out (LIFO) principle?',
    options: ['Queue', 'Array', 'Linked list', 'Stack'],
    answer: 3,
    subject: 'Computer Science',
    explain: 'A stack removes the most recently added element first.'
  },
  {
    q: 'What is the time complexity of binary search on a sorted array?',
    options: ['O(n)', 'O(1)', 'O(log n)', 'O(n²)'],
    answer: 2,
    subject: 'Computer Science',
    explain: 'Binary search halves the search range each time, giving O(log n) complexity.'
  },
  {
    q: 'What does SQL stand for?',
    options: ['Simple Query Language', 'Structured Query Language', 'Standard Question Language', 'System Query Logic'],
    answer: 1,
    subject: 'Computer Science',
    explain: 'SQL stands for Structured Query Language, used to manage relational databases.'
  },
  {
    q: 'Which SQL command is used to retrieve data from a database?',
    options: ['INSERT', 'UPDATE', 'DELETE', 'SELECT'],
    answer: 3,
    subject: 'Computer Science',
    explain: 'The SELECT statement retrieves rows from a database table.'
  },
  {
    q: 'What is a primary key in a relational database?',
    options: ['A field that uniquely identifies each record', 'A field that can contain duplicate values', 'A table with no rows', 'A query that joins two tables'],
    answer: 0,
    subject: 'Computer Science',
    explain: 'A primary key uniquely identifies each row in a table.'
  }
]);
