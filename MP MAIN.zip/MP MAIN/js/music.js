/* music.js — Tape Deck: old Hindi stations (official YouTube player) + local files.
   Verified video ids only. Nothing plays until the user turns streaming on from the
   Music tab. Local files live in IndexedDB and never leave the device. */
'use strict';

const Music = (function(){

  /* ---------- station catalogue (every id verified playable) ---------- */
  const STATIONS = [
    {
      id:'truck', name:'Truck Driver', tag:'Highway', icon:'fa-truck-fast', hue:'#E0A458',
      desc:'Long jukeboxes for the open road',
      tracks:[
        { v:'TYbaOdqWMUQ', t:'Golden 70s Bollywood Songs',        d:4547 },
        { v:'m-m1ReKcRsw', t:'The Musical Legends — 20 old hits', d:5428 },
        { v:'1-vx-6irXO8', t:'Sadabahar Nagme',                   d:2848 },
        { v:'XSeuv32Af_Y', t:'80s Evergreen Hindi Songs',         d:2650 }
      ]
    },
    {
      id:'saloon', name:'Saloon', tag:'90s cuts', icon:'fa-scissors', hue:'#E2725B',
      desc:'Barber-shop hits, one song at a time',
      tracks:[
        { v:'mnkJoRaMqbc', t:'Kaun Hai Aisa Jise Phoolon Se',  d:323 },
        { v:'QWOpY0e_ZTU', t:'Meri Aankh Phadakti Hai',        d:215 },
        { v:'otZWTsvP-54', t:'Papa Ki Pari',                   d:349 },
        { v:'bYwSFF-_k2E', t:'Woh Meri Neend Mera Chain',      d:300 },
        { v:'UGZta7AzBkM', t:'Zindagi Pyar Ka Geet Hai',       d:309 }
      ]
    },
    {
      id:'bus', name:'Bus Driver', tag:'Kishore', icon:'fa-bus-simple', hue:'#4C8FD6',
      desc:'Kishore da, non-stop till the last stop',
      tracks:[
        { v:'ry8zxMSffDA', t:'Kishore Kumar 80s Greatest Hits', d:3156 },
        { v:'eLvWUBv6ziQ', t:'Kishore\u2019s Romantic Hits',    d:1622 },
        { v:'n2ARM0msgB0', t:'Best of Kishore Kumar',           d:2650 },
        { v:'R8d1li7sOBc', t:'Kishore Kumar Hits',              d:1930 }
      ]
    },
    {
      id:'classics', name:'Old Bollywood Classics', tag:'Golden era', icon:'fa-clapperboard', hue:'#B78BFA',
      desc:'The timeless stuff, back to back',
      tracks:[
        { v:'7CO9TS9N22Q', t:'Top 20 Songs of Kishore Kumar', d:6337 },
        { v:'Rv1_XzDb-Lw', t:'80s Love Songs',                d:2686 },
        { v:'ZTB5kukM3HI', t:'Evergreen Birthday Jukebox',    d:6834 }
      ]
    },
    {
      id:'mukesh-rafi', name:'Mukesh & Rafi', tag:'Voices', icon:'fa-microphone-lines', hue:'#7FBF9E',
      desc:'Two voices that defined a generation',
      tracks:[
        { v:'syhMeKZnhBA', t:'51 Mukesh Hits',                  d:5391 },
        { v:'cemHzxPTNTw', t:'Best of Mohammad Rafi',           d:2626 },
        { v:'ule63jhdlYQ', t:'Mukesh & Asha — Timeless Duets',  d:2323 },
        { v:'69pPYkGiEAQ', t:'Kisi Ki Muskurahaton Pe',         d:248 },
        { v:'GNTNnp5rk5E', t:'Aane Se Uske Aaye Bahar',         d:190 }
      ]
    },
    {
      id:'lata-asha', name:'Lata & Asha', tag:'Melody', icon:'fa-star', hue:'#EE9BB7',
      desc:'The nightingale and her sister',
      tracks:[
        { v:'_t61CJBzXEA', t:'Rafi & Lata — Top 10',       d:1947 },
        { v:'M9YGUkKphsg', t:'Zindagi Pyar Ka Geet Hai',   d:311 },
        { v:'6C7R_CUJgHQ', t:'Rimjhim Gire Sawan',         d:225 },
        { v:'Upq1jF3JZqY', t:'Yaara Seeli Seeli',          d:299 },
        { v:'BV0-rrdPJKw', t:'Tera Mera Pyar Amar',        d:235 },
        { v:'nOru3DwJnrU', t:'O Babul Pyare',              d:357 }
      ]
    },
    {
      id:'files', name:'My Files', tag:'Offline', icon:'fa-folder-open', hue:'#8FBF4D',
      desc:'Your own songs, stored on this device',
      local:true, tracks:[]
    }
  ];

  const KEY_VOL = 'musicvol', KEY_SHUF = 'musicShuffle', KEY_REP = 'musicRepeat', KEY_YT = 'ytConsent';
  const DB_NAME = 'ff_tape_v1', DB_STORE = 'tracks';

  const state = {
    tab: 'sounds',
    stationId: null,
    playId: null,
    tracks: [],
    index: 0,
    playing: false,
    mode: 'yt',
    fails: 0,
    blocked: false,
    showVideo: false,
    shuffle: Store.get(KEY_SHUF, false),
    repeat: Store.get(KEY_REP, 'off'),
    vol: Math.min(1, Math.max(0, Store.get(KEY_VOL, 0.8)))
  };

  let yt = null, apiPromise = null, audio = null, objUrl = null;
  let tickId = null, pending = null, localTracks = [], initialized = false;
  let startTimer = null, hinted = false, autoVideo = false;
  let nudgeTimers = [];

  const station = id => STATIONS.find(s => s.id === id) || null;
  const current = () => state.tracks[state.index] || null;
  const ytOn = () => Store.get(KEY_YT, '') === 'yes';
  const isYt = () => state.mode === 'yt';

  /* ---------- IndexedDB ---------- */
  let dbp = null;
  function db(){
    if(dbp) return dbp;
    dbp = new Promise((res, rej) => {
      if(!window.indexedDB){ rej(new Error('no-idb')); return; }
      let req;
      try{ req = indexedDB.open(DB_NAME, 1); }catch(e){ rej(e); return; }
      req.onupgradeneeded = () => {
        const d = req.result;
        if(!d.objectStoreNames.contains(DB_STORE)) d.createObjectStore(DB_STORE, { keyPath:'id' });
      };
      req.onsuccess = () => res(req.result);
      req.onerror = () => rej(req.error || new Error('idb'));
    });
    return dbp;
  }
  function allTracks(){
    return db().then(d => new Promise((res, rej) => {
      const rq = d.transaction(DB_STORE, 'readonly').objectStore(DB_STORE).getAll();
      rq.onsuccess = () => res((rq.result || []).sort((a, b) => a.added - b.added));
      rq.onerror = () => rej(rq.error);
    }));
  }
  function putTrack(t){
    return db().then(d => new Promise((res, rej) => {
      const tx = d.transaction(DB_STORE, 'readwrite');
      tx.objectStore(DB_STORE).put(t);
      tx.oncomplete = () => res(t);
      tx.onerror = () => rej(tx.error || new Error('put'));
    }));
  }
  function dropTrack(id){
    return db().then(d => new Promise((res, rej) => {
      const tx = d.transaction(DB_STORE, 'readwrite');
      tx.objectStore(DB_STORE).delete(id);
      tx.oncomplete = () => res();
      tx.onerror = () => rej(tx.error || new Error('del'));
    }));
  }

  function probeDuration(file){
    return new Promise(res => {
      const url = URL.createObjectURL(file);
      const a = new Audio();
      let done = false;
      const finish = v => { if(done) return; done = true; URL.revokeObjectURL(url); res(v); };
      a.preload = 'metadata';
      a.onloadedmetadata = () => finish(isFinite(a.duration) ? Math.round(a.duration) : 0);
      a.onerror = () => finish(0);
      a.src = url;
      setTimeout(() => finish(0), 4000);
    });
  }

  async function addFiles(list){
    const files = Array.from(list || []).filter(f =>
      /^audio\//.test(f.type) || /\.(mp3|m4a|aac|wav|ogg|oga|opus|flac|webm)$/i.test(f.name));
    if(!files.length){ toast('Those files are not audio', 'warn'); return; }
    let ok = 0, failed = 0;
    for(const f of files){
      if(f.size > 150 * 1024 * 1024){ failed++; continue; }
      try{
        const dur = await probeDuration(f);
        await putTrack({
          id: 't' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
          name: f.name.replace(/\.[^.]+$/, ''),
          size: f.size, type: f.type, dur,
          added: Date.now(), blob: f
        });
        ok++;
      }catch(e){ failed++; }
    }
    if(ok) toast(ok + ' track' + (ok > 1 ? 's' : '') + ' added to My Files', 'info');
    if(failed) toast(failed + ' file' + (failed > 1 ? 's' : '') + ' could not be stored — the browser may be out of space', 'warn');
    await loadLocal();
    renderGrid();
    if(state.stationId === 'files') renderDetail(station('files'));
  }

  async function loadLocal(){
    try{ localTracks = await allTracks(); }
    catch(e){ localTracks = []; }
  }

  /* ---------- YouTube API ---------- */
  function loadAPI(){
    if(window.YT && window.YT.Player) return Promise.resolve();
    if(apiPromise) return apiPromise;
    apiPromise = new Promise((res, rej) => {
      let done = false;
      const finish = ok => {
        if(done) return;
        done = true;
        ok ? res() : rej(new Error('yt-api'));
      };
      const prev = window.onYouTubeIframeAPIReady;
      window.onYouTubeIframeAPIReady = function(){
        try{ if(typeof prev === 'function') prev(); }catch(e){}
        finish(true);
      };
      const s = document.createElement('script');
      s.src = 'https://www.youtube.com/iframe_api';
      s.async = true;
      s.onerror = () => finish(false);
      document.head.append(s);
      setTimeout(() => finish(!!(window.YT && window.YT.Player)), 15000);
    }).catch(e => { apiPromise = null; throw e; });
    return apiPromise;
  }

  function createPlayer(videoId){
    const host = $('#yt-frame');
    if(!host || !window.YT) return;
    host.innerHTML = '';
    const holder = document.createElement('div');
    holder.id = 'yt-holder';
    host.append(holder);
    yt = new YT.Player(holder, {
      width: '100%', height: '100%', videoId,
      playerVars: {
        autoplay: 1, playsinline: 1, rel: 0, modestbranding: 1,
        origin: location.protocol === 'file:' ? '' : location.origin
      },
      events: {
        onReady: e => {
          try{ e.target.setVolume(Math.round(state.vol * 100)); e.target.playVideo(); }catch(err){}
          watchStart();
        },
        onStateChange: onYTState,
        onError: onYTError
      }
    });
  }

  function onYTState(e){
    if(!yt) return;
    if(e.data === 1){
      clearTimeout(startTimer); startTimer = null; clearNudge();
      state.playing = true; state.blocked = false; state.fails = 0;
      if(autoVideo){ autoVideo = false; setVideo(false); }
      renderPlayer();
    }
    else if(e.data === 3){
      /* buffering: show as playing, but keep the start watchdog running */
      state.playing = true;
      renderPlayer();
    }
    else if(e.data === 0){ next(true); }
    else if(e.data === 2 || e.data === -1){ state.playing = false; renderPlayer(); }
    if(window.Sound) Sound.syncUI();
  }

  function ytTime(){
    try{ return (yt && yt.getCurrentTime) ? (yt.getCurrentTime() || 0) : 0; }catch(e){ return 0; }
  }

  /* If playback never actually starts (browser autoplay policy, blocked embed, no network),
     don't pretend the pause icon means "playing": show it, and surface the player so one tap
     on YouTube's own button can start it. */
  function watchStart(){
    clearTimeout(startTimer);
    startTimer = setTimeout(() => {
      startTimer = null;
      if(!state.tracks.length || !isYt()) return;
      if(state.playing && ytTime() > 0.5) return;
      state.blocked = true;
      state.playing = false;
      clearNudge();
      renderPlayer();
      if(!state.showVideo && $('#yt-frame iframe')){ setVideo(true); autoVideo = true; }
      if(!hinted){
        hinted = true;
        toast(ytOn() ? 'This browser blocked audio — tap play in the player' : 'Tap play to start', 'warn');
      }
    }, 4500);
  }

  function onYTError(e){
    const code = e && e.data;
    const tr = current();
    if(tr && code !== 5 && code !== 2) tr.dead = true;
    toast('That video is not playable — skipping', 'warn');
    next(true);
  }

  /* ---------- playback ---------- */
  function playStation(){
    const st = station(state.stationId);
    if(!st) return;
    if(st.local){
      if(!localTracks.length){ toast('Add audio files first — they stay on this device', 'warn'); return; }
      state.tracks = localTracks.slice();
      state.mode = 'local';
      state.playId = st.id;
      state.index = state.shuffle ? Math.floor(Math.random() * state.tracks.length) : 0;
      state.fails = 0;
      playCurrent();
      return;
    }
    if(!ytOn()){ askConsent(() => playStation()); return; }
    if(onFile()){
      paintFileWarn();
      toast('YouTube needs http://localhost — open the app with Live Server', 'warn');
      return;
    }
    state.tracks = st.tracks.slice();
    if(!state.tracks.length){ toast('No playable tracks in this station', 'warn'); return; }
    state.mode = 'yt';
    state.playId = st.id;
    state.index = state.shuffle ? Math.floor(Math.random() * state.tracks.length) : 0;
    state.fails = 0;
    playCurrent();
  }

  function playTrack(i){
    if(i < 0 || i >= state.tracks.length) return;
    state.index = i;
    state.fails = 0;
    playCurrent();
  }

  function playCurrent(){
    const tr = current();
    if(!tr){ state.playing = false; renderPlayer(); return; }
    if(state.mode === 'local') playLocal(tr);
    else playYT(tr);
  }

  /* Some browsers only honour a play command for a short window after the tap.
     Re-issue it a few times; stop as soon as the player reports playing. */
  function nudge(){
    clearNudge();
    [250, 900, 1600].forEach(ms => {
      nudgeTimers.push(setTimeout(() => {
        if(state.blocked || !state.tracks.length || !isYt()) return;
        if(ytTime() > 0.5) return;
        try{ if(yt && yt.playVideo) yt.playVideo(); }catch(e){}
      }, ms));
    });
  }
  function clearNudge(){ nudgeTimers.forEach(clearTimeout); nudgeTimers = []; }

  function playYT(tr){
    state.mode = 'yt';
    state.blocked = false;
    if(onFile()){
      paintFileWarn();
      toast('YouTube needs http://localhost — open the app with Live Server', 'warn');
      state.playing = false; renderPlayer();
      return;
    }
    loadAPI().then(() => {
      if(!yt || !yt.loadVideoById) createPlayer(tr.v);
      else { try{ yt.loadVideoById(tr.v); }catch(e){} }
      try{ yt.setVolume(Math.round(state.vol * 100)); }catch(e){}
      /* the bar only shows "playing" once the player reports it */
      state.playing = false;
      renderPlayer(); startTick(); watchStart(); nudge();
      if(window.Sound) Sound.syncUI();
    }).catch(() => {
      toast('Could not reach YouTube — check your connection', 'warn');
      state.playing = false; renderPlayer();
    });
  }

  function playLocal(tr){
    state.mode = 'local';
    if(!audio){
      audio = new Audio();
      audio.preload = 'metadata';
      audio.addEventListener('ended', () => next(true));
      audio.addEventListener('error', () => {
        if(state.mode !== 'local' || !state.tracks.length) return;
        toast('That file could not be played — skipping', 'warn');
        next(true);
      });
    }
    if(objUrl){ URL.revokeObjectURL(objUrl); objUrl = null; }
    try{ objUrl = URL.createObjectURL(tr.blob); }catch(e){ toast('That file could not be read', 'warn'); return; }
    audio.src = objUrl;
    audio.volume = state.vol;
    state.playing = true;
    audio.play().catch(() => toast('Tap play again to start this file', 'warn'));
    renderPlayer(); startTick();
    if(window.Sound) Sound.syncUI();
  }

  function toggle(){
    if(!state.tracks.length){ playStation(); return; }
    if(state.playing){
      if(isYt()){ clearNudge(); try{ yt && yt.pauseVideo(); }catch(e){} }
      else if(audio) audio.pause();
      state.playing = false;
      renderPlayer();
    }else{
      if(isYt()){
        try{ yt && yt.playVideo(); }catch(e){}
        state.blocked = false;
        watchStart();
        startTick();
      }else if(audio){
        audio.play().catch(() => {});
        state.playing = true;
        startTick();
      }
      renderPlayer();
    }
    if(window.Sound) Sound.syncUI();
  }

  function next(auto){
    if(!state.tracks.length) return;
    if(auto){
      state.fails++;
      if(state.fails > state.tracks.length){
        toast('This station is unavailable right now', 'warn');
        state.playing = false;
        stopTick(); renderPlayer();
        return;
      }
    }else state.fails = 0;
    if(state.repeat === 'one'){ playCurrent(); return; }
    if(state.shuffle && state.tracks.length > 1){
      let n = state.index;
      while(n === state.index) n = Math.floor(Math.random() * state.tracks.length);
      state.index = n;
    }else{
      state.index = (state.index + 1) % state.tracks.length;
    }
    playCurrent();
  }

  function prev(){
    if(!state.tracks.length) return;
    state.fails = 0;
    state.index = (state.index - 1 + state.tracks.length) % state.tracks.length;
    playCurrent();
  }

  function seek(ratio){
    const r = Math.max(0, Math.min(1, ratio));
    if(isYt()){
      try{ if(yt && yt.getDuration) yt.seekTo(r * yt.getDuration(), true); }catch(e){}
    }else if(audio && isFinite(audio.duration)){
      audio.currentTime = r * audio.duration;
    }
  }

  function setVolume(v){
    state.vol = Math.max(0, Math.min(1, v));
    Store.set(KEY_VOL, state.vol);
    try{ if(yt && yt.setVolume) yt.setVolume(Math.round(state.vol * 100)); }catch(e){}
    if(audio) audio.volume = state.vol;
    const r = $('#tp-vol');
    if(r) r.value = Math.round(state.vol * 100);
  }

  function stop(){
    state.playing = false;
    state.tracks = [];
    state.index = 0;
    state.fails = 0;
    state.playId = null;
    state.blocked = false;
    clearTimeout(startTimer); startTimer = null;
    clearNudge();
    setVideo(false);
    stopTick();
    try{ if(yt && yt.stopVideo) yt.stopVideo(); }catch(e){}
    if(audio){ try{ audio.pause(); }catch(e){} audio.removeAttribute('src'); }
    if(objUrl){ URL.revokeObjectURL(objUrl); objUrl = null; }
    renderPlayer();
    renderGrid();
    if(window.Sound) Sound.syncUI();
  }

  /* ---------- progress ---------- */
  function startTick(){ if(!tickId) tickId = setInterval(paintProgress, 500); paintProgress(); }
  function stopTick(){ if(tickId){ clearInterval(tickId); tickId = null; } }

  function paintProgress(){
    let cur = 0, dur = 0;
    if(isYt()){
      try{ if(yt && yt.getCurrentTime){ cur = yt.getCurrentTime() || 0; dur = yt.getDuration() || 0; } }catch(e){}
    }else if(audio){
      cur = audio.currentTime || 0;
      dur = isFinite(audio.duration) ? audio.duration : 0;
    }
    const c = $('#tp-cur'), d = $('#tp-dur'), s = $('#tp-seek');
    if(c) c.textContent = fmtClock(cur);
    if(d) d.textContent = fmtClock(dur);
    if(s && document.activeElement !== s) s.value = dur ? Math.round((cur / dur) * 1000) : 0;
  }

  /* ---------- consent ---------- */
  function paintConsent(){
    const on = ytOn();
    const label = $('#yt-consent-label'), btn = $('#yt-consent-btn');
    if(label) label.textContent = on ? 'Streaming on' : 'Streaming off';
    if(btn){
      btn.classList.toggle('on', on);
      btn.setAttribute('aria-pressed', on ? 'true' : 'false');
      btn.title = on ? 'Turn YouTube streaming off' : 'Turn YouTube streaming on';
    }
  }
  function askConsent(after){
    pending = after || null;
    const m = $('#yt-modal');
    if(m) m.style.display = 'flex';
  }
  function closeConsent(){
    const m = $('#yt-modal');
    if(m) m.style.display = 'none';
  }

  /* ---------- visible player (fallback when a browser blocks background audio) ---------- */
  function setVideo(on){
    state.showVideo = !!on;
    const dock = $('#yt-dock');
    if(dock) dock.classList.toggle('show', state.showVideo);
    const btn = $('#yt-video-btn');
    if(btn){
      btn.classList.toggle('on', state.showVideo);
      btn.setAttribute('aria-pressed', state.showVideo ? 'true' : 'false');
      btn.title = state.showVideo ? 'Hide the video player' : 'Show the video player';
    }
  }
  function toggleVideo(){
    if(!state.tracks.length || !isYt() || !$('#yt-frame iframe')){ toast('Start a station first', 'warn'); return; }
    setVideo(!state.showVideo);
  }

  /* YouTube's iframe API refuses to work from file:// (no valid origin). */
  function onFile(){
    return location.protocol === 'file:';
  }
  function paintFileWarn(){
    const w = $('#yt-file-warn');
    if(w) w.hidden = !onFile();
    const chips = $('#yt-video-btn');
    if(chips) chips.hidden = onFile();
  }

  /* ---------- rendering ---------- */
  function renderGrid(){
    const box = $('#station-grid');
    if(!box) return;
    box.innerHTML = STATIONS.map(s => {
      const tracks = s.local ? localTracks : s.tracks;
      const len = s.local
        ? localTracks.reduce((a, t) => a + (t.dur || 0), 0)
        : s.tracks.reduce((a, t) => a + (t.d || 0), 0);
      const meta = tracks.length
        ? tracks.length + (s.local ? ' file' : ' track') + (tracks.length > 1 ? 's' : '') + ' · ' + fmtDur(len)
        : 'Empty';
      return '<button class="station" data-station="' + s.id + '" style="--sh:' + s.hue + '" type="button">' +
        '<span class="st-cover">' +
          '<span class="st-icon"><i class="fa-solid ' + s.icon + '"></i></span>' +
          '<span class="st-tag">' + s.tag + '</span>' +
          '<span class="st-go"><i class="fa-solid fa-play"></i></span>' +
        '</span>' +
        '<span class="st-name">' + escapeHTML(s.name) + '</span>' +
        '<span class="st-desc">' + escapeHTML(s.desc) + '</span>' +
        '<span class="st-meta">' + meta + '</span>' +
      '</button>';
    }).join('');
  }

  function renderDetail(s){
    const box = $('#station-detail'), grid = $('#station-grid');
    if(!box || !s) return;
    if(grid) grid.hidden = true;
    box.hidden = false;

    const head = '<div class="st-bar">' +
      '<button class="link-btn" data-st-back type="button"><i class="fa-solid fa-arrow-left"></i>All stations</button>' +
      '<span class="st-src">' + (s.local ? '<i class="fa-solid fa-hard-drive"></i>On this device' : '<i class="fa-brands fa-youtube"></i>YouTube') + '</span>' +
    '</div>';

    const hero = '<div class="st-hero" style="--sh:' + s.hue + '">' +
      '<span class="st-hero-art"><i class="fa-solid ' + s.icon + '"></i></span>' +
      '<div class="st-hero-txt"><p class="label">' + escapeHTML(s.tag) + '</p><h3>' + escapeHTML(s.name) + '</h3><p class="sub">' + escapeHTML(s.desc) + '</p></div>' +
      '<button class="btn btn-primary st-play" data-st-play type="button"><i class="fa-solid fa-play"></i>' +
        (s.local && !localTracks.length ? 'Add files' : 'Play') + '</button>' +
    '</div>';

    if(s.local){
      box.innerHTML = head + hero +
        '<div class="drop" id="drop-zone">' +
          '<i class="fa-solid fa-file-arrow-up"></i>' +
          '<b>Drop audio files here</b>' +
          '<small>MP3, M4A, WAV, OGG · stored on this device, never uploaded</small>' +
          '<button class="btn btn-ghost" id="pick-files" type="button"><i class="fa-solid fa-folder-open"></i>Choose files</button>' +
          '<input type="file" id="file-input" accept="audio/*" multiple hidden>' +
        '</div>' +
        (localTracks.length
          ? '<ol class="tr-list">' + localTracks.map((t, i) =>
              '<li class="tr" data-track="' + i + '">' +
                '<span class="tr-n mono">' + String(i + 1).padStart(2, '0') + '</span>' +
                '<span class="tr-t">' + escapeHTML(t.name) + '<small>' + fmtDur(t.dur || 0) + ' · ' + (Math.round(t.size / 104857.6) / 10) + ' MB</small></span>' +
                '<button class="tr-del" data-lib-del="' + t.id + '" type="button" title="Remove" aria-label="Remove ' + escapeHTML(t.name) + '"><i class="fa-solid fa-xmark"></i></button>' +
              '</li>').join('') + '</ol>'
          : '<div class="empty"><i class="fa-solid fa-folder-open"></i><p>No files yet — add songs you own and they will play offline.</p></div>') +
        '<p class="footnote"><i class="fa-solid fa-shield-halved"></i>Files stay in this browser, in IndexedDB, and are never uploaded.</p>';
      bindFileInput();
      paintTrackHighlight();
      return;
    }

    box.innerHTML = head + hero +
      '<ol class="tr-list">' + s.tracks.map((t, i) =>
        '<li class="tr" data-track="' + i + '">' +
          '<span class="tr-n mono">' + String(i + 1).padStart(2, '0') + '</span>' +
          '<span class="tr-t">' + escapeHTML(t.t) + '<small>' + fmtDur(t.d) + '</small></span>' +
          '<span class="tr-play"><i class="fa-solid fa-play"></i></span>' +
        '</li>').join('') + '</ol>' +
      '<p class="footnote"><i class="fa-brands fa-youtube"></i><span>Streamed with the official YouTube player — availability depends on the uploader. Use <b>Open on YouTube</b> in the player if a video is blocked.</span></p>';

    paintTrackHighlight();
  }

  function closeDetail(){
    const box = $('#station-detail'), grid = $('#station-grid');
    if(box) box.hidden = true;
    if(grid) grid.hidden = false;
    state.stationId = null;
  }

  function paintTrackHighlight(){
    const same = state.playId && state.stationId === state.playId;
    $$('#station-detail [data-track]').forEach((li, i) => {
      li.classList.toggle('on', !!(same && state.playing && i === state.index));
    });
  }

  function renderPlayer(){
    const bar = $('#tape-player');
    if(!bar) return;
    const tr = current();
    const st = station(state.playId || state.stationId);
    bar.hidden = !state.tracks.length;
    if(!state.tracks.length) return;

    bar.classList.toggle('playing', state.playing);
    const title = $('#tp-title'), sub = $('#tp-sub'), art = $('#tp-art'), open = $('#tp-open');
    if(title) title.textContent = tr ? (tr.t || tr.name) : 'Nothing playing';
    if(sub) sub.textContent = state.mode === 'yt'
      ? (state.blocked ? 'Did not start — tap play' : (st ? st.name + ' · YouTube' : 'YouTube'))
      : (st ? st.name + ' · this device' : 'On this device');
    if(sub) sub.classList.toggle('warn', !!state.blocked);
    if(art){
      art.style.setProperty('--sh', st ? st.hue : '#B78BFA');
      art.innerHTML = '<i class="fa-solid ' + (st ? st.icon : 'fa-record-vinyl') + '"></i>';
    }
    if(open){
      if(state.mode === 'yt' && tr && tr.v){
        open.hidden = false;
        open.href = 'https://www.youtube.com/watch?v=' + tr.v;
      }else{
        open.hidden = true;
        open.removeAttribute('href');
      }
    }
    const sh = $('[data-pl="shuffle"]'), rp = $('[data-pl="repeat"]');
    if(sh){ sh.classList.toggle('on', state.shuffle); sh.setAttribute('aria-pressed', state.shuffle ? 'true' : 'false'); }
    if(rp){
      rp.classList.toggle('on', state.repeat !== 'off');
      rp.classList.toggle('one', state.repeat === 'one');
      rp.title = state.repeat === 'off' ? 'Repeat off' : state.repeat === 'all' ? 'Repeat station' : 'Repeat one';
    }
    const vol = $('#tp-vol');
    if(vol) vol.value = Math.round(state.vol * 100);
    paintProgress();
    paintTrackHighlight();
  }

  /* ---------- tabs / chrome ---------- */
  function setTab(tab){
    state.tab = tab === 'music' ? 'music' : 'sounds';
    $$('#tape-seg [data-tape-tab]').forEach(b => {
      const on = b.dataset.tapeTab === state.tab;
      b.classList.toggle('active', on);
      b.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    const s = $('#tape-sounds'), m = $('#tape-music');
    if(s) s.hidden = state.tab !== 'sounds';
    if(m) m.hidden = state.tab !== 'music';
    /* warm the YouTube API while the user browses stations, so Play is instant */
    if(state.tab === 'music' && ytOn() && !onFile()) loadAPI().catch(() => {});
  }

  function onShow(){
    renderGrid();
    paintConsent();
    paintFileWarn();
    setTab(state.tab);
    renderPlayer();
    if(window.Sound) Sound.syncUI();
  }
  function onHide(){
    if(state.showVideo) setVideo(false);
  }

  /* ---------- events ---------- */
  function bindFileInput(){
    const input = $('#file-input'), pick = $('#pick-files'), zone = $('#drop-zone');
    if(pick && input) pick.addEventListener('click', () => input.click());
    if(input) input.addEventListener('change', () => {
      addFiles(input.files);
      input.value = '';
    });
    if(zone){
      ['dragenter', 'dragover'].forEach(ev => zone.addEventListener(ev, e => {
        e.preventDefault(); zone.classList.add('over');
      }));
      ['dragleave', 'drop'].forEach(ev => zone.addEventListener(ev, e => {
        e.preventDefault(); zone.classList.remove('over');
      }));
      zone.addEventListener('drop', e => {
        if(e.dataTransfer && e.dataTransfer.files) addFiles(e.dataTransfer.files);
      });
    }
  }

  function bind(){
    document.addEventListener('click', e => {
      const tab = e.target.closest('[data-tape-tab]');
      if(tab){ setTab(tab.dataset.tapeTab); return; }

      const card = e.target.closest('[data-station]');
      if(card){
        const s = station(card.dataset.station);
        if(!s) return;
        state.stationId = s.id;
        if(s.local) loadLocal().then(() => renderDetail(s));
        else renderDetail(s);
        return;
      }

      if(e.target.closest('[data-st-back]')){ closeDetail(); return; }
      if(e.target.closest('[data-st-play]')){ playStation(); return; }

      const del = e.target.closest('[data-lib-del]');
      if(del){
        e.stopPropagation();
        const id = del.dataset.libDel;
        dropTrack(id).then(() => loadLocal()).then(() => {
          if(state.stationId === 'files') renderDetail(station('files'));
          renderGrid();
          toast('File removed', 'info');
        }).catch(() => toast('Could not remove that file', 'warn'));
        return;
      }

      const track = e.target.closest('#station-detail [data-track]');
      if(track){
        const i = +track.dataset.track;
        if(state.stationId === 'files'){
          state.tracks = localTracks.slice();
          state.mode = 'local';
          state.playId = 'files';
        }else{
          const s = station(state.stationId);
          if(!s) return;
          state.tracks = s.tracks.slice();
          state.mode = 'yt';
          state.playId = s.id;
          if(!ytOn()){ askConsent(() => playTrack(i)); return; }
        }
        playTrack(i);
        return;
      }

      const ctl = e.target.closest('[data-pl]');
      if(ctl){
        const what = ctl.dataset.pl;
        if(what === 'toggle') toggle();
        else if(what === 'next') next(false);
        else if(what === 'prev') prev();
        else if(what === 'close') stop();
        else if(what === 'shuffle'){
          state.shuffle = !state.shuffle;
          Store.set(KEY_SHUF, state.shuffle);
          renderPlayer();
        }else if(what === 'repeat'){
          state.repeat = state.repeat === 'off' ? 'all' : state.repeat === 'all' ? 'one' : 'off';
          Store.set(KEY_REP, state.repeat);
          renderPlayer();
        }
        return;
      }

      if(e.target.closest('#yt-video-btn')){ toggleVideo(); return; }
      if(e.target.closest('#yt-consent-btn')){
        if(ytOn()){
          Store.set(KEY_YT, 'no');
          paintConsent();
          if(state.playing && isYt()) stop();
          setVideo(false);
          toast('Streaming off — focus sounds and My Files still work', 'info');
        }else askConsent(null);
        return;
      }
      if(e.target.closest('#yt-accept')){
        Store.set(KEY_YT, 'yes');
        closeConsent();
        paintConsent();
        const a = pending; pending = null;
        toast('Streaming on', 'info');
        if(a) a();
        return;
      }
      if(e.target.closest('#yt-decline')){
        Store.set(KEY_YT, 'no');
        closeConsent();
        paintConsent();
        pending = null;
        toast('Stations need streaming — My Files plays offline', 'info');
        return;
      }
    });

    document.addEventListener('keydown', e => {
      if(e.key !== 'Escape') return;
      const m = $('#yt-modal');
      if(m && m.style.display !== 'none'){ closeConsent(); pending = null; }
    });

    const seek = $('#tp-seek');
    if(seek) seek.addEventListener('input', () => seek(seek.value / 1000));
    const vol = $('#tp-vol');
    if(vol) vol.addEventListener('input', () => setVolume(vol.value / 100));
  }

  /* ---------- boot ---------- */
  function init(){
    if(initialized || !$('#view-sounds')) return;
    initialized = true;
    bind();
    paintConsent();
    paintFileWarn();
    renderGrid();
    loadLocal().then(() => {
      renderGrid();
      if(state.stationId === 'files') renderDetail(station('files'));
    }).catch(() => {});
    setTab('sounds');
  }

  return {
    init, onShow, onHide, stop,
    isPlaying: () => state.playing,
    nowTitle: () => { const t = current(); return t ? (t.t || t.name || '') : ''; }
  };
})();

window.Music = Music;
