'use strict';

Quiz.addBank([
  {
    q: 'What does scarcity mean in economics?',
    options: ['A shortage of money only', 'Limited resources relative to unlimited wants', 'An excess supply of goods', 'Complete government control of markets'],
    answer: 1,
    subject: 'Economics',
    explain: 'Scarcity means resources are limited compared with unlimited human wants.'
  },
  {
    q: 'What is opportunity cost?',
    options: ['The total money spent on a good', 'The cost of all available alternatives together', 'The cost of production only', 'The value of the next best alternative forgone'],
    answer: 3,
    subject: 'Economics',
    explain: 'Opportunity cost is the value of the next best alternative given up when a choice is made.'
  },
  {
    q: 'Which of these is a factor of production?',
    options: ['Land', 'Money', 'Price', 'Demand'],
    answer: 0,
    subject: 'Economics',
    explain: 'Land is one of the four factors of production, along with labour, capital, and entrepreneurship.'
  },
  {
    q: 'What does the law of demand state, other things being equal?',
    options: ['Quantity demanded rises as price rises', 'Quantity demanded is unrelated to price', 'Quantity demanded falls as price rises', 'Supply falls as price rises'],
    answer: 2,
    subject: 'Economics',
    explain: 'The law of demand states an inverse relationship between price and quantity demanded.'
  },
  {
    q: 'What does the law of supply state, other things being equal?',
    options: ['Quantity supplied falls as price rises', 'Quantity supplied rises as price rises', 'Supply is unrelated to price', 'Demand rises as price rises'],
    answer: 1,
    subject: 'Economics',
    explain: 'The law of supply states a direct relationship between price and quantity supplied.'
  },
  {
    q: 'What is equilibrium price?',
    options: ['The highest price in the market', 'The lowest price in the market', 'The price at which demand exceeds supply', 'The price at which quantity demanded equals quantity supplied'],
    answer: 3,
    subject: 'Economics',
    explain: 'At equilibrium price, quantity demanded equals quantity supplied.'
  },
  {
    q: 'Which activity belongs to the primary sector?',
    options: ['Banking', 'Manufacturing', 'Agriculture', 'Software services'],
    answer: 2,
    subject: 'Economics',
    explain: 'Agriculture is a primary activity because it directly uses natural resources.'
  },
  {
    q: 'Which activity belongs to the tertiary sector?',
    options: ['Banking', 'Agriculture', 'Manufacturing', 'Mining'],
    answer: 0,
    subject: 'Economics',
    explain: 'Banking is a service, so it belongs to the tertiary sector.'
  },
  {
    q: 'What does GDP measure?',
    options: ['The total income of all citizens, wherever they live', 'The market value of final goods and services produced within a country in a year', 'The total value of exports', 'The total government spending'],
    answer: 1,
    subject: 'Economics',
    explain: 'GDP is the market value of final goods and services produced within a country in a year.'
  },
  {
    q: 'What is inflation?',
    options: ['A sustained fall in the general price level', 'A rise in unemployment', 'A sustained rise in the general price level', 'A fall in national income'],
    answer: 2,
    subject: 'Economics',
    explain: 'Inflation is a sustained rise in the general price level.'
  },
  {
    q: 'Which institution is the central bank of India?',
    options: ['State Bank of India', 'Ministry of Finance', 'NITI Aayog', 'Reserve Bank of India'],
    answer: 3,
    subject: 'Economics',
    explain: 'The Reserve Bank of India is the central bank of India.'
  },
  {
    q: 'Which of these is a direct tax?',
    options: ['Income tax', 'GST', 'Excise duty', 'Customs duty'],
    answer: 0,
    subject: 'Economics',
    explain: 'Income tax is paid directly by the taxpayer to the government.'
  },
  {
    q: 'What is the main aim of the Public Distribution System (PDS)?',
    options: ['To provide cheap loans to farmers', 'To provide food grains at subsidized prices', 'To collect taxes from traders', 'To build rural roads'],
    answer: 1,
    subject: 'Economics',
    explain: 'The PDS supplies food grains and other essentials at subsidized prices.'
  },
  {
    q: 'Which of these is a renewable resource?',
    options: ['Coal', 'Petroleum', 'Natural gas', 'Solar energy'],
    answer: 3,
    subject: 'Economics',
    explain: 'Solar energy is renewable because it is continuously replenished by the Sun.'
  },
  {
    q: 'What does globalization mean?',
    options: ['The isolation of national economies', 'The nationalization of private firms', 'The integration of economies through trade and investment', 'The replacement of money with barter'],
    answer: 2,
    subject: 'Economics',
    explain: 'Globalization is the growing integration of economies through trade, investment, and technology.'
  },
  {
    q: 'What is human capital?',
    options: ['The skills and knowledge of people', 'Machinery and equipment', 'Money held in banks', 'Land and minerals'],
    answer: 0,
    subject: 'Economics',
    explain: 'Human capital refers to the skills, knowledge, and health of people.'
  },
  {
    q: 'Which measure is commonly used to show income inequality?',
    options: ['Gross domestic product', 'Gini coefficient', 'Consumer price index', 'Human Development Index'],
    answer: 1,
    subject: 'Economics',
    explain: 'The Gini coefficient measures inequality, with 0 indicating perfect equality.'
  },
  {
    q: 'What does HDI stand for?',
    options: ['Human Diversity Index', 'Household Development Index', 'Human Development Index', 'Health Development Index'],
    answer: 2,
    subject: 'Economics',
    explain: 'HDI stands for Human Development Index.'
  },
  {
    q: 'Which of these is typically a fixed cost in the short run?',
    options: ['Raw materials', 'Daily wage labour', 'Electricity used per unit', 'Rent'],
    answer: 3,
    subject: 'Economics',
    explain: 'Rent is a fixed cost because it does not change with the level of output in the short run.'
  },
  {
    q: 'What is disguised unemployment?',
    options: ['More workers are employed than are actually needed', 'People are working part-time', 'Workers are unemployed due to a lack of skills', 'People are unemployed only in certain seasons'],
    answer: 0,
    subject: 'Economics',
    explain: 'Disguised unemployment occurs when more workers are engaged than are actually required.'
  }
]);
