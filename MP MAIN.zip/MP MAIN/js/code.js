'use strict';

const Code = (function(){

  const PROBLEMS = [
    {
      id: 'two-sum',
      title: 'Two Sum',
      difficulty: 'Easy',
      fn: 'twoSum',
      statement: 'Given an array of integers nums and an integer target, return the indices of the two numbers that add up to target. Each input has exactly one solution, and you may not use the same element twice. Return the indices in any order.',
      example: 'twoSum([2, 7, 11, 15], 9) → [0, 1]\nBecause nums[0] + nums[1] = 2 + 7 = 9.',
      starter: 'function twoSum(nums, target) {\n  return [];\n}',
      starters: {
        javascript: 'function twoSum(nums, target) {\n  return [];\n}',
        python: 'def twoSum(nums, target):\n    return []',
        c: '#include <stdio.h>\n\nint main(void) {\n    int n;\n    if (scanf("%d", &n) != 1) return 0;\n    int nums[100];\n    for (int i = 0; i < n; i++) scanf("%d", &nums[i]);\n    int target;\n    scanf("%d", &target);\n    printf("TODO\\n");\n    return 0;\n}',
        cpp: '#include <iostream>\n#include <vector>\nusing namespace std;\n\nint main() {\n    int n;\n    if (!(cin >> n)) return 0;\n    vector<int> nums(n);\n    for (int &x : nums) cin >> x;\n    int target;\n    cin >> target;\n    cout << "TODO\\n";\n    return 0;\n}',
        java: 'import java.util.*;\n\npublic class Main {\n    public static void main(String[] args) {\n        Scanner sc = new Scanner(System.in);\n        int n = sc.nextInt();\n        int[] nums = new int[n];\n        for (int i = 0; i < n; i++) nums[i] = sc.nextInt();\n        int target = sc.nextInt();\n        System.out.println("TODO");\n    }\n}'
      },
      io: { stdin: '4\n2 7 11 15\n9\n', expected: '0 1' },
      tests: [
        { name: 'Basic pair', args: [[2, 7, 11, 15], 9], expected: [0, 1], normalize: 'sort' },
        { name: 'Middle pair', args: [[3, 2, 4], 6], expected: [1, 2], normalize: 'sort' },
        { name: 'Duplicate values', args: [[3, 3], 6], expected: [0, 1], normalize: 'sort' },
        { name: 'Later pair', args: [[1, 5, 9, 3], 12], expected: [2, 3], normalize: 'sort' },
        { name: 'Negative numbers', args: [[-3, 4, 3, 90], 0], expected: [0, 2], normalize: 'sort' }
      ]
    },
    {
      id: 'reverse-string',
      title: 'Reverse String',
      difficulty: 'Easy',
      fn: 'reverseString',
      statement: 'Write a function that reverses a string. The input is always a string. Return the reversed string.',
      example: 'reverseString("hello") → "olleh"',
      starter: 'function reverseString(s) {\n  return s;\n}',
      starters: {
        javascript: 'function reverseString(s) {\n  return s;\n}',
        python: 'def reverseString(s):\n    return s',
        c: '#include <stdio.h>\n#include <string.h>\n\nint main(void) {\n    char s[256];\n    if (!fgets(s, sizeof s, stdin)) return 0;\n    s[strcspn(s, "\\r\\n")] = \'\\0\';\n    puts(s);\n    return 0;\n}',
        cpp: '#include <iostream>\n#include <string>\nusing namespace std;\n\nint main() {\n    string s;\n    if (!(cin >> s)) return 0;\n    cout << s << "\\n";\n    return 0;\n}',
        java: 'import java.util.*;\n\npublic class Main {\n    public static void main(String[] args) {\n        Scanner sc = new Scanner(System.in);\n        String s = sc.next();\n        System.out.println(s);\n    }\n}'
      },
      io: { stdin: 'hello\n', expected: 'olleh' },
      tests: [
        { name: 'Simple word', args: ['hello'], expected: 'olleh' },
        { name: 'Three letters', args: ['abc'], expected: 'cba' },
        { name: 'Empty string', args: [''], expected: '' },
        { name: 'Spaces included', args: ['A man'], expected: 'nam A' }
      ]
    },
    {
      id: 'valid-parentheses',
      title: 'Valid Parentheses',
      difficulty: 'Medium',
      fn: 'isValid',
      statement: 'Given a string containing only the characters (, ), {, }, [, and ], determine if the brackets are valid. Brackets must close in the correct order and every opening bracket must have a matching closing bracket.',
      example: 'isValid("()[]{}") → true\nisValid("([)]") → false',
      starter: 'function isValid(s) {\n  return false;\n}',
      starters: {
        javascript: 'function isValid(s) {\n  return false;\n}',
        python: 'def isValid(s):\n    return False',
        c: '#include <stdio.h>\n\nint main(void) {\n    char s[256];\n    if (scanf("%255s", s) != 1) return 0;\n    printf("false\\n");\n    return 0;\n}',
        cpp: '#include <iostream>\n#include <string>\nusing namespace std;\n\nint main() {\n    string s;\n    cin >> s;\n    cout << "false\\n";\n    return 0;\n}',
        java: 'import java.util.*;\n\npublic class Main {\n    public static void main(String[] args) {\n        Scanner sc = new Scanner(System.in);\n        String s = sc.next();\n        System.out.println("false");\n    }\n}'
      },
      io: { stdin: '()[]{}\n', expected: 'true' },
      tests: [
        { name: 'Single pair', args: ['()'], expected: true },
        { name: 'All bracket types', args: ['()[]{}'], expected: true },
        { name: 'Mismatched pair', args: ['(]'], expected: false },
        { name: 'Wrong nesting', args: ['([)]'], expected: false },
        { name: 'Nested braces', args: ['{[]}'], expected: true }
      ]
    },
    {
      id: 'fizzbuzz',
      title: 'FizzBuzz',
      difficulty: 'Easy',
      fn: 'fizzBuzz',
      statement: 'Given an integer n, return an array containing the numbers from 1 to n as strings, replacing multiples of 3 with "Fizz", multiples of 5 with "Buzz", and multiples of both with "FizzBuzz".',
      example: 'fizzBuzz(5) → ["1", "2", "Fizz", "4", "Buzz"]',
      starter: 'function fizzBuzz(n) {\n  return [];\n}',
      starters: {
        javascript: 'function fizzBuzz(n) {\n  return [];\n}',
        python: 'def fizzBuzz(n):\n    return []',
        c: '#include <stdio.h>\n\nint main(void) {\n    int n;\n    if (scanf("%d", &n) != 1) return 0;\n    printf("%d\\n", n);\n    return 0;\n}',
        cpp: '#include <iostream>\nusing namespace std;\n\nint main() {\n    int n;\n    cin >> n;\n    cout << n << "\\n";\n    return 0;\n}',
        java: 'import java.util.*;\n\npublic class Main {\n    public static void main(String[] args) {\n        Scanner sc = new Scanner(System.in);\n        int n = sc.nextInt();\n        System.out.println(n);\n    }\n}'
      },
      io: { stdin: '5\n', expected: '1 2 Fizz 4 Buzz' },
      tests: [
        { name: 'One number', args: [1], expected: ['1'] },
        { name: 'First Fizz', args: [3], expected: ['1', '2', 'Fizz'] },
        { name: 'Up to five', args: [5], expected: ['1', '2', 'Fizz', '4', 'Buzz'] },
        {
          name: 'FizzBuzz at fifteen',
          args: [15],
          expected: ['1', '2', 'Fizz', '4', 'Buzz', 'Fizz', '7', '8', 'Fizz', 'Buzz', '11', 'Fizz', '13', '14', 'FizzBuzz']
        }
      ]
    },
    {
      id: 'palindrome-number',
      title: 'Palindrome Number',
      difficulty: 'Easy',
      fn: 'isPalindrome',
      statement: 'Given an integer x, return true if x is a palindrome, and false otherwise. Negative numbers are not palindromes.',
      example: 'isPalindrome(121) → true\nisPalindrome(-121) → false',
      starter: 'function isPalindrome(x) {\n  return false;\n}',
      starters: {
        javascript: 'function isPalindrome(x) {\n  return false;\n}',
        python: 'def isPalindrome(x):\n    return False',
        c: '#include <stdio.h>\n\nint main(void) {\n    int x;\n    if (scanf("%d", &x) != 1) return 0;\n    printf("false\\n");\n    return 0;\n}',
        cpp: '#include <iostream>\nusing namespace std;\n\nint main() {\n    int x;\n    cin >> x;\n    cout << "false\\n";\n    return 0;\n}',
        java: 'import java.util.*;\n\npublic class Main {\n    public static void main(String[] args) {\n        Scanner sc = new Scanner(System.in);\n        int x = sc.nextInt();\n        System.out.println("false");\n    }\n}'
      },
      io: { stdin: '121\n', expected: 'true' },
      tests: [
        { name: 'Three digits', args: [121], expected: true },
        { name: 'Negative number', args: [-121], expected: false },
        { name: 'Trailing zero', args: [10], expected: false },
        { name: 'Five digits', args: [12321], expected: true },
        { name: 'Zero', args: [0], expected: true }
      ]
    },
    {
      id: 'max-subarray',
      title: 'Max Subarray',
      difficulty: 'Medium',
      fn: 'maxSubarray',
      statement: 'Given an integer array nums, find the contiguous subarray with the largest sum and return that sum.',
      example: 'maxSubarray([-2, 1, -3, 4, -1, 2, 1, -5, 4]) → 6\nThe subarray [4, -1, 2, 1] has the largest sum.',
      starter: 'function maxSubarray(nums) {\n  return 0;\n}',
      starters: {
        javascript: 'function maxSubarray(nums) {\n  return 0;\n}',
        python: 'def maxSubarray(nums):\n    return 0',
        c: '#include <stdio.h>\n\nint main(void) {\n    int n;\n    if (scanf("%d", &n) != 1) return 0;\n    int nums[1000];\n    for (int i = 0; i < n; i++) scanf("%d", &nums[i]);\n    printf("0\\n");\n    return 0;\n}',
        cpp: '#include <iostream>\n#include <vector>\nusing namespace std;\n\nint main() {\n    int n;\n    cin >> n;\n    vector<int> nums(n);\n    for (int &x : nums) cin >> x;\n    cout << 0 << "\\n";\n    return 0;\n}',
        java: 'import java.util.*;\n\npublic class Main {\n    public static void main(String[] args) {\n        Scanner sc = new Scanner(System.in);\n        int n = sc.nextInt();\n        int[] nums = new int[n];\n        for (int i = 0; i < n; i++) nums[i] = sc.nextInt();\n        System.out.println(0);\n    }\n}'
      },
      io: { stdin: '9\n-2 1 -3 4 -1 2 1 -5 4\n', expected: '6' },
      tests: [
        { name: 'Mixed values', args: [[-2, 1, -3, 4, -1, 2, 1, -5, 4]], expected: 6 },
        { name: 'Single value', args: [[1]], expected: 1 },
        { name: 'All negative', args: [[-2, -1, -3]], expected: -1 },
        { name: 'Large positive run', args: [[5, 4, -1, 7, 8]], expected: 23 }
      ]
    },
    {
      id: 'merge-sorted-arrays',
      title: 'Merge Sorted Arrays',
      difficulty: 'Medium',
      fn: 'mergeSorted',
      statement: 'Given two sorted integer arrays a and b, merge them into one sorted array and return it. Do not modify the input arrays.',
      example: 'mergeSorted([1, 2, 3], [2, 5, 6]) → [1, 2, 2, 3, 5, 6]',
      starter: 'function mergeSorted(a, b) {\n  return [];\n}',
      starters: {
        javascript: 'function mergeSorted(a, b) {\n  return [];\n}',
        python: 'def mergeSorted(a, b):\n    return []',
        c: '#include <stdio.h>\n\nint main(void) {\n    int n, m;\n    if (scanf("%d", &n) != 1) return 0;\n    int a[100], b[100];\n    for (int i = 0; i < n; i++) scanf("%d", &a[i]);\n    scanf("%d", &m);\n    for (int i = 0; i < m; i++) scanf("%d", &b[i]);\n    printf("\\n");\n    return 0;\n}',
        cpp: '#include <iostream>\n#include <vector>\nusing namespace std;\n\nint main() {\n    int n, m;\n    cin >> n;\n    vector<int> a(n);\n    for (int &x : a) cin >> x;\n    cin >> m;\n    vector<int> b(m);\n    for (int &x : b) cin >> x;\n    cout << "\\n";\n    return 0;\n}',
        java: 'import java.util.*;\n\npublic class Main {\n    public static void main(String[] args) {\n        Scanner sc = new Scanner(System.in);\n        int n = sc.nextInt();\n        int[] a = new int[n];\n        for (int i = 0; i < n; i++) a[i] = sc.nextInt();\n        int m = sc.nextInt();\n        int[] b = new int[m];\n        for (int i = 0; i < m; i++) b[i] = sc.nextInt();\n        System.out.println();\n    }\n}'
      },
      io: { stdin: '3\n1 2 3\n3\n2 5 6\n', expected: '1 2 2 3 5 6' },
      tests: [
        { name: 'Two sorted arrays', args: [[1, 2, 3], [2, 5, 6]], expected: [1, 2, 2, 3, 5, 6] },
        { name: 'Empty first array', args: [[], [1]], expected: [1] },
        { name: 'Empty second array', args: [[1, 3, 5], []], expected: [1, 3, 5] },
        { name: 'Negative numbers', args: [[-3, -1], [-2, 4]], expected: [-3, -2, -1, 4] }
      ]
    },
    {
      id: 'fibonacci',
      title: 'Fibonacci',
      difficulty: 'Hard',
      fn: 'fib',
      statement: 'Given a non-negative integer n, return the nth Fibonacci number. fib(0) = 0 and fib(1) = 1.',
      example: 'fib(7) → 13',
      starter: 'function fib(n) {\n  return 0;\n}',
      starters: {
        javascript: 'function fib(n) {\n  return 0;\n}',
        python: 'def fib(n):\n    return 0',
        c: '#include <stdio.h>\n\nint main(void) {\n    int n;\n    if (scanf("%d", &n) != 1) return 0;\n    printf("0\\n");\n    return 0;\n}',
        cpp: '#include <iostream>\nusing namespace std;\n\nint main() {\n    int n;\n    cin >> n;\n    cout << 0 << "\\n";\n    return 0;\n}',
        java: 'import java.util.*;\n\npublic class Main {\n    public static void main(String[] args) {\n        Scanner sc = new Scanner(System.in);\n        int n = sc.nextInt();\n        System.out.println(0);\n    }\n}'
      },
      io: { stdin: '7\n', expected: '13' },
      tests: [
        { name: 'Zero', args: [0], expected: 0 },
        { name: 'One', args: [1], expected: 1 },
        { name: 'Seven', args: [7], expected: 13 },
        { name: 'Ten', args: [10], expected: 55 },
        { name: 'Twenty', args: [20], expected: 6765 }
      ]
    }
  ];

  const LANGUAGE_GROUPS = [
    {
      label: 'Runs in browser',
      options: [
        { id: 'javascript', label: 'JavaScript' },
        { id: 'python', label: 'Python' }
      ]
    },
    {
      label: 'Online runner',
      options: [
        { id: 'c', label: 'C' },
        { id: 'cpp', label: 'C++' },
        { id: 'java', label: 'Java' }
      ]
    }
  ];
  const LANGUAGES = [];
  LANGUAGE_GROUPS.forEach(group => group.options.forEach(lang => LANGUAGES.push(lang)));
  const LANG_IDS = LANGUAGES.map(lang => lang.id);
  const ONLINE_IDS = ['c', 'cpp', 'java'];
  const storedLang = Store.get('codelang', 'javascript');
  let selectedLang = LANG_IDS.includes(storedLang) ? storedLang : 'javascript';
  let selectedId = PROBLEMS[0].id;
  let bound = false;
  let runToken = 0;
  let onlineConsent = false;
  let consentAction = null;
  let consentSelect = null;
  let editingCustomId = null;

  const container = () => $('#practice-code');
  const isOnlineLang = lang => ONLINE_IDS.includes(lang);
  const isCustomId = id => typeof id === 'string' && id.startsWith('c-');
  const isCustomProblem = problem => !!(problem && isCustomId(problem.id));
  const runnerUrl = () => {
    const stored = Store.get('runnerurl', '');
    return typeof stored === 'string' ? stored.trim() : '';
  };

  function customProblems(){
    const list = Store.get('codecustom', []);
    return Array.isArray(list)
      ? list.filter(p => p && typeof p === 'object' && !Array.isArray(p) && isCustomId(p.id))
      : [];
  }

  function allProblems(){
    return PROBLEMS.concat(customProblems());
  }

  function byId(id){
    return allProblems().find(p => p.id === id) || PROBLEMS[0];
  }

  function newCustomId(){
    let id;
    do{
      id = 'c-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 7);
    }while(allProblems().some(p => p.id === id));
    return id;
  }

  function pythonStarter(fn){
    return 'def ' + fn + '(*args):\n    return None';
  }

  function cleanTest(raw){
    if(!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
    const name = typeof raw.name === 'string' ? raw.name.trim().slice(0, 80) : '';
    if(!name || !Array.isArray(raw.args) || !Object.prototype.hasOwnProperty.call(raw, 'expected')) return null;
    try{
      return {
        name,
        args: JSON.parse(JSON.stringify(raw.args)),
        expected: JSON.parse(JSON.stringify(raw.expected))
      };
    }catch(e){
      return null;
    }
  }

  function cleanCustomProblem(raw, usedIds){
    if(!raw || typeof raw !== 'object' || Array.isArray(raw)) return null;
    const title = typeof raw.title === 'string' ? raw.title.trim().slice(0, 80) : '';
    const statement = typeof raw.statement === 'string' ? raw.statement.trim().slice(0, 1200) : '';
    const fn = typeof raw.fn === 'string' ? raw.fn.trim().slice(0, 60) : '';
    const starter = typeof raw.starter === 'string' ? raw.starter :
      (raw.starters && typeof raw.starters.javascript === 'string' ? raw.starters.javascript : '');
    const difficulty = ['Easy', 'Medium', 'Hard'].includes(raw.difficulty) ? raw.difficulty : 'Easy';
    const tests = Array.isArray(raw.tests) ? raw.tests.map(cleanTest).filter(Boolean) : [];
    if(!title || !statement || !starter.trim() || !/^[A-Za-z_][A-Za-z0-9_]*$/.test(fn) || tests.length < 2){
      return null;
    }

    let id = typeof raw.id === 'string' && /^c-[A-Za-z0-9_-]+$/.test(raw.id) ? raw.id : '';
    if(!id || (usedIds && usedIds.has(id))){
      do{
        id = newCustomId();
      }while(usedIds && usedIds.has(id));
    }
    if(usedIds) usedIds.add(id);

    return {
      id,
      title,
      difficulty,
      statement,
      fn,
      starter,
      starters: { javascript: starter, python: pythonStarter(fn) },
      tests
    };
  }

  function drafts(){
    const d = Store.get('codedrafts', {});
    return d && typeof d === 'object' && !Array.isArray(d) ? d : {};
  }

  function starterFor(id, lang){
    const problem = byId(id);
    if(problem.starters && typeof problem.starters[lang] === 'string') return problem.starters[lang];
    if(isCustomProblem(problem) && lang === 'python' && typeof problem.fn === 'string') return pythonStarter(problem.fn);
    return typeof problem.starter === 'string' ? problem.starter : '';
  }

  function draftFor(id, lang){
    const d = drafts();
    const entry = d[id];
    if(entry && typeof entry === 'object' && !Array.isArray(entry)){
      return typeof entry[lang] === 'string' ? entry[lang] : starterFor(id, lang);
    }
    if(lang === 'javascript' && typeof entry === 'string') return entry;
    return starterFor(id, lang);
  }

  function saveDraft(id, lang, code){
    const d = drafts();
    let entry = d[id];
    if(!entry || typeof entry !== 'object' || Array.isArray(entry)){
      entry = typeof entry === 'string' ? { javascript: entry } : {};
    }
    entry[lang] = String(code);
    d[id] = entry;
    Store.set('codedrafts', d);
  }

  function solvedList(){
    const list = Store.get('codesolved', []);
    return Array.isArray(list) ? list.filter(id => typeof id === 'string') : [];
  }

  function markSolved(id){
    const list = solvedList();
    if(!list.includes(id)){
      list.push(id);
      Store.set('codesolved', list);
    }
  }

  function bind(){
    const box = container();
    if(!box || bound) return;
    bound = true;
    bindConsent();
    box.addEventListener('click', handleClick);
    box.addEventListener('input', handleInput);
    box.addEventListener('change', handleChange);
    box.addEventListener('submit', handleSubmit);
    box.addEventListener('keydown', handleKeydown);
  }

  function bindConsent(){
    const modal = $('#online-consent-modal');
    if(!modal || modal.dataset.bound) return;
    modal.dataset.bound = '1';
    const allow = $('#online-consent-allow');
    const cancel = $('#online-consent-cancel');
    if(allow) allow.addEventListener('click', () => closeConsent(true));
    if(cancel) cancel.addEventListener('click', () => closeConsent(false));
    modal.addEventListener('click', e => { if(e.target === modal) closeConsent(false); });
    document.addEventListener('keydown', e => {
      if(e.key === 'Escape' && modal.style.display !== 'none') closeConsent(false);
    });
  }

  function askConsent(action, select){
    const modal = $('#online-consent-modal');
    if(!modal){
      toast('Online runner consent is required', 'warn');
      if(select) select.value = selectedLang;
      return;
    }
    consentAction = action;
    consentSelect = select || null;
    modal.style.display = 'flex';
  }

  function closeConsent(allow){
    const modal = $('#online-consent-modal');
    if(modal) modal.style.display = 'none';
    const action = consentAction;
    const select = consentSelect;
    consentAction = null;
    consentSelect = null;
    if(allow){
      onlineConsent = true;
      toast('Online runner enabled for this session', 'warn');
      if(action) action();
    }else if(select && select.isConnected){
      select.value = selectedLang;
    }
  }

  function toggleOnlineConsent(){
    onlineConsent = !onlineConsent;
    render();
    toast(onlineConsent ? 'Online runner enabled for this session' : 'Online runner disabled', onlineConsent ? 'warn' : 'info');
  }

  function applyLanguage(lang){
    saveCurrentDraft();
    stopRun();
    selectedLang = isCustomId(selectedId) && isOnlineLang(lang) ? 'javascript' : lang;
    Store.set('codelang', selectedLang);
    render();
  }

  function handleClick(e){
    const edit = e.target.closest('[data-code-edit-custom]');
    if(edit){ editCustomProblem(edit.dataset.codeEditCustom); return; }
    const del = e.target.closest('[data-code-delete-custom]');
    if(del){ deleteCustomProblem(del.dataset.codeDeleteCustom); return; }
    if(e.target.closest('[data-code-custom-cancel]')){ editingCustomId = null; render(); return; }
    if(e.target.closest('[data-code-test-add]')){ addTestRow(e.target); return; }
    if(e.target.closest('[data-code-test-remove]')){ removeTestRow(e.target); return; }
    if(e.target.closest('[data-code-export]')){ exportCustomProblems(); return; }
    if(e.target.closest('[data-code-import]')){
      const form = e.target.closest('[data-code-custom-form]');
      const input = form ? $('[data-code-import-file]', form) : null;
      if(input) input.click();
      return;
    }
    const prob = e.target.closest('[data-code-problem]');
    if(prob){ selectProblem(prob.dataset.codeProblem); return; }
    if(e.target.closest('[data-code-online-toggle]')){ toggleOnlineConsent(); return; }
    if(e.target.closest('[data-code-run]')){ runAll(false); return; }
    if(e.target.closest('[data-code-submit]')){ runAll(true); return; }
    if(e.target.closest('[data-code-reset]')){ resetCode(); }
  }

  function handleSubmit(e){
    const form = e.target.closest('[data-code-custom-form]');
    if(!form) return;
    e.preventDefault();
    saveCustomProblem(form);
  }

  function handleInput(e){
    if(e.target.id !== 'code-editor') return;
    saveDraft(selectedId, selectedLang, e.target.value);
  }

  function handleKeydown(e){
    if(e.target.id !== 'code-editor' || e.key !== 'Tab') return;
    e.preventDefault();
    const ta = e.target;
    const start = ta.selectionStart;
    const end = ta.selectionEnd;
    ta.value = ta.value.slice(0, start) + '  ' + ta.value.slice(end);
    ta.selectionStart = ta.selectionEnd = start + 2;
    saveDraft(selectedId, selectedLang, ta.value);
  }

  function handleChange(e){
    if(e.target.matches('[data-code-import-file]')){
      const file = e.target.files && e.target.files[0];
      importCustomProblems(file, e.target);
      return;
    }
    if(e.target.id !== 'code-language') return;
    const lang = e.target.value;
    if(!LANG_IDS.includes(lang) || lang === selectedLang) return;
    if(isCustomProblem(byId(selectedId)) && isOnlineLang(lang)){
      e.target.value = selectedLang;
      toast('Custom problems run in JavaScript or Python', 'warn');
      return;
    }
    if(isOnlineLang(lang) && !onlineConsent){
      askConsent(() => applyLanguage(lang), e.target);
      return;
    }
    applyLanguage(lang);
  }

  function problemButtonHTML(p, solved){
    const done = solved.includes(p.id);
    return '<button class="code-problem' + (p.id === selectedId ? ' active' : '') +
      '" data-code-problem="' + escapeHTML(p.id) + '" type="button">' +
      '<span class="code-problem-main"><span class="code-problem-title">' + escapeHTML(p.title) +
        '</span><span class="diff diff-' + p.difficulty.toLowerCase() + '">' + escapeHTML(p.difficulty) + '</span></span>' +
      '<span class="code-problem-side">' +
        (done ? '<i class="fa-solid fa-circle-check ok" title="Solved"></i>' : '') +
      '</span></button>';
  }

  function customProblemRowHTML(p, solved){
    return '<div class="code-custom-row">' + problemButtonHTML(p, solved) +
      '<div class="code-custom-actions">' +
        '<button class="icon-btn small" data-code-edit-custom="' + escapeHTML(p.id) +
          '" type="button" title="Edit problem" aria-label="Edit ' + escapeHTML(p.title) + '">' +
          '<i class="fa-solid fa-pen"></i></button>' +
        '<button class="icon-btn small danger" data-code-delete-custom="' + escapeHTML(p.id) +
          '" type="button" title="Delete problem" aria-label="Delete ' + escapeHTML(p.title) + '">' +
          '<i class="fa-solid fa-trash"></i></button>' +
      '</div></div>';
  }

  function testRowHTML(test){
    const name = test && typeof test.name === 'string' ? test.name : '';
    const argsText = test && Array.isArray(test.args) ? jsonText(test.args) : '';
    const expectedText = test && Object.prototype.hasOwnProperty.call(test, 'expected') ? jsonText(test.expected) : '';
    return '<div class="code-test-row" data-code-test-row>' +
      '<label class="quiz-field"><span class="label">Name</span>' +
        '<input type="text" data-code-test-name maxlength="80" autocomplete="off" value="' +
          escapeHTML(name) + '" placeholder="Example test"></label>' +
      '<label class="quiz-field"><span class="label">Arguments (JSON array)</span>' +
        '<input type="text" data-code-test-args autocomplete="off" value="' +
          escapeHTML(argsText) + '" placeholder="[1, 2]"></label>' +
      '<label class="quiz-field"><span class="label">Expected (JSON)</span>' +
        '<input type="text" data-code-test-expected autocomplete="off" value="' +
          escapeHTML(expectedText) + '" placeholder="3"></label>' +
      '<button class="icon-btn small danger" data-code-test-remove type="button" title="Remove test" aria-label="Remove test">' +
        '<i class="fa-solid fa-xmark"></i></button>' +
    '</div>';
  }

  function customFormHTML(){
    const editing = editingCustomId ? customProblems().find(p => p.id === editingCustomId) : null;
    if(editingCustomId && !editing) editingCustomId = null;
    const data = editing || { difficulty: 'Easy', tests: [null, null] };
    const starter = editing
      ? (editing.starters && typeof editing.starters.javascript === 'string'
        ? editing.starters.javascript
        : (typeof editing.starter === 'string' ? editing.starter : ''))
      : '';
    const tests = Array.isArray(data.tests) && data.tests.length ? data.tests : [null, null];
    const difficulty = ['Easy', 'Medium', 'Hard'].map(level =>
      '<option value="' + level + '"' + (data.difficulty === level ? ' selected' : '') + '>' + level + '</option>'
    ).join('');

    return '<details class="quiz-add code-custom-add"' + (editing ? ' open' : '') + ' data-code-custom-add>' +
      '<summary><i class="fa-solid fa-' + (editing ? 'pen' : 'plus') + '"></i>' +
        (editing ? 'Edit my problem' : 'Create my own problem') + '</summary>' +
      '<form class="card pad quiz-add-body" data-code-custom-form novalidate>' +
        '<div class="quiz-form-grid">' +
          '<label class="quiz-field wide"><span class="label">Title</span>' +
            '<input type="text" name="title" maxlength="80" autocomplete="off" value="' +
              escapeHTML(data.title || '') + '"></label>' +
          '<label class="quiz-field"><span class="label">Difficulty</span>' +
            '<select name="difficulty">' + difficulty + '</select></label>' +
          '<label class="quiz-field"><span class="label">Function name</span>' +
            '<input type="text" name="fn" maxlength="60" autocomplete="off" value="' +
              escapeHTML(data.fn || '') + '" placeholder="myFunction"></label>' +
          '<label class="quiz-field wide"><span class="label">Statement</span>' +
            '<textarea name="statement" rows="3" maxlength="1200">' +
              escapeHTML(data.statement || '') + '</textarea></label>' +
          '<label class="quiz-field wide"><span class="label">JavaScript starter code</span>' +
            '<textarea name="starter" class="code-custom-starter" rows="7" spellcheck="false" wrap="off">' +
              escapeHTML(starter) + '</textarea></label>' +
        '</div>' +
        '<div class="code-tests-head"><p class="label">Tests</p>' +
          '<button class="btn btn-ghost" data-code-test-add type="button">' +
            '<i class="fa-solid fa-plus"></i>Add test</button></div>' +
        '<div class="code-test-rows" data-code-test-rows>' +
          tests.map(testRowHTML).join('') + '</div>' +
        '<div class="quiz-form-actions">' +
          '<button class="btn btn-ghost" data-code-export type="button">' +
            '<i class="fa-solid fa-file-export"></i>Export JSON</button>' +
          '<button class="btn btn-ghost" data-code-import type="button">' +
            '<i class="fa-solid fa-file-import"></i>Import JSON</button>' +
          '<input type="file" accept="application/json,.json" data-code-import-file hidden>' +
          (editing ? '<button class="btn btn-ghost" data-code-custom-cancel type="button">' +
            '<i class="fa-solid fa-xmark"></i>Cancel</button>' : '') +
          '<button class="btn btn-primary" type="submit">' +
            '<i class="fa-solid fa-floppy-disk"></i>' +
            (editing ? 'Update problem' : 'Save problem') + '</button>' +
        '</div>' +
      '</form>' +
    '</details>';
  }

  function addTestRow(target){
    const form = target.closest('[data-code-custom-form]');
    const rows = form ? $('[data-code-test-rows]', form) : null;
    if(rows) rows.insertAdjacentHTML('beforeend', testRowHTML(null));
  }

  function removeTestRow(target){
    const form = target.closest('[data-code-custom-form]');
    const row = target.closest('[data-code-test-row]');
    if(!form || !row) return;
    if($$('[data-code-test-row]', form).length <= 2){
      toast('Keep at least two tests', 'warn');
      return;
    }
    row.remove();
  }

  function saveCustomProblem(form){
    const data = new FormData(form);
    const title = String(data.get('title') || '').trim();
    const difficulty = String(data.get('difficulty') || 'Easy');
    const statement = String(data.get('statement') || '').trim();
    const fn = String(data.get('fn') || '').trim();
    const starter = String(data.get('starter') || '');

    if(!title || !statement || !fn || !starter.trim()){
      toast('Fill in the title, function name, statement and starter code', 'warn');
      return;
    }
    if(!/^[A-Za-z_][A-Za-z0-9_]*$/.test(fn)){
      toast('Function name must be a valid identifier', 'warn');
      return;
    }
    if(!['Easy', 'Medium', 'Hard'].includes(difficulty)) difficulty = 'Easy';

    const rows = $$('[data-code-test-row]', form);
    if(rows.length < 2){
      toast('Add at least two tests', 'warn');
      return;
    }

    const tests = [];
    for(let i = 0; i < rows.length; i++){
      const row = rows[i];
      const nameInput = $('[data-code-test-name]', row);
      const argsInput = $('[data-code-test-args]', row);
      const expectedInput = $('[data-code-test-expected]', row);
      const name = String(nameInput && nameInput.value || '').trim();
      const argsText = String(argsInput && argsInput.value || '').trim();
      const expectedText = String(expectedInput && expectedInput.value || '').trim();
      if(!name){
        toast('Give test ' + (i + 1) + ' a name', 'warn');
        return;
      }
      let args, expected;
      try{
        args = JSON.parse(argsText);
      }catch(e){
        toast('Test ' + (i + 1) + ' arguments must be valid JSON', 'warn');
        return;
      }
      if(!Array.isArray(args)){
        toast('Test ' + (i + 1) + ' arguments must be a JSON array', 'warn');
        return;
      }
      try{
        expected = JSON.parse(expectedText);
      }catch(e){
        toast('Test ' + (i + 1) + ' expected value must be valid JSON', 'warn');
        return;
      }
      tests.push({ name, args, expected });
    }

    const existing = customProblems();
    const current = editingCustomId ? existing.find(p => p.id === editingCustomId) : null;
    const item = {
      id: current ? current.id : newCustomId(),
      title,
      difficulty,
      statement,
      fn,
      starter,
      starters: { javascript: starter, python: pythonStarter(fn) },
      tests
    };

    saveCurrentDraft();
    stopRun();
    if(current){
      Store.set('codecustom', existing.map(p => p.id === current.id ? item : p));
      toast('Custom problem updated', 'success');
    }else{
      Store.set('codecustom', existing.concat(item));
      toast('Custom problem created', 'success');
    }

    selectedId = item.id;
    if(isOnlineLang(selectedLang)){
      selectedLang = 'javascript';
      Store.set('codelang', selectedLang);
    }
    editingCustomId = null;
    render();
  }

  function editCustomProblem(id){
    if(!customProblems().some(p => p.id === id)) return;
    editingCustomId = id;
    render();
    const form = $('[data-code-custom-form]', container());
    const title = form ? $('[name="title"]', form) : null;
    if(title) title.focus();
  }

  function deleteCustomProblem(id){
    const existing = customProblems();
    const next = existing.filter(p => p.id !== id);
    if(next.length === existing.length) return;

    Store.set('codecustom', next);
    const solved = solvedList().filter(item => item !== id);
    Store.set('codesolved', solved);
    const d = drafts();
    if(Object.prototype.hasOwnProperty.call(d, id)){
      delete d[id];
      Store.set('codedrafts', d);
    }
    if(editingCustomId === id) editingCustomId = null;
    if(selectedId === id){
      stopRun();
      selectedId = next.length ? next[0].id : PROBLEMS[0].id;
    }
    render();
    toast('Custom problem deleted', 'success');
  }

  function exportCustomProblems(){
    const list = customProblems();
    if(!list.length){
      toast('No custom problems to export', 'warn');
      return;
    }
    const output = list.map(p => ({
      id: p.id,
      title: p.title,
      difficulty: p.difficulty,
      statement: p.statement,
      fn: p.fn,
      starter: p.starters && typeof p.starters.javascript === 'string'
        ? p.starters.javascript
        : (p.starter || ''),
      tests: p.tests
    }));
    const blob = new Blob([JSON.stringify(output, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'focusflow-code-problems.json';
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 0);
    toast('Exported ' + list.length + ' custom problem' + (list.length === 1 ? '' : 's'), 'success');
  }

  function importCustomProblems(file, input){
    if(!file){
      if(input) input.value = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      let data;
      try{
        data = JSON.parse(String(reader.result || '').replace(/^\uFEFF/, ''));
      }catch(e){
        if(input) input.value = '';
        toast('That file is not valid JSON', 'warn');
        return;
      }
      const raw = Array.isArray(data) ? data : (data && Array.isArray(data.problems) ? data.problems : null);
      if(!raw){
        if(input) input.value = '';
        toast('No custom problems found in that file', 'warn');
        return;
      }
      const used = new Set(allProblems().map(p => p.id));
      const imported = raw.map(item => cleanCustomProblem(item, used)).filter(Boolean);
      if(!imported.length){
        if(input) input.value = '';
        toast('No valid custom problems found', 'warn');
        return;
      }
      Store.set('codecustom', customProblems().concat(imported));
      editingCustomId = null;
      if(input) input.value = '';
      render();
      toast('Imported ' + imported.length + ' custom problem' + (imported.length === 1 ? '' : 's'), 'success');
    };
    reader.onerror = () => {
      if(input) input.value = '';
      toast('Could not read that file', 'warn');
    };
    reader.readAsText(file);
  }

  function problemListHTML(){
    const solved = solvedList();
    const custom = customProblems();
    return PROBLEMS.map(p => problemButtonHTML(p, solved)).join('') +
      '<div class="code-problem-group"><p class="label">My problems</p>' +
        (custom.length
          ? custom.map(p => customProblemRowHTML(p, solved)).join('')
          : '<p class="sub code-problem-empty">No custom problems yet</p>') +
      '</div>';
  }

  function renderProblemList(){
    const box = container();
    if(!box) return;
    const list = $('.code-problem-list', box);
    if(list) list.innerHTML = problemListHTML();
    const count = $('#code-solved-count', box);
    if(count) count.textContent = solvedList().length + '/' + allProblems().length;
  }

  function setResults(html){
    const panel = $('#code-results', container());
    if(panel) panel.innerHTML = html;
  }

  function emptyResults(){
    return '<div class="empty"><i class="fa-solid fa-flask"></i><p>Run your code to see test results</p></div>';
  }

  function render(){
    const box = container();
    if(!box) return;
    const problem = byId(selectedId);
    const custom = isCustomProblem(problem);
    const total = allProblems().length;
    const solved = solvedList().length;

    box.innerHTML = customFormHTML() + '<div class="code-shell">' +
      '<aside class="card pad code-list">' +
        '<div class="rail-head"><p class="label">Problems</p><span class="sub mono" id="code-solved-count">' +
          solved + '/' + total + '</span></div>' +
        '<div class="code-problem-list">' + problemListHTML() + '</div>' +
      '</aside>' +
      '<section class="card pad code-main">' +
        '<div class="rail-head"><div><p class="label">' + escapeHTML(problem.difficulty) +
          '</p><h3 class="code-title">' + escapeHTML(problem.title) + '</h3></div>' +
          '<span class="sub mono">' + escapeHTML(problem.fn) + '()</span></div>' +
        '<p class="code-statement">' + escapeHTML(problem.statement) + '</p>' +
        (problem.example
          ? '<div class="code-example-wrap"><p class="label">Example</p><pre class="code-example">' +
            escapeHTML(problem.example) + '</pre></div>'
          : '') +
        '<div class="code-editor-head"><label class="label" for="code-editor">Solution</label>' +
          '<label class="sub code-language">Language <select id="code-language">' +
            LANGUAGE_GROUPS.map(group => '<optgroup label="' + escapeHTML(group.label) + '">' +
              group.options.map(lang => {
                const locked = isOnlineLang(lang.id) && !onlineConsent;
                const blocked = custom && isOnlineLang(lang.id);
                return '<option value="' + escapeHTML(lang.id) + '"' +
                  (lang.id === selectedLang ? ' selected' : '') +
                  (blocked ? ' disabled' : '') + '>' +
                  escapeHTML((locked ? '\u{1F512} ' : '') + lang.label) + '</option>';
              }).join('') +
            '</optgroup>').join('') +
          '</select></label></div>' +
        (custom ? '<p class="sub code-custom-hint">Custom problems run in JavaScript or Python only.</p>' : '') +
        '<textarea id="code-editor" class="code-editor" spellcheck="false" autocomplete="off" autocapitalize="off" wrap="off">' +
          escapeHTML(draftFor(problem.id, selectedLang)) + '</textarea>' +
        '<div class="code-actions">' +
          '<button class="btn btn-primary" data-code-run type="button"><i class="fa-solid fa-play"></i>Run</button>' +
          '<button class="btn btn-ghost" data-code-submit type="button"><i class="fa-solid fa-check"></i>Submit</button>' +
          '<button class="btn btn-ghost" data-code-reset type="button"><i class="fa-solid fa-rotate-left"></i>Reset</button>' +
        '</div>' +
        '<details class="code-online-settings">' +
          '<summary class="sub"><i class="fa-solid fa-gear"></i> Runner settings</summary>' +
          '<div class="code-online-row">' +
            '<div><p class="label">Online runner</p><p class="sub">Sends your code to a remote server. Off by default; consent lasts this session only.</p></div>' +
            '<button class="ch-toggle' + (onlineConsent ? ' on' : '') + '" data-code-online-toggle type="button" aria-pressed="' + onlineConsent + '" aria-label="Toggle online runner"></button>' +
          '</div>' +
        '</details>' +
        '<div class="code-results" id="code-results">' + emptyResults() + '</div>' +
      '</section>' +
    '</div>';
  }

  function saveCurrentDraft(){
    const ta = $('#code-editor', container());
    if(ta) saveDraft(selectedId, selectedLang, ta.value);
  }

  function selectProblem(id){
    if(id === selectedId || !allProblems().some(p => p.id === id)) return;
    saveCurrentDraft();
    stopRun();
    selectedId = id;
    if(isCustomId(id) && isOnlineLang(selectedLang)){
      selectedLang = 'javascript';
      Store.set('codelang', selectedLang);
    }
    render();
  }

  function resetCode(){
    const problem = byId(selectedId);
    const ta = $('#code-editor', container());
    if(!ta) return;
    stopRun();
    ta.value = starterFor(problem.id, selectedLang);
    saveDraft(problem.id, selectedLang, ta.value);
    setResults(emptyResults());
    ta.focus();
  }

  function stopRun(){
    runToken += 1;
    if(window.Runners) Runners.cancel();
  }

  function jsonText(value){
    try{
      if(typeof value === 'undefined') return 'undefined';
      return JSON.stringify(value);
    }catch(e){
      return String(value);
    }
  }

  function errorText(err){
    return err && err.message ? String(err.message) : String(err || 'Unknown error');
  }

  function showFatal(message, ms){
    setResults('<div class="rail-head"><p class="label">Results</p><span class="sub mono danger">Error</span></div>' +
      '<div class="code-result fail"><div class="code-result-head">' +
        '<span class="code-result-name"><i class="fa-solid fa-circle-xmark"></i>Error</span>' +
        '<span class="sub mono">' + Math.round(ms || 0) + ' ms</span></div>' +
      '<div class="code-result-detail"><span class="code-result-error">' + escapeHTML(String(message)) +
      '</span></div></div>');
  }

  function showTimeout(ms){
    const limit = Math.max(0, Math.round(Number(ms) || 0));
    const seconds = limit / 1000;
    const label = seconds === 1 ? 'second' : 'seconds';
    setResults('<div class="rail-head"><p class="label">Results</p><span class="sub mono danger">Time limit exceeded</span></div>' +
      '<div class="code-result fail"><div class="code-result-head">' +
        '<span class="code-result-name"><i class="fa-solid fa-circle-xmark"></i>Time limit exceeded</span>' +
        '<span class="sub mono">' + limit + ' ms</span></div>' +
      '<div class="code-result-detail">Your code ran for more than ' + seconds + ' ' + label + ' and was stopped.</div></div>');
    toast('Time limit exceeded', 'warn');
  }

  function showResults(problem, results, totalMs, submit){
    if(!Array.isArray(results) || !results.length){
      showFatal('No test results were returned', totalMs);
      return;
    }

    const passed = results.filter(r => r && r.pass).length;
    const allPassed = passed === results.length;
    const rows = results.map((r, i) => {
      const ok = !!(r && r.pass);
      const name = r && r.name ? String(r.name) : 'Test ' + (i + 1);
      const ms = Math.max(0, Math.round(Number(r && r.ms) || 0));
      const err = r && r.error ? String(r.error) : '';
      let detail = '';
      if(err){
        detail = '<div class="code-result-detail"><span class="code-result-error">' + escapeHTML(err) + '</span></div>';
      }else if(!ok){
        detail = '<div class="code-result-detail">Expected ' + escapeHTML(jsonText(r && r.expected)) +
          ' · Got ' + escapeHTML(jsonText(r && r.got)) + '</div>';
      }
      return '<div class="code-result ' + (ok ? 'pass' : 'fail') + '">' +
        '<div class="code-result-head"><span class="code-result-name">' +
          '<i class="fa-solid ' + (ok ? 'fa-circle-check' : 'fa-circle-xmark') + '"></i>' +
          escapeHTML(name) + '</span><span class="sub mono">' + ms + ' ms</span></div>' +
        detail + '</div>';
    }).join('');

    if(submit && allPassed){
      markSolved(problem.id);
      renderProblemList();
      toast('All tests passed — problem solved!', 'success');
    }

    const summary = allPassed
      ? '<span class="ok">' + (results.length === 1 ? 'Sample I/O passed' : 'All ' + results.length + ' tests passed') + '</span>'
      : '<span class="danger">' + passed + '/' + results.length + ' tests passed</span>';

    setResults('<div class="rail-head"><p class="label">Results</p><span class="sub mono">' + summary +
      ' · ' + Math.round(Number(totalMs) || 0) + ' ms</span></div>' +
      '<div class="code-result-list">' + rows + '</div>');
  }

  function runAll(submit){
    const box = container();
    const ta = $('#code-editor', box);
    if(!ta) return;
    const problem = byId(selectedId);
    if(isCustomProblem(problem) && isOnlineLang(selectedLang)){
      showFatal('Custom problems run in JavaScript or Python only.', 0);
      return;
    }
    const code = ta.value;
    saveDraft(problem.id, selectedLang, code);
    stopRun();

    if(isOnlineLang(selectedLang) && !onlineConsent){
      askConsent(() => runAll(submit));
      return;
    }

    if(isOnlineLang(selectedLang) && !runnerUrl()){
      showFatal('No online runner endpoint is configured. Set Store \'runnerurl\' (localStorage key ff_runnerurl) to your remote runner URL.', 0);
      return;
    }

    const token = ++runToken;
    const started = performance.now();

    if(!window.Runners){
      showFatal('Code runner is not available', performance.now() - started);
      return;
    }

    if(selectedLang === 'python' && !Runners.isPythonReady()){
      setResults('<div class="empty"><i class="fa-solid fa-spinner fa-spin"></i><p>Loading Python runtime (first run only)</p></div>');
    }else{
      setResults('<div class="empty"><i class="fa-solid fa-spinner fa-spin"></i><p>Running tests…</p></div>');
    }

    Runners.run(selectedLang, problem, code, { consent: onlineConsent }).then(result => {
      if(token !== runToken) return;
      showResults(problem, result.results, result.totalMs, submit);
    }).catch(err => {
      if(token !== runToken || err && err.cancelled) return;
      if(err && err.timeout){
        showTimeout(err.ms);
      }else{
        showFatal(errorText(err), err && typeof err.ms === 'number' ? err.ms : performance.now() - started);
      }
    });
  }

  function onShow(){
    bind();
    const box = container();
    if(!box) return;
    if(!box.querySelector('.code-shell')){
      render();
    }else{
      saveCurrentDraft();
      const select = $('#code-language', box);
      if(select) select.value = selectedLang;
    }
  }

  return { onShow };
})();
window.Code = Code;
