'use strict';

Quiz.addBank([
  {
    q: 'Which is the largest continent by area?',
    options: ['Asia', 'Africa', 'North America', 'Europe'],
    answer: 0,
    subject: 'Geography',
    explain: 'Asia is the largest continent by both area and population.'
  },
  {
    q: 'Which is the largest ocean on Earth?',
    options: ['Atlantic Ocean', 'Indian Ocean', 'Pacific Ocean', 'Arctic Ocean'],
    answer: 2,
    subject: 'Geography',
    explain: 'The Pacific Ocean is the largest and deepest ocean.'
  },
  {
    q: 'What is the imaginary line at 0° latitude called?',
    options: ['Tropic of Cancer', 'Equator', 'Prime Meridian', 'Arctic Circle'],
    answer: 1,
    subject: 'Geography',
    explain: 'The Equator is the line of 0° latitude that divides Earth into two hemispheres.'
  },
  {
    q: 'In which layer of the atmosphere is the ozone layer mainly found?',
    options: ['Troposphere', 'Mesosphere', 'Stratosphere', 'Thermosphere'],
    answer: 2,
    subject: 'Geography',
    explain: 'The ozone layer is mainly found in the stratosphere.'
  },
  {
    q: 'What is the main cause of ocean tides on Earth?',
    options: ['Prevailing winds', 'Rotation of Earth alone', 'Underwater earthquakes', 'Gravitational pull of the Moon and Sun'],
    answer: 3,
    subject: 'Geography',
    explain: 'The gravitational pull of the Moon and Sun mainly causes tides.'
  },
  {
    q: 'Which type of rock forms when magma or lava cools and solidifies?',
    options: ['Igneous rock', 'Sedimentary rock', 'Metamorphic rock', 'Fossil rock'],
    answer: 0,
    subject: 'Geography',
    explain: 'Igneous rocks form from cooled magma or lava.'
  },
  {
    q: 'What was the name of the supercontinent that began to break apart about 200 million years ago?',
    options: ['Gondwanaland', 'Laurasia', 'Pangaea', 'Rodinia'],
    answer: 2,
    subject: 'Geography',
    explain: 'Pangaea was the supercontinent that later split into Laurasia and Gondwanaland.'
  },
  {
    q: 'Which is the highest mountain peak above sea level?',
    options: ['K2', 'Mount Everest', 'Kangchenjunga', 'Makalu'],
    answer: 1,
    subject: 'Geography',
    explain: 'Mount Everest is the highest peak above sea level.'
  },
  {
    q: 'Which is the largest hot desert in the world?',
    options: ['Gobi Desert', 'Kalahari Desert', 'Thar Desert', 'Sahara Desert'],
    answer: 3,
    subject: 'Geography',
    explain: 'The Sahara is the largest hot desert; Antarctica is the largest desert overall.'
  },
  {
    q: 'Which imaginary line divides Earth into the Eastern and Western Hemispheres?',
    options: ['Prime Meridian', 'Equator', 'Tropic of Cancer', 'International Date Line'],
    answer: 0,
    subject: 'Geography',
    explain: 'The Prime Meridian, at 0° longitude, divides Earth into Eastern and Western Hemispheres.'
  },
  {
    q: 'Indian Standard Time is based on which longitude?',
    options: ['75°E', '90°E', '82.5°E', '68.7°E'],
    answer: 2,
    subject: 'Geography',
    explain: 'Indian Standard Time is based on the standard meridian of 82.5°E.'
  },
  {
    q: 'Which is the deepest oceanic trench on Earth?',
    options: ['Tonga Trench', 'Mariana Trench', 'Java Trench', 'Puerto Rico Trench'],
    answer: 1,
    subject: 'Geography',
    explain: 'The Mariana Trench in the Pacific Ocean is the deepest oceanic trench.'
  },
  {
    q: 'The Great Barrier Reef lies off the coast of which country?',
    options: ['Brazil', 'Indonesia', 'Mexico', 'Australia'],
    answer: 3,
    subject: 'Geography',
    explain: 'The Great Barrier Reef lies off the northeastern coast of Australia.'
  },
  {
    q: 'Which river is known as the "Sorrow of Bihar"?',
    options: ['Kosi', 'Ganga', 'Yamuna', 'Brahmaputra'],
    answer: 0,
    subject: 'Geography',
    explain: 'The Kosi is called the "Sorrow of Bihar" because of its frequent floods.'
  },
  {
    q: 'Which is the largest Indian state by area?',
    options: ['Madhya Pradesh', 'Maharashtra', 'Rajasthan', 'Uttar Pradesh'],
    answer: 2,
    subject: 'Geography',
    explain: 'Rajasthan is the largest Indian state by area.'
  },
  {
    q: 'Which is the longest river in India?',
    options: ['Godavari', 'Ganga', 'Brahmaputra', 'Narmada'],
    answer: 1,
    subject: 'Geography',
    explain: 'The Ganga is the longest river within India.'
  },
  {
    q: 'Which of these is a kharif crop?',
    options: ['Wheat', 'Mustard', 'Gram', 'Rice'],
    answer: 3,
    subject: 'Geography',
    explain: 'Rice is a kharif crop, grown mainly during the monsoon season.'
  },
  {
    q: 'Which soil is best suited for growing cotton?',
    options: ['Alluvial soil', 'Red soil', 'Laterite soil', 'Black soil'],
    answer: 3,
    subject: 'Geography',
    explain: 'Black soil, also called regur soil, retains moisture and is ideal for cotton.'
  },
  {
    q: 'What is the main source of energy that drives the water cycle?',
    options: ['The Moon', 'The Sun', 'Wind', 'Earth\'s interior'],
    answer: 1,
    subject: 'Geography',
    explain: 'The Sun provides most of the energy that drives evaporation and the water cycle.'
  },
  {
    q: 'What is the process by which plants release water vapour into the atmosphere?',
    options: ['Transpiration', 'Condensation', 'Precipitation', 'Infiltration'],
    answer: 0,
    subject: 'Geography',
    explain: 'Transpiration is the loss of water vapour from plants, mainly through stomata.'
  }
]);
