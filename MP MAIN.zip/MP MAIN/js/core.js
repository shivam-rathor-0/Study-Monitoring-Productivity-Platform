/* core.js — helpers, storage, toast, theme, cursor, subject colours */
'use strict';

const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

function el(tag, attrs = {}, ...children){
  const node = document.createElement(tag);
  for(const [k, v] of Object.entries(attrs)){
    if(v == null) continue;
    if(k === 'class')     node.className = v;
    else if(k === 'html') node.innerHTML = v;
    else if(k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2), v);
    else node.setAttribute(k, v);
  }
  for(const c of children){
    if(c == null) continue;
    node.append(c.nodeType ? c : document.createTextNode(c));
  }
  return node;
}

function escapeHTML(str){
  return String(str).replace(/[&<>"']/g, m =>
    ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

/* ---------- time helpers ---------- */
function fmtClock(sec){
  sec = Math.max(0, Math.floor(sec));
  const h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  const mm = String(m).padStart(2, '0'), ss = String(s).padStart(2, '0');
  return h > 0 ? h + ':' + mm + ':' + ss : m + ':' + ss;
}
function fmtDur(sec){
  const m = Math.round(sec / 60);
  if(m < 1)  return '<1m';
  if(m < 60) return m + 'm';
  return Math.floor(m / 60) + 'h ' + (m % 60) + 'm';
}
function fmtAgo(ts){
  const s = Math.floor((Date.now() - ts) / 1000);
  if(s < 60)    return 'just now';
  if(s < 3600)  return Math.floor(s / 60) + 'm ago';
  if(s < 86400) return Math.floor(s / 3600) + 'h ago';
  return Math.floor(s / 86400) + 'd ago';
}
function dateKey(d = new Date()){
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function dayLabel(d){ return d.toLocaleDateString(undefined, { weekday: 'short' }); }

/* ---------- subject colour system ---------- */
const PALETTE = ['#F6B93B','#4FB286','#5B9BD5','#C97B63','#A78BDB','#E4739C','#56C4C6','#8FBF4D','#E0A458','#7A9ECC'];
function hstr(s){ let h = 0; for(let i = 0; i < String(s).length; i++) h = (h * 31 + String(s).charCodeAt(i)) >>> 0; return h; }
function hueFor(name){ return PALETTE[hstr(name) % PALETTE.length]; }
function safeColor(v, fallback){
  return typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v) ? v : fallback;
}
function safeCode(v){
  const s = String(v == null ? '' : v).toUpperCase();
  return /^[A-Z0-9]{4,10}$/.test(s) ? s : '';
}
function safeDecode(s){
  try{ return decodeURIComponent(s); }catch(e){ return ''; }
}

/* ---------- fail-safe localStorage wrapper ---------- */
const Store = {
  get(key, fallback){
    try{
      const raw = localStorage.getItem('ff_' + key);
      if(raw == null) return fallback;
      const val = JSON.parse(raw);
      if(val == null) return fallback;
      if(Array.isArray(fallback)) return Array.isArray(val) ? val : fallback;
      if(fallback !== null && typeof fallback === 'object') {
        return (typeof val === 'object' && val !== null && !Array.isArray(val)) ? val : fallback;
      }
      if(typeof fallback === 'string' || typeof fallback === 'number' || typeof fallback === 'boolean') {
        return typeof val === typeof fallback ? val : fallback;
      }
      return val;
    }catch(e){ return fallback; }
  },
  set(key, val){ try{ localStorage.setItem('ff_' + key, JSON.stringify(val)); }catch(e){} },
  del(key){ try{ localStorage.removeItem('ff_' + key); }catch(e){} }
};

/* ---------- toast ---------- */
function toast(msg, type = 'info'){
  const box = $('#toast-container');
  if(!box) return;
  const t = el('div', { class: 'toast toast-' + type }, msg);
  box.append(t);
  requestAnimationFrame(() => requestAnimationFrame(() => t.classList.add('show')));
  setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 350); }, 3600);
  while(box.children.length > 4) box.firstChild.remove();
}

/* ---------- shared state + constants ---------- */
const State = { user: null, view: 'home' };
const SUBJECTS = ['Mathematics','Physics','Chemistry','Biology','English','Computer Science','History','Geography','Economics'];

/* ---------- themed background art ---------- */
const BG_THEMES = ['dark','light','aurora','sakura','matcha','mocha'];

function bgArtEnabled(){
  return Store.get('bgart', Store.get('bgvideo', true)) !== false;
}
function bgTheme(){
  return document.documentElement.getAttribute('data-theme') || Store.get('theme', 'dark') || 'dark';
}
function syncBgChips(){
  const on = bgArtEnabled();
  $$('#bgart-toggle [data-bgart]').forEach(b => {
    const active = (b.dataset.bgart === 'on') === on;
    b.classList.toggle('active', active);
    b.setAttribute('aria-pressed', String(active));
  });
}
function applyBgArt(){
  const layer = $('#bg-layer');
  if(!layer) return;
  const on = bgArtEnabled();
  const valid = BG_THEMES.includes(bgTheme());
  layer.classList.toggle('show', on && valid);
  layer.classList.toggle('art-off', !on || !valid);
  syncBgChips();
}

(function bindBgArt(){
  if(!$('#bg-layer')) return;
  document.addEventListener('click', e => {
    const chip = e.target.closest('#bgart-toggle [data-bgart]');
    if(!chip) return;
    e.preventDefault();
    Store.set('bgart', chip.dataset.bgart === 'on');
    applyBgArt();
  });
  applyBgArt();
})();

/* ---------- theme ---------- */
function applyTheme(theme){
  const next = ['dark', 'light', 'aurora', 'sakura', 'matcha', 'mocha'].includes(theme) ? theme : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  $$('#theme-list .theme-opt').forEach(b => {
    const on = b.dataset.themeId === next;
    b.classList.toggle('active', on);
    b.setAttribute('aria-pressed', String(on));
  });
  applyBgArt();
  if(applyTheme.applyCursor) applyTheme.applyCursor();
}
function toggleTheme(){
  const cur = document.documentElement.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
  const next = cur === 'light' ? 'dark' : 'light';
  Store.set('theme', next);
  applyTheme(next);
}

/* ---------- themed cursors ---------- */
(function(){
  function applyCursor(){
    const root = document.documentElement;
    if(!document.body || window.matchMedia('(pointer: coarse)').matches){
      root.style.removeProperty('--cursor-default');
      root.style.removeProperty('--cursor-pointer');
      return;
    }

    const resolve = color => {
      const probe = document.createElement('span');
      probe.style.cssText = 'position:absolute;visibility:hidden;pointer-events:none';
      probe.style.color = color;
      document.body.appendChild(probe);
      const rgb = getComputedStyle(probe).color;
      probe.remove();
      return rgb;
    };
    const accent = resolve('var(--accent)');
    const outline = resolve('var(--text)');

    const url = svg => `url("data:image/svg+xml,${encodeURIComponent(svg)}")`;
    const arrow = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M3 2v17l4.8-4.3 3.1 6.3 3.1-1.6-3.2-6.2H17L3 2Z" fill="${accent}" stroke="${outline}" stroke-width="1.5" stroke-linejoin="round"/></svg>`;
    const hand = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 16 16"><path d="M6.75 1a.75.75 0 0 1 .75.75V8a.5.5 0 0 0 1 0V5.25a.75.75 0 0 1 1.5 0V8a.5.5 0 0 0 1 0V3.25a.75.75 0 0 1 1.5 0V8a.5.5 0 0 0 1 0V4.75a.75.75 0 0 1 1.5 0v6.5a5.5 5.5 0 0 1-5.5 5.5h-1.5a5.5 5.5 0 0 1-5.5-5.5v-4a.75.75 0 0 1 1.5 0V9a.5.5 0 0 0 1 0V1.75A.75.75 0 0 1 6.75 1z" fill="${accent}" stroke="${outline}" stroke-width=".7" stroke-linejoin="round"/></svg>`;

    root.style.setProperty('--cursor-default', `${url(arrow)} 3 2, auto`);
    root.style.setProperty('--cursor-pointer', `${url(hand)} 11 2, pointer`);
  }

  applyTheme.applyCursor = applyCursor;
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', applyCursor, { once: true });
  else applyCursor();
})();