/* audio.js — 10 generative music channels + 7 ambience channels.
   Music runs on lookahead schedulers (real performances, not loops);
   ambience uses noise synthesis + randomized events. */
'use strict';

const Sound = (function(){

  const CHANNELS = [
    /* --- instrumental --- */
    { id:'jazz',   name:'Jazz Corner',    desc:'Walking bass · brushed comping · swing ride',   icon:'fa-guitar',      cat:'instrumental', hue:'#E8A33D', vol:.9,  gen:genJazz },
    { id:'lofi',   name:'Lofi Beats',     desc:'Warm chords · vinyl crackle · soft kick',        icon:'fa-compact-disc',cat:'instrumental', hue:'#EE9BB7', vol:.9,  gen:genLofi },
    { id:'piano',  name:'Ivory Keys',     desc:'Slow generative piano in a large hall',          icon:'fa-music',       cat:'instrumental', hue:'#8FC7E8', vol:.9,  gen:genPiano },
    { id:'synth',  name:'Synthwave',      desc:'Neon arpeggios · punchy drums · retro pads',     icon:'fa-record-vinyl',cat:'instrumental', hue:'#B78BFA', vol:.85, gen:genSynth },
    { id:'bossa',  name:'Bossa Nova',     desc:'Nylon-guitar comping · shaker · warm bass',      icon:'fa-leaf',        cat:'instrumental', hue:'#7FBF9E', vol:.85, gen:genBossa },
    { id:'strings',name:'String Quartet', desc:'Slow vibrato strings with soaring melody',       icon:'fa-violin',      cat:'instrumental', hue:'#D9B45B', vol:.85, gen:genStrings },
    { id:'harpsi', name:'Baroque Keys',   desc:'Harpsichord arpeggios · classical drive',        icon:'fa-feather',     cat:'instrumental', hue:'#C97B63', vol:.8,  gen:genHarpsi },
    { id:'night',  name:'Night Drive',    desc:'Dark pulse · sparse echoing arps',               icon:'fa-car-side',    cat:'instrumental', hue:'#5E8FD6', vol:.85, gen:genNight },
    { id:'bowls',  name:'Singing Bowls',  desc:'Meditation bowls with slow harmonics',           icon:'fa-spa',         cat:'instrumental', hue:'#A78BDB', vol:.8,  gen:genBowls },
    { id:'box',    name:'Music Box',      desc:'Twinkling melodies in a dreamy echo',            icon:'fa-star',        cat:'instrumental', hue:'#F4A9C4', vol:.75, gen:genBox },
    /* --- noise --- */
    { id:'white',  name:'White Noise',    desc:'Bright, even hiss for masking',                  icon:'fa-wind',        cat:'noise', hue:'#A8A29A', vol:.45, gen:genWhite },
    { id:'brown',  name:'Brown Noise',    desc:'Deep, warm rumble — easy on the ears',           icon:'fa-mountain',    cat:'noise', hue:'#B08463', vol:.5,  gen:genBrown },
    { id:'pink',   name:'Pink Noise',     desc:'Soft rain-like hiss, balanced across octaves',   icon:'fa-cloud',       cat:'noise', hue:'#C99BA8', vol:.5,  gen:genPink },
    /* --- nature & places --- */
    { id:'rain',    name:'Rain',         desc:'Steady downpour with droplets',                  icon:'fa-cloud-rain',  cat:'nature', hue:'#7AA5D8', vol:.8, gen:genRain },
    { id:'thunder', name:'Thunderstorm', desc:'Heavy rain with distant rumbles',                icon:'fa-cloud-bolt',  cat:'nature', hue:'#7E8CA0', vol:.8, gen:genThunder },
    { id:'cafe',    name:'Café Murmur',  desc:'Room murmur with clinking cups',                 icon:'fa-mug-hot',     cat:'nature', hue:'#E0A458', vol:.8, gen:genCafe },
    { id:'fire',    name:'Fireplace',    desc:'Crackling wood fire',                            icon:'fa-fire',        cat:'nature', hue:'#E8703A', vol:.8, gen:genFire },
    { id:'waves',   name:'Ocean Waves',  desc:'Slow rolling swells',                            icon:'fa-water',       cat:'nature', hue:'#56C4C6', vol:.9, gen:genWaves },
    { id:'forest',  name:'Night Forest', desc:'Crickets chirping through a soft breeze',        icon:'fa-tree',        cat:'nature', hue:'#8FBF4D', vol:.8, gen:genForest },
  ];

  const GROUPS = [
    { id:'noise',        label:'Noise',           hint:'Steady masking' },
    { id:'instrumental', label:'Instrumental',    hint:'Generative performances' },
    { id:'nature',       label:'Nature & places', hint:'Environments' }
  ];

  const PRESETS = [
    { name:'Rainy Lofi',     icon:'fa-cloud-rain', ch:{ lofi:.85, rain:.6 } },
    { name:'Midnight Jazz',  icon:'fa-guitar',     ch:{ jazz:.9, fire:.45 } },
    { name:'Storm & Keys',   icon:'fa-cloud-bolt', ch:{ thunder:.85, piano:.65 } },
    { name:'Neon Drive',     icon:'fa-road',       ch:{ synth:.8, night:.5 } },
    { name:'Zen Temple',     icon:'fa-spa',        ch:{ bowls:.8, forest:.4 } },
    { name:'Baroque Study',  icon:'fa-feather',    ch:{ harpsi:.75, cafe:.35 } },
  ];

  let ctx = null, master = null, sfxBus = null, audioBroken = false;
  let volume = Math.min(1, Math.max(0, Store.get('volume', 0.7)));
  const active = new Map();
  const noiseCache = {};
  let sleepMin = null, sleepUntil = null, sleepInt = null;

  const mtof = m => 440 * Math.pow(2, (m - 69) / 12);
  const vols = () => Store.get('chanvol', {});
  const defVol = id => { const d = CHANNELS.find(c => c.id === id); return d ? d.vol : .8; };

  const osc  = (type, f) => { const o = ctx.createOscillator(); o.type = type; o.frequency.value = f; return o; };
  const gn   = v => { const g = ctx.createGain(); g.gain.value = v; return g; };
  const flt  = (type, f, q) => { const b = ctx.createBiquadFilter(); b.type = type; b.frequency.value = f; if(q) b.Q.value = q; return b; };
  const noiseSrc = kind => { const s = ctx.createBufferSource(); s.buffer = noiseBuffer(kind); s.loop = true; return s; };

  function ensure(){
    if(audioBroken) return null;
    if(!ctx){
      try{
        const Ctx = window.AudioContext || window.webkitAudioContext;
        if(!Ctx) throw new Error('No AudioContext');
        ctx = new Ctx();
        const comp = ctx.createDynamicsCompressor();
        comp.threshold.value = -18; comp.ratio.value = 6;
        master = ctx.createGain(); master.gain.value = volume;
        sfxBus = ctx.createGain(); sfxBus.gain.value = 0.6;
        master.connect(comp); sfxBus.connect(comp); comp.connect(ctx.destination);
      }catch(e){
        audioBroken = true;
        toast('Sound is not supported in this browser', 'warn');
        return null;
      }
    }
    if(ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function noiseBuffer(kind){
    if(noiseCache[kind]) return noiseCache[kind];
    const len = ctx.sampleRate * 2;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = buf.getChannelData(0);
    let last = 0, b0 = 0, b1 = 0, b2 = 0;
    for(let i = 0; i < len; i++){
      const w = Math.random() * 2 - 1;
      if(kind === 'white'){ d[i] = w * 0.4; }
      else if(kind === 'brown'){ last = (last + 0.02 * w) / 1.02; d[i] = last * 3.2; }
      else {
        b0 = 0.99886 * b0 + w * 0.0555179;
        b1 = 0.99332 * b1 + w * 0.0750759;
        b2 = 0.96900 * b2 + w * 0.1538520;
        d[i] = (b0 + b1 + b2 + w * 0.5482) * 0.11;
      }
    }
    noiseCache[kind] = buf;
    return buf;
  }

  function makeChannel(){
    const ch = { nodes: [], timers: [], gain: ctx.createGain() };
    ch.gain.gain.value = 0;
    ch.gain.connect(master);
    ch.stop = () => {
      const now = ctx.currentTime;
      try{ ch.gain.gain.cancelScheduledValues(now); }catch(e){}
      ch.gain.gain.setTargetAtTime(0, now, 0.08);
      setTimeout(() => {
        ch.timers.forEach(clearInterval);
        ch.nodes.forEach(n => {
          try{ n.stop && n.stop(); }catch(e){}
          try{ n.disconnect(); }catch(e){}
        });
        try{ ch.gain.disconnect(); }catch(e){}
      }, 380);
    };
    return ch;
  }

  function toggle(id){
    if(active.has(id)){
      active.get(id).stop();
      active.delete(id);
    }else{
      const def = CHANNELS.find(c => c.id === id);
      if(!def) return false;
      if(!ensure()) return false;
      const ch = makeChannel();
      def.gen(ch);
      ch.gain.gain.setTargetAtTime(vols()[id] != null ? vols()[id] : def.vol, ctx.currentTime, 0.15);
      active.set(id, ch);
    }
    syncUI();
    return active.has(id);
  }

  function setChannelVol(id, v){
    v = Math.max(0, Math.min(1, v));
    const vs = vols(); vs[id] = v; Store.set('chanvol', vs);
    const ch = active.get(id);
    if(ch && ctx) ch.gain.gain.setTargetAtTime(v, ctx.currentTime, .08);
  }

  function stopAll(){
    [...active.keys()].forEach(id => { active.get(id).stop(); active.delete(id); });
    syncUI();
  }

  function setVolume(v){
    volume = Math.max(0, Math.min(1, v));
    Store.set('volume', volume);
    if(master) master.gain.setTargetAtTime(volume, ctx.currentTime, 0.05);
  }

  /* ---------- sleep timer ---------- */
  function setSleep(min){
    clearSleep();
    sleepMin = min;
    sleepUntil = Date.now() + min * 60000;
    sleepInt = setInterval(() => {
      const left = sleepUntil - Date.now();
      if(left <= 0){
        clearSleep(); stopAll();
        if(window.Music) Music.stop();
        toast('Sleep timer finished — sounds stopped', 'info');
        return;
      }
      if(left < 20000 && master) master.gain.setTargetAtTime(volume * (left / 20000), ctx.currentTime, .3);
      const lbl = $('#sleep-left');
      if(lbl) lbl.textContent = fmtClock(left / 1000) + ' left';
    }, 1000);
    syncUI();
  }
  function clearSleep(){
    if(sleepInt) clearInterval(sleepInt);
    sleepInt = null; sleepUntil = null; sleepMin = null;
    if(master && ctx) master.gain.setTargetAtTime(volume, ctx.currentTime, .1);
    const lbl = $('#sleep-left');
    if(lbl) lbl.textContent = '';
    syncUI();
  }

  /* ---------- presets ---------- */
  function applyPreset(p){
    stopAll();
    const vs = vols();
    Object.entries(p.ch).forEach(([id, v]) => { vs[id] = v; });
    Store.set('chanvol', vs);
    Object.keys(p.ch).forEach(id => {
      if(!active.has(id)) toggle(id);
      else active.get(id).gain.gain.setTargetAtTime(p.ch[id], ctx.currentTime, .1);
    });
    syncUI();
    toast('Preset loaded — ' + p.name, 'info');
  }

  /* ================= shared drum voices ================= */
  function kick(out, t){
    const o = osc('sine', 95);
    o.frequency.setValueAtTime(95, t);
    o.frequency.exponentialRampToValueAtTime(42, t + .12);
    const g = ctx.createGain();
    g.gain.setValueAtTime(.16, t);
    g.gain.exponentialRampToValueAtTime(.0001, t + .22);
    o.connect(g); g.connect(out);
    o.start(t); o.stop(t + .25);
  }
  function snare(out, t){
    const src = ctx.createBufferSource(); src.buffer = noiseBuffer('white');
    const bp = flt('bandpass', 1800, .8);
    const g = ctx.createGain();
    g.gain.setValueAtTime(.07, t);
    g.gain.exponentialRampToValueAtTime(.001, t + .16);
    src.connect(bp); bp.connect(g); g.connect(out);
    src.start(t); src.stop(t + .2);
    const o = osc('triangle', 180);
    const og = ctx.createGain();
    og.gain.setValueAtTime(.05, t);
    og.gain.exponentialRampToValueAtTime(.001, t + .08);
    o.connect(og); og.connect(out);
    o.start(t); o.stop(t + .1);
  }
  function hat(out, t, v = 1){
    const src = ctx.createBufferSource(); src.buffer = noiseBuffer('white');
    const hp = flt('highpass', 8000);
    const g = ctx.createGain();
    g.gain.setValueAtTime(.03 * v, t);
    g.gain.exponentialRampToValueAtTime(.0001, t + .05);
    src.connect(hp); hp.connect(g); g.connect(out);
    src.start(t); src.stop(t + .07);
  }

  /* ================= MUSIC generators ================= */

  function genJazz(ch){
    const bus = gn(1);
    bus.connect(ch.gain); ch.nodes.push(bus);
    const BEAT = 60 / 96, BAR = BEAT * 4;
    const BARS = [
      { chord: [50, 53, 57, 60], bass: [38, 41, 45, 48] },
      { chord: [43, 47, 50, 53], bass: [43, 45, 47, 48] },
      { chord: [48, 52, 55, 59], bass: [48, 50, 52, 47] },
      { chord: [48, 52, 55, 59], bass: [48, 52, 55, 59] },
    ];
    let next = ctx.currentTime + .1, bi = 0;
    const schedule = () => {
      while(next < ctx.currentTime + .6){
        const bar = BARS[bi % 4];
        bar.bass.forEach((n, q) => jBass(bus, mtof(n), next + q * BEAT, BEAT * .95));
        stab(bus, bar.chord, next + .02, .9);
        stab(bus, bar.chord, next + BEAT * 2.5, .5);
        for(let b = 0; b < 4; b++){
          ride(bus, next + b * BEAT, 1);
          ride(bus, next + b * BEAT + BEAT * .66, .6);
        }
        bi++; next += BAR;
      }
    };
    ch.timers.push(setInterval(schedule, 250));
    schedule();
  }
  function jBass(out, freq, t, len){
    const o = osc('triangle', freq);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(.14, t + .02);
    g.gain.exponentialRampToValueAtTime(.001, t + len);
    o.connect(g); g.connect(out);
    o.start(t); o.stop(t + len + .02);
  }
  function stab(out, chord, t, len){
    chord.forEach((n, i) => {
      const o  = osc('sine', mtof(n + 12));
      const o2 = osc('triangle', mtof(n + 12) * 2);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(Math.max(.015, .035 - i * .004), t + .015);
      g.gain.exponentialRampToValueAtTime(.0001, t + len);
      o.connect(g); o2.connect(g); g.connect(out);
      o.start(t); o.stop(t + len + .05);
      o2.start(t); o2.stop(t + len + .05);
    });
  }
  function ride(out, t, vol){
    const src = ctx.createBufferSource(); src.buffer = noiseBuffer('white');
    const bp = flt('bandpass', 5200, 1.2);
    const g = ctx.createGain();
    g.gain.setValueAtTime(.028 * vol, t);
    g.gain.exponentialRampToValueAtTime(.0001, t + .09);
    src.connect(bp); bp.connect(g); g.connect(out);
    src.start(t); src.stop(t + .12);
  }

  function genLofi(ch){
    const lp = flt('lowpass', 1050);
    lp.connect(ch.gain); ch.nodes.push(lp);
    const CHORDS = [[53,57,60,64],[52,55,59,62],[50,53,57,60],[48,52,55,59]];
    const LEN = 3.43;
    let next = ctx.currentTime + .1, ci = 0;
    const schedule = () => {
      while(next < ctx.currentTime + .6){
        const chord = CHORDS[ci % 4];
        padChord(lp, chord, next, LEN);
        bassNote(lp, mtof(chord[0] - 12), next, LEN);
        kick(lp, next + .01);
        kick(lp, next + LEN / 2 + .01);
        hat(ch.gain, next + LEN / 4);
        hat(ch.gain, next + LEN * 3 / 4);
        ci++; next += LEN;
      }
    };
    ch.timers.push(setInterval(schedule, 250));
    schedule();
    ch.timers.push(setInterval(() => { if(Math.random() < .8) vinyl(ch.gain); }, 90));
  }
  function padChord(out, notes, t, len){
    notes.forEach(n => {
      [-4, 3].forEach(det => {
        const o = osc('triangle', mtof(n)); o.detune.value = det;
        const g = ctx.createGain();
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(.045, t + .6);
        g.gain.setValueAtTime(.045, t + Math.max(.7, len - .8));
        g.gain.linearRampToValueAtTime(.0001, t + len);
        o.connect(g); g.connect(out);
        o.start(t); o.stop(t + len + .05);
      });
    });
  }
  function bassNote(out, freq, t, len){
    const o = osc('sine', freq);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(.11, t + .08);
    g.gain.setTargetAtTime(.0001, t + len * .6, .4);
    o.connect(g); g.connect(out);
    o.start(t); o.stop(t + len);
  }
  function vinyl(out){
    const t = ctx.currentTime;
    const src = ctx.createBufferSource(); src.buffer = noiseBuffer('white');
    const hp = flt('highpass', 3800);
    const g = ctx.createGain();
    g.gain.setValueAtTime(.012 + Math.random() * .03, t);
    g.gain.exponentialRampToValueAtTime(.0001, t + .02 + Math.random() * .03);
    src.connect(hp); hp.connect(g); g.connect(out);
    src.start(t); src.stop(t + .08);
  }

  function genPiano(ch){
    const lp = flt('lowpass', 3200);
    const wet = gn(.5);
    const del = ctx.createDelay(1); del.delayTime.value = .34;
    const fb = gn(.42);
    del.connect(fb); fb.connect(del);
    wet.connect(del); del.connect(lp); lp.connect(ch.gain);
    ch.nodes.push(lp, wet, del, fb);
    const SCALE = [57, 60, 62, 64, 67, 69, 72, 74, 76, 79];
    let idx = 4;
    const note = (t, midi, vel) => {
      [[1,'sine',1],[2,'triangle',.28],[3.01,'sine',.09]].forEach(([mul, type, amp]) => {
        const o = osc(type, mtof(midi) * mul);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(vel * amp, t + .008);
        g.gain.exponentialRampToValueAtTime(.0001, t + 3.8);
        o.connect(g); g.connect(lp);
        o.start(t); o.stop(t + 3.9);
      });
    };
    let next = ctx.currentTime + .2;
    ch.timers.push(setInterval(() => {
      while(next < ctx.currentTime + .8){
        idx = Math.max(0, Math.min(SCALE.length - 1, idx + Math.floor(Math.random() * 7) - 3));
        const vel = .05 + Math.random() * .07;
        note(next, SCALE[idx], vel);
        if(Math.random() < .3) note(next + .02, SCALE[Math.min(SCALE.length - 1, idx + 2)], vel * .7);
        next += 1.2 + Math.random() * 3.2;
      }
    }, 250));
  }

  function genSynth(ch){
    const BEAT = 60 / 104, BAR = BEAT * 4;
    const bus = gn(1); bus.connect(ch.gain); ch.nodes.push(bus);
    const del = ctx.createDelay(1); del.delayTime.value = BEAT * .75;
    const fb = gn(.32); del.connect(fb); fb.connect(del);
    const wet = gn(.35); del.connect(wet); wet.connect(bus);
    ch.nodes.push(del, fb, wet);
    const CH = [[57,60,64],[53,57,60],[48,52,55],[55,59,62]];   /* Am F C G */
    const ARP = [0,1,2,1,0,2,1,2];
    let next = ctx.currentTime + .1, bi = 0;
    const schedule = () => {
      while(next < ctx.currentTime + .6){
        const t = next, chord = CH[bi % 4];
        chord.forEach(n => [-7, 7].forEach(d => {
          const o = osc('sawtooth', mtof(n)); o.detune.value = d;
          const f = flt('lowpass', 1100, .7);
          const g = ctx.createGain();
          g.gain.setValueAtTime(0, t);
          g.gain.linearRampToValueAtTime(.028, t + .05);
          g.gain.setValueAtTime(.028, t + BAR - .1);
          g.gain.linearRampToValueAtTime(0, t + BAR);
          o.connect(f); f.connect(g); g.connect(bus);
          o.start(t); o.stop(t + BAR + .02);
        }));
        for(let i = 0; i < 8; i++){
          const o = osc('square', mtof(chord[0] - 24));
          const f = flt('lowpass', 300);
          const g = ctx.createGain();
          const tt = t + i * BEAT / 2;
          g.gain.setValueAtTime(.09, tt);
          g.gain.exponentialRampToValueAtTime(.001, tt + BEAT * .45);
          o.connect(f); f.connect(g); g.connect(bus);
          o.start(tt); o.stop(tt + BEAT * .5);
        }
        for(let i = 0; i < 8; i++){
          const n = chord[ARP[i]] + 12;
          const o = osc('square', mtof(n));
          const f = flt('lowpass', 2600, 2);
          const g = ctx.createGain();
          const tt = t + i * BEAT / 2;
          g.gain.setValueAtTime(.05, tt);
          g.gain.exponentialRampToValueAtTime(.001, tt + BEAT * .4);
          o.connect(f); f.connect(g); g.connect(bus); g.connect(del);
          o.start(tt); o.stop(tt + BEAT * .45);
        }
        for(let b = 0; b < 4; b++){
          kick(bus, t + b * BEAT);
          if(b % 2 === 1) snare(bus, t + b * BEAT);
          hat(bus, t + b * BEAT + BEAT / 2, .5);
        }
        bi++; next += BAR;
      }
    };
    ch.timers.push(setInterval(schedule, 250));
    schedule();
  }

  function genBossa(ch){
    const BEAT = 60 / 78, BAR = BEAT * 4;
    const bus = gn(1); bus.connect(ch.gain); ch.nodes.push(bus);
    const CH = [[45,49,52,56],[50,53,57,60],[43,47,50,53],[48,52,55,59]];  /* Am7 Dm7 G7 Cmaj7 */
    let next = ctx.currentTime + .1, bi = 0;
    const pluck = (n, t, v) => {
      const o = osc('triangle', mtof(n));
      const o2 = osc('sine', mtof(n) * 2);
      const g2 = gn(.25);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(v, t + .006);
      g.gain.exponentialRampToValueAtTime(.0001, t + .55);
      o.connect(g); o2.connect(g2); g2.connect(g); g.connect(bus);
      o.start(t); o.stop(t + .6); o2.start(t); o2.stop(t + .6);
    };
    const shaker = (t, v) => {
      const src = ctx.createBufferSource(); src.buffer = noiseBuffer('white');
      const hp = flt('highpass', 6000);
      const g = ctx.createGain();
      g.gain.setValueAtTime(v, t);
      g.gain.exponentialRampToValueAtTime(.0005, t + .05);
      src.connect(hp); hp.connect(g); g.connect(bus);
      src.start(t); src.stop(t + .07);
    };
    const schedule = () => {
      while(next < ctx.currentTime + .6){
        const t = next, chord = CH[bi % 4];
        [0, 1.5, 2, 3.5].forEach((b, k) => {
          chord.forEach((n, i) => pluck(n + (i === 3 ? 12 : 0), t + b * BEAT + i * .012, k % 2 ? .035 : .05));
        });
        const bs = (n, tt) => {
          const o = osc('sine', mtof(n - 12));
          const g = ctx.createGain();
          g.gain.setValueAtTime(0, tt);
          g.gain.linearRampToValueAtTime(.11, tt + .02);
          g.gain.exponentialRampToValueAtTime(.001, tt + BEAT * 1.6);
          o.connect(g); g.connect(bus);
          o.start(tt); o.stop(tt + BEAT * 1.7);
        };
        bs(chord[0], t); bs(chord[0] + 7, t + 2 * BEAT);
        for(let i = 0; i < 8; i++) shaker(t + i * BEAT / 2, i % 2 ? .02 : .012);
        bi++; next += BAR;
      }
    };
    ch.timers.push(setInterval(schedule, 250));
    schedule();
  }

  function genStrings(ch){
    const bus = gn(1); bus.connect(ch.gain); ch.nodes.push(bus);
    const lp = flt('lowpass', 1900, .5); lp.connect(bus); ch.nodes.push(lp);
    const vib = osc('sine', 5);
    const vdepth = gn(4); vib.connect(vdepth); vib.start();
    ch.nodes.push(vib, vdepth);
    const CH = [[50,57,62,66],[46,53,58,62],[41,48,53,57],[48,55,60,64]];  /* Dm Bb F C */
    const LEN = 7.5;
    let next = ctx.currentTime + .1, bi = 0;
    const voice = (n, t, d) => {
      [-6, 6].forEach(det => {
        const o = osc('sawtooth', mtof(n)); o.detune.value = det;
        vdepth.connect(o.detune);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(.03, t + 1.6);
        g.gain.setValueAtTime(.03, t + d - 1.8);
        g.gain.linearRampToValueAtTime(0, t + d);
        o.connect(g); g.connect(lp);
        o.start(t); o.stop(t + d + .05);
      });
    };
    const schedule = () => {
      while(next < ctx.currentTime + 1.2){
        const chord = CH[bi % 4];
        chord.forEach(n => voice(n, next, LEN));
        if(bi % 2 === 1){
          const mel = chord[3] + 12 + (Math.random() < .4 ? 7 : 0);
          const o = osc('sawtooth', mtof(mel)); o.detune.value = 5;
          vdepth.connect(o.detune);
          const f = flt('lowpass', 2600, 1);
          const g = ctx.createGain();
          g.gain.setValueAtTime(0, next + .3);
          g.gain.linearRampToValueAtTime(.035, next + 1.2);
          g.gain.setValueAtTime(.035, next + LEN - 2);
          g.gain.linearRampToValueAtTime(0, next + LEN);
          o.connect(f); f.connect(g); g.connect(lp);
          o.start(next + .3); o.stop(next + LEN);
        }
        bi++; next += LEN;
      }
    };
    ch.timers.push(setInterval(schedule, 600));
    schedule();
  }

  function genHarpsi(ch){
    const bus = gn(1); bus.connect(ch.gain); ch.nodes.push(bus);
    const STEP = 60 / 92 / 4;                                    /* 16ths @ 92bpm */
    const CH = [[57,60,64],[55,59,62],[53,57,60],[52,56,59]];    /* Am G F E */
    const PAT = [0,1,2,0,1,2,1,0,2,1,0,2,1,0,1,2];
    let next = ctx.currentTime + .1, bi = 0, pi = 0;
    const pluck = (n, t, v) => {
      [0, -9].forEach(d => {
        const o = osc('sawtooth', mtof(n)); o.detune.value = d;
        const hp = flt('highpass', 180);
        const g = ctx.createGain();
        g.gain.setValueAtTime(v, t);
        g.gain.exponentialRampToValueAtTime(.0001, t + .22);
        o.connect(hp); hp.connect(g); g.connect(bus);
        o.start(t); o.stop(t + .26);
      });
    };
    const schedule = () => {
      while(next < ctx.currentTime + .5){
        const chord = CH[bi % 4];
        const idx = PAT[pi % PAT.length];
        let n = chord[idx % 3];
        if(pi % 16 >= 8) n += 12;
        pluck(n, next, .045);
        if(pi % 16 === 0) pluck(chord[0] - 12, next, .06);
        pi++; if(pi % 16 === 0) bi++;
        next += STEP;
      }
    };
    ch.timers.push(setInterval(schedule, 200));
    schedule();
  }

  function genNight(ch){
    const BEAT = 60 / 90, BAR = BEAT * 4;
    const bus = gn(1); bus.connect(ch.gain); ch.nodes.push(bus);
    const del = ctx.createDelay(1); del.delayTime.value = BEAT * .5;
    const fb = gn(.42); del.connect(fb); fb.connect(del);
    const wet = gn(.5); del.connect(wet); wet.connect(bus);
    ch.nodes.push(del, fb, wet);
    const PENT = [40, 43, 45, 47, 50, 52];   /* E minor */
    let next = ctx.currentTime + .1;
    const schedule = () => {
      while(next < ctx.currentTime + .6){
        const t = next;
        for(let i = 0; i < 8; i++){
          const o = osc('sine', mtof(PENT[0]));
          const g = ctx.createGain();
          const tt = t + i * BEAT / 2;
          g.gain.setValueAtTime(i % 2 ? .05 : .09, tt);
          g.gain.exponentialRampToValueAtTime(.001, tt + BEAT * .45);
          o.connect(g); g.connect(bus);
          o.start(tt); o.stop(tt + BEAT * .5);
        }
        for(let i = 0; i < 8; i++){
          if(Math.random() < .45) continue;
          const n = PENT[1 + Math.floor(Math.random() * (PENT.length - 1))] + 12;
          const o = osc('triangle', mtof(n));
          const f = flt('lowpass', 1500, 1.5);
          const g = ctx.createGain();
          const tt = t + i * BEAT / 2;
          g.gain.setValueAtTime(.05, tt);
          g.gain.exponentialRampToValueAtTime(.001, tt + BEAT * .9);
          o.connect(f); f.connect(g); g.connect(wet);
          o.start(tt); o.stop(tt + BEAT);
        }
        const o = osc('sawtooth', mtof(PENT[1] + 12));
        const o2 = osc('sawtooth', mtof(PENT[1] + 12)); o2.detune.value = -8;
        const f = flt('lowpass', 650);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(.03, t + 1);
        g.gain.setValueAtTime(.03, t + BAR - 1);
        g.gain.linearRampToValueAtTime(0, t + BAR);
        o.connect(f); o2.connect(f); f.connect(g); g.connect(bus);
        o.start(t); o.stop(t + BAR); o2.start(t); o2.stop(t + BAR);
        next += BAR;
      }
    };
    ch.timers.push(setInterval(schedule, 250));
    schedule();
  }

  function genBowls(ch){
    const bus = gn(1); bus.connect(ch.gain); ch.nodes.push(bus);
    const FREQS = [110, 130.81, 146.83, 164.81, 196, 220];
    const strike = () => {
      const t = ctx.currentTime + .05;
      const f = FREQS[Math.floor(Math.random() * FREQS.length)];
      [[1, .16], [2.01, .06], [2.99, .03], [4.16, .012]].forEach(([m, a]) => {
        const o = osc('sine', f * m);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(a, t + .9);
        g.gain.exponentialRampToValueAtTime(.0001, t + 9);
        o.connect(g); g.connect(bus);
        o.start(t); o.stop(t + 9.2);
      });
      const o = osc('sine', f * 1.004);   /* slow beating between partials */
      const g = ctx.createGain();
      g.gain.setValueAtTime(0, t);
      g.gain.linearRampToValueAtTime(.07, t + 1.1);
      g.gain.exponentialRampToValueAtTime(.0001, t + 9);
      o.connect(g); g.connect(bus);
      o.start(t); o.stop(t + 9.2);
    };
    strike();
    ch.timers.push(setInterval(() => { if(Math.random() < .5) strike(); }, 4500));
  }

  function genBox(ch){
    const bus = gn(1); bus.connect(ch.gain); ch.nodes.push(bus);
    const del = ctx.createDelay(1); del.delayTime.value = .42;
    const fb = gn(.36); del.connect(fb); fb.connect(del);
    const wet = gn(.4); del.connect(wet); wet.connect(bus);
    const lp = flt('lowpass', 5200); lp.connect(bus);
    ch.nodes.push(del, fb, wet, lp);
    const SCALE = [72, 74, 76, 79, 81, 84, 86, 88];
    let idx = 3;
    const note = (t, n, v) => {
      [[1, 1], [4.02, .12], [6.9, .04]].forEach(([m, a]) => {
        const o = osc('sine', mtof(n) * m);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(v * a, t + .004);
        g.gain.exponentialRampToValueAtTime(.0001, t + 1.9);
        o.connect(g); g.connect(lp); g.connect(del);
        o.start(t); o.stop(t + 2);
      });
    };
    let next = ctx.currentTime + .2;
    ch.timers.push(setInterval(() => {
      while(next < ctx.currentTime + .8){
        idx = Math.max(0, Math.min(SCALE.length - 1, idx + Math.floor(Math.random() * 5) - 2));
        note(next, SCALE[idx], .06);
        if(Math.random() < .25) note(next + .15, SCALE[Math.min(SCALE.length - 1, idx + 2)], .04);
        next += .5 + Math.random() * 1.4;
      }
    }, 300));
  }

  /* ================= AMBIENCE generators ================= */

  function genWhite(ch){
    const src = noiseSrc('white');
    const lp = flt('lowpass', 9000);
    const g = gn(.5);
    src.connect(lp); lp.connect(g); g.connect(ch.gain); src.start();
    ch.nodes.push(src, lp, g);
  }

  function genBrown(ch){
    const src = noiseSrc('brown');
    const lp = flt('lowpass', 1100);
    const g = gn(.75);
    src.connect(lp); lp.connect(g); g.connect(ch.gain); src.start();
    ch.nodes.push(src, lp, g);
  }

  function genPink(ch){
    const src = noiseSrc('pink');
    const hp = flt('highpass', 70);
    const lp = flt('lowpass', 4800);
    const g = gn(.62);
    src.connect(hp); hp.connect(lp); lp.connect(g); g.connect(ch.gain); src.start();
    ch.nodes.push(src, hp, lp, g);
  }

  function genRain(ch){
    const src = noiseSrc('pink');
    const hp = flt('highpass', 500);
    const lp = flt('lowpass', 6500);
    const g = gn(.55);
    src.connect(hp); hp.connect(lp); lp.connect(g); g.connect(ch.gain); src.start();
    ch.nodes.push(src, hp, lp, g);
    ch.timers.push(setInterval(() => {
      if(Math.random() < 0.6) drop(ch.gain, 1600 + Math.random() * 2800, .04 + Math.random() * .1);
    }, 260));
  }
  function drop(out, freq, vol){
    const t = ctx.currentTime;
    const o = osc('sine', freq);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(vol, t + .005);
    g.gain.exponentialRampToValueAtTime(.0001, t + .08);
    o.connect(g); g.connect(out); o.start(t); o.stop(t + .1);
  }

  function genThunder(ch){
    genRain(ch);
    ch.timers.push(setInterval(() => {
      const t = ctx.currentTime + .05;
      if(Math.random() < .5){
        const src = ctx.createBufferSource(); src.buffer = noiseBuffer('white');
        const bp = flt('bandpass', 2600, 1);
        const g = ctx.createGain();
        g.gain.setValueAtTime(.1, t);
        g.gain.exponentialRampToValueAtTime(.0001, t + .12);
        src.connect(bp); bp.connect(g); g.connect(ch.gain);
        src.start(t); src.stop(t + .15);
      }
      const src = ctx.createBufferSource(); src.buffer = noiseBuffer('brown');
      const lp = flt('lowpass', 110);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0, t + .1);
      g.gain.linearRampToValueAtTime(.5, t + .5);
      g.gain.exponentialRampToValueAtTime(.0001, t + 4);
      src.connect(lp); lp.connect(g); g.connect(ch.gain);
      src.start(t + .1); src.stop(t + 4.2);
    }, 9000 + Math.floor(Math.random() * 12000)));
  }

  function genCafe(ch){
    const base = noiseSrc('brown');
    const bp = flt('bandpass', 380, .6);
    const g = gn(.9);
    base.connect(bp); bp.connect(g); g.connect(ch.gain); base.start();
    ch.nodes.push(base, bp, g);
    ch.timers.push(setInterval(() => {
      if(Math.random() < 0.4) clink(ch.gain);
    }, 1400));
  }
  function clink(out){
    const t = ctx.currentTime;
    [1, 1.5].forEach((mul, i) => {
      const o = osc('triangle', (1900 + Math.random() * 900) * mul);
      const g = ctx.createGain();
      g.gain.setValueAtTime(i === 0 ? .05 : .02, t + i * .06);
      g.gain.exponentialRampToValueAtTime(.0001, t + i * .06 + .5);
      o.connect(g); g.connect(out);
      o.start(t + i * .06); o.stop(t + i * .06 + .55);
    });
  }

  function genFire(ch){
    const base = noiseSrc('brown');
    const lp = flt('lowpass', 420);
    const g = gn(.65);
    base.connect(lp); lp.connect(g); g.connect(ch.gain); base.start();
    ch.nodes.push(base, lp, g);
    ch.timers.push(setInterval(() => {
      const n = Math.random() < .5 ? 1 : 2;
      for(let i = 0; i < n; i++) pop(ch.gain);
    }, 180));
  }
  function pop(out){
    const t = ctx.currentTime + Math.random() * .12;
    const src = ctx.createBufferSource(); src.buffer = noiseBuffer('white');
    const bp = flt('bandpass', 900 + Math.random() * 2600, 2);
    const g = ctx.createGain();
    g.gain.setValueAtTime(.06 + Math.random() * .22, t);
    g.gain.exponentialRampToValueAtTime(.0001, t + .03 + Math.random() * .05);
    src.connect(bp); bp.connect(g); g.connect(out);
    src.start(t); src.stop(t + .12);
  }

  function genWaves(ch){
    const mk = offset => {
      const src = noiseSrc('brown');
      const lp = flt('lowpass', 550);
      const swell = gn(.19);
      const lfo = osc('sine', .07 + offset * .013);
      const depth = gn(.16);
      lfo.connect(depth); depth.connect(swell.gain);
      src.connect(lp); lp.connect(swell); swell.connect(ch.gain);
      src.start(); lfo.start();
      ch.nodes.push(src, lp, swell, lfo, depth);
    };
    mk(0); mk(1);
  }

  function genForest(ch){
    const wind = noiseSrc('pink');
    const bp = flt('bandpass', 550, .5);
    const wg = gn(.12);
    const lfo = osc('sine', .04);
    const depth = gn(.08);
    lfo.connect(depth); depth.connect(wg.gain);
    wind.connect(bp); bp.connect(wg); wg.connect(ch.gain);
    wind.start(); lfo.start();
    ch.nodes.push(wind, bp, wg, lfo, depth);
    const chirp = (t0, freq) => {
      const n = 6 + Math.floor(Math.random() * 10);
      for(let i = 0; i < n; i++){
        const t = t0 + i * .048;
        const o = osc('sine', freq);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0, t);
        g.gain.linearRampToValueAtTime(.035, t + .008);
        g.gain.exponentialRampToValueAtTime(.0001, t + .026);
        o.connect(g); g.connect(ch.gain);
        o.start(t); o.stop(t + .04);
      }
    };
    ch.timers.push(setInterval(() => {
      const trains = 1 + Math.floor(Math.random() * 3);
      for(let k = 0; k < trains; k++)
        chirp(ctx.currentTime + Math.random() * 1.5, 3800 + Math.random() * 1600);
    }, 2600));
  }

  /* ---------- UI sfx ---------- */
  function sfx(name){
    try{
      if(!ensure()) return;
      const t = ctx.currentTime;
      const tone = (freq, at, dur, vol = .08) => {
        const o = osc('sine', freq);
        const g = ctx.createGain();
        g.gain.setValueAtTime(0, t + at);
        g.gain.linearRampToValueAtTime(vol, t + at + .01);
        g.gain.exponentialRampToValueAtTime(.0001, t + at + dur);
        o.connect(g); g.connect(sfxBus);
        o.start(t + at); o.stop(t + at + dur + .05);
      };
      if(name === 'start'){ tone(523, 0, .15); tone(659, .09, .15); }
      else if(name === 'stop'){ tone(659, 0, .15); tone(523, .1, .2); }
      else if(name === 'pause'){ tone(440, 0, .12, .06); }
      else if(name === 'chime'){ tone(880, 0, .5, .07); tone(1318, .02, .6, .05); }
      else if(name === 'chime2'){ tone(660, 0, .4, .06); tone(990, .02, .5, .045); }
      else if(name === 'done'){ tone(784, 0, .12, .06); tone(1046, .08, .2, .06); }
      else if(name === 'level'){ tone(523, 0, .12); tone(659, .1, .12); tone(784, .2, .12); tone(1046, .3, .3); }
      else if(name === 'alert'){ tone(392, 0, .09, .07); tone(311, .13, .13, .07); }
      else if(name === 'pop'){ tone(880, 0, .06, .04); }
    }catch(e){}
  }

  /* ---------- UI ---------- */
  function syncUI(){
    $$('[data-sound]').forEach(node => {
      const on = active.has(node.dataset.sound);
      if(node.classList.contains('chip') || node.classList.contains('snd')) node.classList.toggle('active', on);
      if(node.classList.contains('snd')) node.classList.toggle('on', on);
      if(node.classList.contains('tile')) node.classList.toggle('on', on);
    });
    const vs = vols();
    $$('[data-vol]').forEach(r => {
      const v = vs[r.dataset.vol] != null ? vs[r.dataset.vol] : defVol(r.dataset.vol);
      r.value = Math.round(v * 100);
    });
    $$('[data-sleep]').forEach(c => c.classList.toggle('active', String(sleepMin) === c.dataset.sleep));
    const musicOn = !!(window.Music && Music.isPlaying && Music.isPlaying());
    const mp = $('#mini-player'), cnt = $('#mini-count');
    if(mp){
      mp.classList.toggle('playing', active.size > 0 || musicOn);
      mp.title = musicOn && Music.nowTitle ? 'Tape Deck — ' + Music.nowTitle() : 'Tape Deck';
    }
    if(cnt) cnt.textContent = active.size + (musicOn ? 1 : 0);
  }

  function renderMixer(){
    const box = $('#mixer-list'); if(!box) return;
    const vs = vols();
    const card = c => {
      const v = Math.round((vs[c.id] != null ? vs[c.id] : c.vol) * 100);
      return '<div class="snd" data-sound="' + c.id + '" style="--th:' + c.hue + '">' +
        '<span class="snd-ic"><i class="fa-solid ' + c.icon + '"></i>' +
          '<span class="snd-eq"><i></i><i></i><i></i></span></span>' +
        '<div class="snd-txt"><b>' + c.name + '</b><small>' + c.desc + '</small></div>' +
        '<button class="snd-play" type="button" aria-label="Toggle ' + c.name + '">' +
          '<i class="fa-solid fa-play"></i><i class="fa-solid fa-pause"></i></button>' +
        '<input type="range" class="snd-vol" data-vol="' + c.id + '" min="0" max="100" value="' + v + '" aria-label="' + c.name + ' volume">' +
      '</div>';
    };
    box.innerHTML = GROUPS.map(g =>
      '<div class="snd-group"><span>' + g.label + '</span><i></i><small>' + g.hint + '</small></div>' +
      '<div class="snd-grid">' + CHANNELS.filter(c => c.cat === g.id).map(card).join('') + '</div>'
    ).join('');
  }

  function bindUI(){
    renderMixer();
    const pr = $('#preset-row');
    if(pr) pr.innerHTML = PRESETS.map((p, i) =>
      '<button class="chip" data-preset="' + i + '" type="button"><i class="fa-solid ' + p.icon + '"></i>' + p.name + '</button>').join('');
    const vol = $('#master-vol');
    if(vol){
      vol.value = Math.round(volume * 100);
      vol.addEventListener('input', () => setVolume(vol.value / 100));
    }
    const stop = $('#stop-all');
    if(stop) stop.addEventListener('click', () => { stopAll(); if(window.Music) Music.stop(); });
    syncUI();
  }

  /* delegated events */
  document.addEventListener('click', e => {
    if(e.target.closest('input[type=range]')) return;
    const p = e.target.closest('[data-preset]');
    if(p) return applyPreset(PRESETS[+p.dataset.preset]);
    const s = e.target.closest('[data-sleep]');
    if(s) return (String(sleepMin) === s.dataset.sleep) ? clearSleep() : setSleep(+s.dataset.sleep);
    const node = e.target.closest('[data-sound]');
    if(node) toggle(node.dataset.sound);
  });
  document.addEventListener('input', e => {
    const r = e.target.closest('[data-vol]');
    if(r) setChannelVol(r.dataset.vol, r.value / 100);
  });

  return { toggle, stopAll, sfx, setVolume, syncUI, renderMixer, bindUI, isActive: id => active.has(id), activeCount: () => active.size };
})();
window.Sound = Sound;