/* profile.js — YPT-style profiles. Click your avatar or any room member. */
'use strict';

const Profile = (function(){

  function init(){
    const modal = $('#profile-modal');
    if(!modal) return;
    const close = $('#profile-close');
    if(close) close.addEventListener('click', () => { modal.style.display = 'none'; });
    modal.addEventListener('click', e => { if(e.target === modal) modal.style.display = 'none'; });
    const body = $('#profile-body');
    if(body) body.addEventListener('click', e => {
      const btn = e.target.closest('[data-demo]');
      if(!btn || !window.Demo) return;
      if(btn.dataset.demo === 'load'){
        if(!confirm('Load demo data? Your real data will be backed up first.')) return;
        Demo.load();
        Profile.show();
      }else if(btn.dataset.demo === 'restore'){
        Demo.restore();
        Profile.show();
      }
    });
  }

  function open(html){
    const modal = $('#profile-modal'), body = $('#profile-body');
    if(!modal || !body) return;
    body.innerHTML = html;
    modal.style.display = 'flex';
  }

  /* ---------- shared blocks ---------- */

  function badgeGrid(earnedIds){
    const all = window.Tracker ? Tracker.badges() : [];
    return all.map((b, i) => {
      const c = PALETTE[i % PALETTE.length];
      const e = earnedIds.has(b.id);
      return '<span class="pm-badge ' + (e ? 'earned' : '') + '" ' +
        (e ? 'style="--c:' + c + ';color:color-mix(in srgb,' + c + ' 55%,var(--text));border-color:' + c + '55;background:' + c + '14"' : '') +
        ' title="' + escapeHTML(b.name + ' — ' + b.desc) + '"><i class="fa-solid ' + b.icon + '"></i></span>';
    }).join('');
  }

  function subjectBars(map, top = 5){
    const rows = Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, top);
    if(!rows.length) return '<p class="sub" style="padding:6px 0">No subject data yet</p>';
    const max = rows[0][1];
    return rows.map(([name, sec]) => {
      const c = hueFor(name);
      return '<div class="pm-sub-row">' +
        '<span class="n">' + escapeHTML(name) + '</span>' +
        '<span class="track"><span class="fill" style="width:' + Math.max(4, sec / max * 100) + '%;background:' + c + '"></span></span>' +
        '<span class="v mono">' + fmtDur(sec) + '</span>' +
      '</div>';
    }).join('');
  }

  const statCard = (icon, label, val, c) =>
    '<div class="pm-stat" style="--c:color-mix(in srgb,' + c + ' 55%,var(--text))"><span><i class="fa-solid ' + icon + '"></i>' + label + '</span><b class="mono">' + val + '</b></div>';

  const banner = (hue, av, name, sub, statusHtml, xpHtml) =>
    '<div class="pm-banner" style="--ph:' + safeColor(hue, '#F6B93B') + '">' +
      '<div class="pm-top">' +
        '<span class="pm-av">' + escapeHTML(av) + '</span>' +
        '<div class="pm-id">' +
          '<div class="pm-name">' + escapeHTML(name) + '</div>' +
          '<div class="pm-sub">' + sub + '</div>' +
          statusHtml +
        '</div>' +
      '</div>' + xpHtml +
    '</div>';

  const xpBlock = li =>
    '<div class="pm-xp">' +
      '<div class="xp-row mono"><span>LEVEL ' + li.level + '</span><span>' + li.into + ' / ' + li.need + ' XP</span></div>' +
      '<div class="xp-track"><i style="width:' + li.pct + '%"></i></div>' +
    '</div>';

  /* ================= MY PROFILE ================= */

  function show(){
    const u = State.user || { name: 'You', hue: '#F6B93B', since: Date.now() };
    const sessions = Store.get('sessions', []);
    const stats = Tracker.stats();
    const li = Tracker.levelInfo(Store.get('stats', { xp: 0, badges: [] }).xp);
    const today = Tracker.todaySeconds();

    /* week + month */
    const keys = new Set();
    for(let i = 0; i < 7; i++){ const d = new Date(); d.setDate(d.getDate() - i); keys.add(dateKey(d)); }
    const mp = dateKey().slice(0, 7);
    let week = 0, month = 0;
    sessions.forEach(s => {
      if(keys.has(s.date)) week += s.seconds;
      if(s.date.slice(0, 7) === mp) month += s.seconds;
    });
    week += Tracker.liveSec();

    /* guard average */
    const guardS = sessions.filter(s => s.focusPct != null);
    const avgFocus = guardS.length ? Math.round(guardS.reduce((a, s) => a + s.focusPct, 0) / guardS.length) : null;

    /* subject map all-time */
    const map = {};
    sessions.forEach(s => { map[s.subject] = (map[s.subject] || 0) + s.seconds; });

    const earned = new Set(Store.get('stats', { xp: 0, badges: [] }).badges.map(b => b.id));
    const recent = sessions.slice(-6).reverse();

    const html =
      banner(u.hue, u.name.charAt(0).toUpperCase(), u.name,
        '<span><i class="fa-solid fa-bolt"></i> Level ' + li.level + '</span>' +
        '<span>·</span><span><i class="fa-solid fa-calendar"></i> Joined ' + fmtAgo(u.since || Date.now()) + '</span>',
        Tracker.isActive()
          ? '<span class="pm-status live"><i class="fa-solid fa-circle"></i>Studying ' + escapeHTML(Tracker.activeSubject()) + '</span>'
          : '<span class="pm-status">Offline · studying</span>',
        xpBlock(li)) +
      '<div class="pm-body">' +
        '<div class="pm-stats">' +
          statCard('fa-bolt',      'Today',      fmtDur(today),           '#4FB286') +
          statCard('fa-calendar',  'This week',  fmtDur(week),            '#F6B93B') +
          statCard('fa-hourglass', 'This month', fmtDur(month),           '#D9B45B') +
          statCard('fa-clock',     'Total time', fmtDur(stats.totalMin * 60), '#5B9BD5') +
          statCard('fa-fire',      'Streak',     stats.streak + 'd',      '#E8703A') +
          statCard('fa-camera',    'Avg focus',  avgFocus == null ? '—' : avgFocus + '%', '#A78BDB') +
        '</div>' +
        '<div class="pm-sec"><div class="rail-head"><p class="label">Badges · ' + earned.size + '/' + (Tracker.badges().length) + '</p></div>' +
          '<div class="pm-badges">' + badgeGrid(earned) + '</div></div>' +
        '<div class="pm-sec"><div class="rail-head"><p class="label">Subjects · all time</p></div>' +
          '<div class="pm-subs">' + subjectBars(map) + '</div></div>' +
        '<div class="pm-sec"><div class="rail-head"><p class="label">Recent sessions</p><span class="sub mono">' + stats.count + ' total</span></div>' +
          '<div class="pm-recent">' +
            (recent.length ? recent.map(s => {
              const c = hueFor(s.subject);
              return '<div class="pm-rec-row" style="--c:' + c + '">' +
                '<span class="chip-s">' + escapeHTML(s.subject) + '</span>' +
                '<span class="sub">' + (s.guard ? 'AI Guard' + (s.focusPct != null ? ' · ' + s.focusPct + '%' : '') : (s.mode === 'pomodoro' ? 'Pomodoro ×' + (s.pomodoros || 0) : 'Stopwatch')) +  + '</span>' +
                '<span class="d mono">' + fmtDur(s.seconds) + '</span>' +
                '<span class="a">' + fmtAgo(s.endedAt) + '</span>' +
              '</div>';
            }).join('') : '<p class="sub" style="padding:6px 0">No sessions yet</p>') +
          '</div></div>' +
        '<details class="pm-sec">' +
          '<summary>Testing tools</summary>' +
          '<div style="display:flex;flex-wrap:wrap;gap:8px;margin-top:10px">' +
            '<button class="btn btn-ghost" type="button" data-demo="load">Load demo data</button>' +
            '<button class="btn btn-ghost" type="button" data-demo="restore"' + (window.Demo && Demo.isLoaded() ? '' : ' disabled') + '>Restore my data</button>' +
          '</div>' +
          '<p class="sub" style="margin-top:8px">Demo data replaces your stats until you restore. Sessions you log meanwhile are lost on restore. Your real data is backed up first.</p>' +
        '</details>' +
      '</div>';

    open(html);
  }

  /* ================= BOT PROFILE ================= */

  function showMember(m){
    /* deterministic stats seeded from member id — stable between opens */
    let seed = hstr(m.id);
    const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };

    const totalSec = (400 + Math.floor(rnd() * 2600)) * 60;
    const week = m.weekSec || Math.floor(totalSec * 0.12);
    const streak = Math.floor(rnd() * 15);
    const sessionsN = 20 + Math.floor(rnd() * 140);
    const avgFocus = 62 + Math.floor(rnd() * 36);
    const sinceDays = 3 + Math.floor(rnd() * 180);

    /* subject distribution */
    const subs = [...SUBJECTS].sort(() => rnd() - 0.5).slice(0, 4);
    let left = totalSec;
    const map = {};
    subs.forEach((s, i) => {
      const frac = i === subs.length - 1 ? left : Math.floor(left * (0.25 + rnd() * 0.45));
      map[s] = frac; left -= frac;
    });

    /* badge subset */
    const all = window.Tracker ? Tracker.badges() : [];
    const nEarn = Math.min(all.length, 2 + Math.floor(rnd() * 6));
    const pool = [...all].sort(() => rnd() - 0.5).slice(0, nEarn);
    const earned = new Set(pool.map(b => b.id));

    const li = Tracker.levelInfo(m.level * 180);

    const html =
      banner(m.hue, m.name.charAt(0).toUpperCase(), m.name,
        '<span><i class="fa-solid fa-bolt"></i> Level ' + m.level + '</span>' +
        '<span>·</span><span><i class="fa-solid fa-calendar"></i> Active ' + sinceDays + ' days</span>',
        m.studying
          ? '<span class="pm-status live"><i class="fa-solid fa-circle"></i>Studying ' + escapeHTML(m.subject || '') + '</span>'
          : '<span class="pm-status">Taking a break</span>',
        xpBlock(li)) +
      '<div class="pm-body">' +
        '<div class="pm-stats">' +
          statCard('fa-bolt',     'Today',      fmtDur(m.todaySec || 0), '#4FB286') +
          statCard('fa-calendar', 'This week',  fmtDur(week),            '#F6B93B') +
          statCard('fa-clock',    'Total time', fmtDur(totalSec),        '#5B9BD5') +
          statCard('fa-fire',     'Streak',     streak + 'd',            '#E8703A') +
          statCard('fa-clipboard', 'Sessions',  sessionsN + '',          '#E4739C') +
          statCard('fa-camera',   'Avg focus',  avgFocus + '%',          '#A78BDB') +
        '</div>' +
        '<div class="pm-sec"><div class="rail-head"><p class="label">Badges · ' + earned.size + '/' + all.length + '</p></div>' +
          '<div class="pm-badges">' + badgeGrid(earned) + '</div></div>' +
        '<div class="pm-sec"><div class="rail-head"><p class="label">Subjects · all time</p></div>' +
          '<div class="pm-subs">' + subjectBars(map) + '</div></div>' +
        '<p class="pm-note"><i class="fa-solid fa-circle-info" style="margin-right:5px"></i>Simulated member — demo build</p>' +
      '</div>';

    open(html);
  }

  return { init, show, showMember };
})();
window.Profile = Profile;