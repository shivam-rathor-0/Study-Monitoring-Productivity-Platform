/* dashboard.js — home view: stats, streak, gradient chart, calendar, badges */
'use strict';

const Dashboard = (function(){

  const GOAL_C = 2 * Math.PI * 52;
  const cal = { y: new Date().getFullYear(), m: new Date().getMonth() };

  function refresh(){
    if(State.view !== 'home') return;
    const h = new Date().getHours();
    const greet = h < 5 ? 'Late night grind' : h < 12 ? 'Good morning'
                : h < 17 ? 'Good afternoon' : h < 21 ? 'Good evening' : 'Night session';
    const name = State.user ? State.user.name : '';
    $('#home-greeting').textContent = greet + (name ? ', ' + name : '');
    $('#home-date').textContent =
      new Date().toLocaleDateString(undefined, { weekday:'long', day:'numeric', month:'long' }) +
      ' · ' + Store.get('sessions', []).length + ' total sessions';
    updateToday();
    renderMiniStats();
    renderStreak();
    renderChart();
    renderSubjects();
    renderBadges();
    renderTasksPreview();
    renderCalendar();
  }

  function goalMin(){ return Store.get('settings', {}).dailyGoal || 120; }

  function updateToday(){
    if(State.view !== 'home') return;
    const today = window.Tracker ? Tracker.todaySeconds() : 0;
    $('#home-today').textContent = fmtDur(today);
    const ms = $('#ms-today');
    if(ms) ms.textContent = fmtDur(today);
    const n = Store.get('sessions', []).filter(s => s.date === dateKey()).length;
    $('#home-sessions').textContent = n === 0 ? 'No sessions yet today' : n + ' session' + (n > 1 ? 's' : '') + ' today';

    const pct = Math.min(100, today / (goalMin() * 60) * 100);
    const ring = $('#goal-ring');
    if(ring){
      ring.style.strokeDasharray = GOAL_C;
      ring.style.strokeDashoffset = GOAL_C * (1 - pct / 100);
    }
    $('#goal-pct').textContent = Math.floor(pct) + '%';
    $('#goal-progress').textContent = fmtDur(today) + ' / ' + goalMin() + 'm';
  }

  function renderMiniStats(){
    const s = window.Tracker ? Tracker.stats() : null;
    if(!s) return;
    const li = Tracker.levelInfo(Store.get('stats', { xp:0, badges:[] }).xp);
    const streak = s.streak;
    const msS = $('#ms-streak'), msL = $('#ms-level'), msT = $('#ms-total');
    if(msS) msS.textContent = streak + 'd';
    if(msL) msL.textContent = 'Lv ' + li.level;
    if(msT) msT.textContent = fmtDur(s.totalMin * 60);
  }

  function renderStreak(){
    const streak = window.Tracker ? Tracker.calcStreak(Store.get('sessions', [])) : 0;
    $('#home-streak').innerHTML = streak +
      '<span class="unit">day' + (streak === 1 ? '' : 's') + '</span> <i class="fa-solid fa-fire flame"></i>';
    $('#streak-hint').textContent = streak === 0
      ? 'Complete a session today to start a streak'
      : streak < 3 ? 'Keep going — a badge unlocks at 3 days' : 'Solid streak — do not break the chain';
  }

  function weekData(){
    const map = {};
    Store.get('sessions', []).forEach(s => map[s.date] = (map[s.date] || 0) + s.seconds);
    const out = [];
    for(let i = 6; i >= 0; i--){
      const d = new Date(); d.setDate(d.getDate() - i);
      out.push({ label: dayLabel(d), key: dateKey(d), sec: map[dateKey(d)] || 0, today: i === 0 });
    }
    return out;
  }

  function renderChart(){
    const svg = $('#week-chart'); if(!svg) return;
    const data = weekData();
    const goal = goalMin() * 60;
    const max = Math.max(goal, ...data.map(x => x.sec), 3600);
    const W = 640, base = 168, top = 18;
    const bw = 46, gap = (W - 7 * bw) / 8;

    let out = '<defs>' +
      '<linearGradient id="wg" x1="0" y1="1" x2="0" y2="0">' +
        '<stop offset="0" style="stop-color:color-mix(in srgb,var(--accent-2) 70%,var(--bg))"/><stop offset="1" style="stop-color:var(--accent)"/></linearGradient>' +
      '<linearGradient id="wg2" x1="0" y1="1" x2="0" y2="0">' +
        '<stop offset="0" style="stop-color:var(--accent-2)"/><stop offset="1" style="stop-color:color-mix(in srgb,var(--accent) 55%,white)"/></linearGradient>' +
    '</defs>';

    data.forEach((x, i) => {
      const h = Math.max(x.sec > 0 ? 6 : 3, (x.sec / max) * (base - top));
      const bx = gap + i * (bw + gap);
      const by = base - h;
      out += '<g>' +
        '<rect class="bar ' + (x.today ? 'today' : '') + '" x="' + bx + '" y="' + by +
          '" width="' + bw + '" height="' + h + '" rx="6"><title>' + x.label + ' — ' + fmtDur(x.sec) + '</title></rect>' +
        '<text class="axis" x="' + (bx + bw / 2) + '" y="' + (base + 18) + '" text-anchor="middle">' + x.label + '</text>' +
        (x.sec > 0 ? '<text class="axis val" x="' + (bx + bw / 2) + '" y="' + (by - 6) + '" text-anchor="middle">' + fmtDur(x.sec) + '</text>' : '') +
      '</g>';
    });
    const gy = base - (goal / max) * (base - top);
    out += '<line class="goal-line" x1="' + gap / 2 + '" y1="' + gy + '" x2="' + (W - gap / 2) + '" y2="' + gy + '"/>' +
      '<text class="goal-tag" x="' + (W - gap / 2) + '" y="' + (gy - 5) + '" text-anchor="end">goal ' + fmtDur(goal) + '</text>';
    svg.innerHTML = out;
    $('#chart-total').textContent = fmtDur(data.reduce((a, x) => a + x.sec, 0)) + ' total';
  }

  function renderSubjects(){
    const box = $('#subject-bars'); if(!box) return;
    const keys = new Set();
    for(let i = 0; i < 7; i++){ const d = new Date(); d.setDate(d.getDate() - i); keys.add(dateKey(d)); }
    const map = {};
    Store.get('sessions', []).forEach(s => { if(keys.has(s.date)) map[s.subject] = (map[s.subject] || 0) + s.seconds; });
    const rows = Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 6);
    if(!rows.length){
      box.innerHTML = '<div class="empty"><i class="fa-solid fa-book-open"></i><p>Subject breakdown appears after your first sessions this week</p></div>';
      return;
    }
    const max = rows[0][1];
    box.innerHTML = rows.map(([name, sec]) => {
      const c = hueFor(name);
      return '<div class="subject-row">' +
        '<span class="name" style="color:color-mix(in srgb,' + c + ' 55%,var(--text))">' + escapeHTML(name) + '</span>' +
        '<span class="track"><span class="fill" style="width:' + Math.max(4, sec / max * 100) + '%;background:linear-gradient(90deg,' + c + '88,' + c + ')"></span></span>' +
        '<span class="val mono">' + fmtDur(sec) + '</span>' +
      '</div>';
    }).join('');
  }

  function renderBadges(){
    const box = $('#badge-row'); if(!box) return;
    const st = Store.get('stats', { xp: 0, badges: [] });
    const earned = new Set(st.badges.map(b => b.id));
    const all = window.Tracker ? Tracker.badges() : [];
    box.innerHTML = all.map((b, i) => {
      const c = PALETTE[i % PALETTE.length];
      const e = earned.has(b.id);
      return '<span class="badge ' + (e ? 'earned' : '') + '" ' +
        (e ? 'style="color:color-mix(in srgb,' + c + ' 55%,var(--text));border-color:' + c + ';background:' + c + '1A"' : '') +
        ' title="' + escapeHTML(b.name + ' — ' + b.desc) + '"><i class="fa-solid ' + b.icon + '"></i></span>';
    }).join('');
    $('#badge-count').textContent = earned.size + '/' + all.length;
  }

  function renderTasksPreview(){
    const box = $('#tasks-preview'); if(!box) return;
    const tasks = (window.Tasks ? Tasks.list() : []).filter(t => !t.done).slice(0, 4);
    if(!tasks.length){
      box.innerHTML = '<div class="empty" style="padding:18px 0"><i class="fa-solid fa-mug-hot"></i><p>All clear — or add some new tasks</p></div>';
      return;
    }
    const pr = t => (t.p == null ? 1 : t.p);
    box.innerHTML = tasks.map(t =>
      '<div class="preview-task">' +
        '<span class="pdot p' + pr(t) + '"></span>' +
        '<button class="task-check" data-check="' + t.id + '" type="button"></button>' +
        '<span>' + escapeHTML(t.title) + '</span>' +
        '<span class="subj" style="color:color-mix(in srgb,' + hueFor(t.subject) + ' 55%,var(--text))">' + escapeHTML(t.subject) + '</span>' +
      '</div>').join('');
  }

  /* ---------- calendar heatmap ---------- */
  function renderCalendar(){
    const grid = $('#cal-grid'); if(!grid) return;
    const now = new Date();
    const isThisMonth = cal.y === now.getFullYear() && cal.m === now.getMonth();
    if(cal.y > now.getFullYear() || (cal.y === now.getFullYear() && cal.m > now.getMonth())){
      cal.y = now.getFullYear(); cal.m = now.getMonth();
    }
    const map = {};
    let monthSec = 0;
    Store.get('sessions', []).forEach(s => {
      const [y, m] = s.date.split('-');
      if(+y === cal.y && (+m - 1) === cal.m){ map[s.date] = (map[s.date] || 0) + s.seconds; monthSec += s.seconds; }
    });

    const first = new Date(cal.y, cal.m, 1);
    const lead = (first.getDay() + 6) % 7;
    const days = new Date(cal.y, cal.m + 1, 0).getDate();

    let out = '';
    for(let i = 0; i < lead; i++) out += '<span class="cal-cell blank"></span>';
    for(let d = 1; d <= days; d++){
      const key = cal.y + '-' + String(cal.m + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0');
      const sec = map[key] || 0;
      const tier = sec >= 120 ? 't4' : sec >= 60 ? 't3' : sec >= 30 ? 't2' : sec > 0 ? 't1' : '';
      const today = isThisMonth && d === now.getDate();
      const future = isThisMonth && d > now.getDate();
      const label = new Date(cal.y, cal.m, d).toLocaleDateString(undefined, { weekday:'short', day:'numeric', month:'short' });
      out += '<span class="cal-cell ' + tier + (today ? ' today' : '') + (future ? ' off' : '') + '"' +
        ' title="' + label + ' — ' + (sec ? fmtDur(sec) : 'no study') + '"></span>';
    }
    grid.innerHTML = out;
    $('#cal-month').textContent = new Date(cal.y, cal.m, 1).toLocaleDateString(undefined, { month:'long', year:'numeric' });
    $('#cal-total').textContent = fmtDur(monthSec) + ' studied this month';
  }

  function onTick(){ updateToday(); }

  function bind(){
    const gi = $('#goal-input');
    if(gi){
      gi.value = goalMin();
      gi.addEventListener('change', () => {
        const c = Store.get('settings', {});
        c.dailyGoal = Math.min(720, Math.max(15, parseInt(gi.value) || 120));
        gi.value = c.dailyGoal;
        Store.set('settings', c);
        refresh();
      });
    }
    const box = $('#tasks-preview');
    if(box) box.addEventListener('click', e => {
      const c = e.target.closest('[data-check]');
      if(c && window.Tasks) Tasks.toggle(c.dataset.check);
    });
    const view = $('#view-home');
    if(view) view.addEventListener('click', e => {
      const b = e.target.closest('[data-cal]');
      if(!b) return;
      let m = cal.m + parseInt(b.dataset.cal), y = cal.y;
      if(m < 0){ m = 11; y--; }
      if(m > 11){ m = 0; y++; }
      const now = new Date();
      if(y > now.getFullYear() || (y === now.getFullYear() && m > now.getMonth())) return;
      cal.m = m; cal.y = y;
      renderCalendar();
    });
  }

  return { refresh, onTick, bind };
})();
window.Dashboard = Dashboard;