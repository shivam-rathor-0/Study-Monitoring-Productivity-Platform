/* app.js — login, hash router, dynamic-island chrome, boot, shortcuts */
'use strict';

const App = (function(){

  const HUES = ['#F6B93B','#4FB286','#5B9BD5','#C97B63','#A78BDB','#C9A227','#7FBFB0','#E4739C'];
  const ROUTES = ['home','focus','tasks','practice','rooms','sounds'];
  let selHue = HUES[0];

  /* ---------- login ---------- */

  function showLogin(){
    const box = $('#hue-swatches');
    if(box && !box.children.length){
      HUES.forEach(h => {
        const dot = el('button', {
          type: 'button',
          class: 'hue-dot' + (h === selHue ? ' active' : ''),
          style: 'background:' + h,
          onclick(){
            selHue = h;
            $$('.hue-dot', box).forEach(x => x.classList.toggle('active', x === dot));
          }
        });
        box.append(dot);
      });
    }
  }

  function enter(name, hue, remember){
    hue = safeColor(hue, '#F6B93B');
    State.user = { name, hue, since: Date.now() };
    if(remember) Store.set('user', State.user);

    const screen = $('#login-screen');
    if(screen){
      screen.classList.add('hide');
      setTimeout(() => document.body.classList.add('logged-in'), 480);
    }else{
      document.body.classList.add('logged-in');
    }

    $('#user-name').textContent = name;
    const av = $('#user-avatar');
    av.textContent = name.charAt(0).toUpperCase();
    av.style.background = hue;

    Tracker.renderXPPill();
    Tracker.renderLog();
    route();
    requestAnimationFrame(() => { positionInd(); positionDock(); });
    toast('Welcome, ' + name + ' — ready to focus?', 'success');
  }

  function bindLogin(){
    const form = $('#login-form');
    if(form) form.addEventListener('submit', e => {
      e.preventDefault();
      const name = $('#login-name').value.trim();
      if(!name){ toast('Please enter your name first', 'warn'); return; }
      enter(name, selHue, true);
    });
    const demo = $('#demo-login');
    if(demo) demo.addEventListener('click', () => {
      const names = ['Scholar','Bookworm','Topper','Night Owl','Grinder'];
      $('#login-name').value = names[Math.floor(Math.random() * names.length)];
      selHue = HUES[Math.floor(Math.random() * HUES.length)];
      enter($('#login-name').value, selHue, true);
    });
  }

  /* ---------- dynamic island indicators ---------- */

  function positionInd(){
    const nav = $('#nav-island'), ind = $('#nav-ind');
    if(!nav || !ind) return;
    const btn = nav.querySelector('.nav-item.active');
    if(!btn) return;
    ind.style.width = btn.offsetWidth + 'px';
    ind.style.transform = 'translateX(' + btn.offsetLeft + 'px)';
  }
  function positionDock(){
    const dock = $('#bottom-nav'), ind = $('#dock-ind');
    if(!dock || !ind) return;
    const btn = dock.querySelector('.bnav-item.active');
    if(!btn) return;
    ind.style.width = btn.offsetWidth + 'px';
    ind.style.transform = 'translateX(' + btn.offsetLeft + 'px)';
  }

  /* ---------- router ---------- */

  function show(view){
    State.view = view;
    $$('.view').forEach(v => v.classList.toggle('active', v.id === 'view-' + view));
    $$('.nav-item,.bnav-item').forEach(n => n.classList.toggle('active', n.dataset.route === view));
    requestAnimationFrame(() => { positionInd(); positionDock(); });
    if(view === 'home' && window.Dashboard) Dashboard.refresh();
    if(view === 'focus' && window.Tracker) Tracker.onShow();
    else if(view !== 'focus' && window.Tracker && Tracker.onLeaveFocus) Tracker.onLeaveFocus();
    if(view === 'tasks' && window.Tasks) Tasks.render();
    if(view === 'practice'){
      if(window.Quiz && Quiz.onShow) Quiz.onShow();
      if(window.Code && Code.onShow) Code.onShow();
    }
    if(view === 'sounds'){
      if(window.Sound) Sound.syncUI();
      if(window.Music) Music.onShow();
    }else if(window.Music) Music.onHide();
    if(view === 'rooms' && window.Rooms) Rooms.onShow();
    if(view !== 'rooms' && window.Rooms) Rooms.setActive(false);
    window.scrollTo(0, 0);
  }

  function route(){
    const hash = location.hash.replace(/^#\/?/, '');
    const parts = hash.split('/');
    if(parts[0] === 'join' && parts[1]){
      const code = safeCode(safeDecode(parts[1]));
      if(!code){ show('home'); return; }
      if(window.Rooms) Rooms.showJoinModal(code);
      show('rooms');
      return;
    }
    if(parts[0] === 'rooms' && parts[1]){
      const code = safeCode(safeDecode(parts[1]));
      if(!code){ show('home'); return; }
      if(window.Rooms) Rooms.open(code);
      show('rooms');
      Rooms.setActive(true);
      return;
    }
    show(ROUTES.includes(parts[0]) ? parts[0] : 'home');
  }

  /* ---------- practice sub-tabs ---------- */

  function applyPracticeTab(tab){
    if(tab !== 'quiz' && tab !== 'code') tab = 'quiz';
    const seg = $('#practice-seg');
    if(seg) $$('.seg-btn', seg).forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
    const quiz = $('#practice-quiz'), code = $('#practice-code');
    if(quiz) quiz.style.display = tab === 'quiz' ? '' : 'none';
    if(code) code.style.display = tab === 'code' ? '' : 'none';
  }

  function bindPractice(){
    const seg = $('#practice-seg');
    if(!seg) return;
    applyPracticeTab(Store.get('practiceTab', 'quiz'));
    $$('.seg-btn', seg).forEach(b => b.addEventListener('click', () => {
      Store.set('practiceTab', b.dataset.tab);
      applyPracticeTab(b.dataset.tab);
    }));
  }

  /* ---------- chrome bindings ---------- */

  function bindChrome(){
    const tb = $('#theme-btn'), pop = $('#theme-popover');
    if(tb && pop){
      const setOpen = open => {
        pop.hidden = !open;
        tb.setAttribute('aria-expanded', String(open));
      };
      tb.addEventListener('click', e => {
        e.stopPropagation();
        setOpen(pop.hidden);
      });
      $$('#theme-list .theme-opt').forEach(b => b.addEventListener('click', () => {
        Store.set('theme', b.dataset.themeId);
        applyTheme(b.dataset.themeId);
        setOpen(false);
      }));
      document.addEventListener('click', e => {
        if(!pop.hidden && !e.target.closest('.theme-picker')) setOpen(false);
      });
    }

    const pb = $('#profile-btn'), pm = $('#profile-menu'), pwrap = $('#profile-menu-wrap');
    if(pb && pm && pwrap){
      const items = () => $$('.profile-menu-item', pm);
      function updateMenuMeta(){
        const u = State.user || { name: 'Scholar', hue: '#F6B93B' };
        const mav = $('#profile-menu-avatar');
        if(mav){
          mav.textContent = String(u.name || 'S').charAt(0).toUpperCase();
          mav.style.background = safeColor(u.hue, '#F6B93B');
        }
        const lvl = $('#profile-level');
        if(lvl && window.Tracker){
          const st = Store.get('stats', { xp: 0, badges: [] });
          lvl.textContent = 'Level ' + Tracker.levelInfo(st.xp).level;
        }
      }
      function setOpen(open){
        pm.hidden = !open;
        pb.setAttribute('aria-expanded', String(open));
        if(open) updateMenuMeta();
      }
      const close = () => setOpen(false);
      pb.addEventListener('click', () => setOpen(pm.hidden));
      pm.addEventListener('click', e => {
        const item = e.target.closest('[data-profile-action]');
        if(!item) return;
        close();
        if(item.dataset.profileAction === 'profile'){
          if(window.Profile) Profile.show();
        }else if(item.dataset.profileAction === 'logout'){
          Store.del('user');
          toast('Logged out \u2014 your data stays on this device', 'warn');
          setTimeout(() => location.reload(), 700);
        }
      });
      document.addEventListener('click', e => {
        if(!pm.hidden && !pwrap.contains(e.target)) close();
      });
      document.addEventListener('keydown', e => {
        if(e.key === 'Escape' && !pm.hidden){ close(); pb.focus(); }
      });
      pwrap.addEventListener('keydown', e => {
        if(e.key === 'Tab' && !pm.hidden){ close(); return; }
        if(e.key !== 'ArrowDown' && e.key !== 'ArrowUp') return;
        if(pm.hidden){
          if(e.target !== pb) return;
          e.preventDefault();
          setOpen(true);
          const list = items();
          if(!list.length) return;
          (e.key === 'ArrowDown' ? list[0] : list[list.length - 1]).focus();
          return;
        }
        const list = items();
        if(!list.length) return;
        e.preventDefault();
        if(e.target === pb){
          (e.key === 'ArrowDown' ? list[0] : list[list.length - 1]).focus();
          return;
        }
        const i = list.indexOf(document.activeElement);
        const next = e.key === 'ArrowDown' ? (i + 1) % list.length : (i - 1 + list.length) % list.length;
        list[next].focus();
      });
    }

    window.addEventListener('scroll', () => {
      $('#chrome').classList.toggle('compact', window.scrollY > 24);
    }, { passive: true });

    if(window.ResizeObserver){
      const ro = new ResizeObserver(() => { positionInd(); positionDock(); });
      const nav = $('#nav-island'), dock = $('#bottom-nav');
      if(nav) ro.observe(nav);
      if(dock) ro.observe(dock);
    }
    window.addEventListener('resize', () => { positionInd(); positionDock(); });

    /* keep indicators glued while labels animate */
    const navIsland = $('#nav-island'), navInd = $('#nav-ind');
    if(navInd) navInd.addEventListener('transitionend', e => { if(e.target === navInd) positionInd(); });
    const dockInd = $('#dock-ind');
    if(dockInd) dockInd.addEventListener('transitionend', e => { if(e.target === dockInd) positionDock(); });

    let indRAF = 0;
    const trackInd = () => { positionInd(); positionDock(); indRAF = requestAnimationFrame(trackInd); };
    const startTrack = () => { if(!indRAF) indRAF = requestAnimationFrame(trackInd); };
    const stopTrack = () => {
      if(indRAF){ cancelAnimationFrame(indRAF); indRAF = 0; }
      positionInd(); positionDock();
    };
    if(navIsland){
      navIsland.addEventListener('pointerenter', startTrack);
      navIsland.addEventListener('pointerleave', stopTrack);
      navIsland.addEventListener('focusin', startTrack);
      navIsland.addEventListener('focusout', stopTrack);
    }

    document.addEventListener('click', e => {
      const n = e.target.closest('[data-route]');
      if(!n) return;
      e.preventDefault();
      location.hash = '#/' + n.dataset.route;
    });

    /* Space — start / pause / resume */
    document.addEventListener('keydown', e => {
      if(e.code !== 'Space') return;
      const t = e.target;
      if(t && t.matches && (t.matches('input,select,textarea') || t.closest('button'))) return;
      const modal = $('#join-modal');
      if(modal && modal.style.display !== 'none') return;
      if($('#summary-modal') && !$('#summary-modal').hidden) return;
      if($('#finish-modal') && !$('#finish-modal').hidden) return;
      if($('#online-consent-modal') && $('#online-consent-modal').style.display !== 'none') return;
      if(!window.Tracker) return;
      if(Tracker.isActive()){
        e.preventDefault();
        Tracker.togglePause();
      }else if(State.view === 'focus'){
        e.preventDefault();
        Tracker.start();
      }
    });

    /* 1-6 switch views */
    document.addEventListener('keydown', e => {
      if(e.ctrlKey || e.metaKey || e.altKey) return;
      if(!/^[1-6]$/.test(e.key)) return;
      const t2 = e.target;
      if(t2 && t2.matches && (t2.matches('input,select,textarea') || t2.isContentEditable)) return;
      const view = ROUTES[parseInt(e.key, 10) - 1];
      if(!view) return;
      e.preventDefault();
      location.hash = '#/' + view;
    });

    /* Esc closes any modal */
    document.addEventListener('keydown', e => {
      if(e.key !== 'Escape') return;
      $$('.modal-overlay').forEach(m => {
        if(m.id === 'summary-modal' || m.id === 'finish-modal') m.hidden = true;
        else m.style.display = 'none';
      });
      const themePop = $('#theme-popover');
      if(themePop) themePop.hidden = true;
      if(tb) tb.setAttribute('aria-expanded', 'false');
    });

    window.addEventListener('beforeunload', e => {
      if(window.Tracker && Tracker.isActive()){ e.preventDefault(); e.returnValue = ''; }
    });

    window.addEventListener('hashchange', route);
  }

  /* ---------- boot ---------- */

  function boot(){
    applyTheme(Store.get('theme', 'dark'));
    bindLogin(); bindChrome();
    Sound.bindUI();
    if(window.Music) Music.init();
    Tracker.bindFocus();
    Tasks.bind();
    Rooms.bind();
    if(window.Profile) Profile.init();
    Dashboard.bind();
    bindPractice();

    const user = Store.get('user', null);
    if(user && user.name){
      enter(user.name, user.hue || '#F6B93B', false);
    }else{
      showLogin();
    }
  }

  document.addEventListener('DOMContentLoaded', boot);

  return { boot };
})();
window.App = App;