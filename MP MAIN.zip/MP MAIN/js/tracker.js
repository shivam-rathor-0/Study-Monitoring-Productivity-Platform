/* tracker.js — session engine (stopwatch / pomodoro / focus guard), XP, badges, focus UI. */
'use strict';

const Tracker = (function(){

  const RING_C = 2 * Math.PI * 118;
  const MAX_CUSTOM_SUBJECTS = 12;
  const DEFAULT_DISTRACT_CATS = ['Phone', 'Noise', 'Daydreaming', 'Social media'];

  const T = {
    active: false, paused: false, mode: 'stopwatch', subject: 'Mathematics', goal: '',
    guard: false, guardFailed: false,
    startedAt: 0, sessionId: '', studiedSec: 0, breakSec: 0, pomodoros: 0,
    focusSec: 0, distractSec: 0, distractionCount: 0, attention: 'off', guardArmed: false,
    samples: [], sampleAcc: 0, cycleCount: 0,
    phase: 'work', phaseLeft: 0, phaseLen: 0,
    interval: null, lastTick: 0, lastRenderKey: '', lastSampleCount: -1,
    zen: false, slept: false, lastDash: 0
  };

  let selSubject = 'Mathematics', selMode = 'stopwatch', selGuard = false, selAmbience = '';
  let lastPhoneLogAt = 0;
  let wakeLock = null;
  let lastSummary = null;
  let selDistractCat = null;

  /* ---------- settings ---------- */
  function clampInt(v, min, max, fallback){
    const n = parseInt(v, 10);
    return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
  }
  function cfg(){
    const s = Store.get('settings', {});
    return {
      pomoWork: clampInt(s.pomoWork, 5, 120, 25),
      pomoBreak: clampInt(s.pomoBreak, 1, 45, 5),
      pomoLong: clampInt(s.pomoLong, 5, 60, 15),
      longBreak: s.longBreak !== false,
      guardSens: ['relaxed','balanced','strict'].includes(s.guardSens) ? s.guardSens : 'balanced',
      guardPhone: s.guardPhone !== false,
      guardPreview: s.guardPreview !== false,
      focusZen: s.focusZen !== false,
      focusChime: s.focusChime !== false,
      focusWake: s.focusWake !== false,
      autoNext: s.autoNext !== false,
      startSound: typeof s.startSound === 'string' ? s.startSound : '',
      lastSubject: typeof s.lastSubject === 'string' ? s.lastSubject : '',
      lastMode: s.lastMode === 'pomodoro' ? 'pomodoro' : 'stopwatch'
    };
  }
  function saveCfg(patch){
    Store.set('settings', Object.assign(cfg(), patch));
  }
  function modeLabel(mode){
    mode = mode || T.mode;
    if(mode === 'pomodoro'){
      const c = cfg();
      return 'Pomodoro ' + c.pomoWork + '/' + c.pomoBreak;
    }
    return 'Stopwatch';
  }
  function startAmbience(id){
    if(!id || !window.Sound) return;
    if(typeof Sound.isActive === 'function' && Sound.isActive(id)) return;
    try{ Sound.toggle(id); }catch(e){}
  }

  /* ---------- wake lock ---------- */
  async function requestWakeLock(){
    if(cfg().focusWake === false || !('wakeLock' in navigator) || !T.active || T.paused) return;
    if(wakeLock) return;
    try{ wakeLock = await navigator.wakeLock.request('screen'); }catch(e){ wakeLock = null; }
  }
  function releaseWakeLock(){
    if(!wakeLock) return;
    try{ wakeLock.release(); }catch(e){}
    wakeLock = null;
  }

  /* ================= session engine ================= */

  function start(opts = {}){
    if(T.active){ toast('A session is already running', 'warn'); return; }
    closeSummary(); closeFinishModal();
    const c = cfg();
    const goalEl = $('#session-goal');
    T.mode = opts.mode || selMode;
    T.subject = opts.subject || selSubject;
    T.goal = String(opts.goal != null ? opts.goal : (goalEl ? goalEl.value : '')).trim().slice(0, 90);
    T.guard = opts.guard != null ? !!opts.guard : selGuard;
    T.guardFailed = false;
    T.active = true; T.paused = false; T.zen = opts.zen != null ? !!opts.zen : (c.focusZen !== false);
    T.startedAt = Date.now(); T.sessionId = 's' + T.startedAt;
    T.studiedSec = 0; T.breakSec = 0; T.pomodoros = 0;
    T.focusSec = 0; T.distractSec = 0; T.distractionCount = 0;
    T.attention = T.guard ? 'init' : 'off'; T.guardArmed = false;
    T.samples = []; T.sampleAcc = 0; T.cycleCount = 0;
    T.phase = 'work'; T.phaseLen = T.mode === 'pomodoro' ? c.pomoWork * 60 : 0; T.phaseLeft = T.phaseLen;
    T.lastTick = Date.now(); T.lastRenderKey = ''; T.lastSampleCount = -1;
    T.slept = false; T.lastDash = 0;
    lastPhoneLogAt = 0;

    saveCfg({ lastSubject: T.subject, lastMode: T.mode });
    selSubject = T.subject; selMode = T.mode;

    enterLive();
    setZen(T.zen);
    T.interval = setInterval(tick, 250);
    requestWakeLock();
    startAmbience(c.startSound);
    Sound.sfx('start');
    if(window.Rooms) Rooms.onMySessionStarted(T.subject, T.mode);
    if(T.guard){
      if(window.Guard) Guard.start(onAttention, onGuardFail);
      else onGuardFail('AI Guard is unavailable. Continuing without it.');
    }
    renderLive(true); renderStrip(); renderToday();
  }

  function tick(){
    if(!T.active || T.paused) return;
    const now = Date.now();
    let dt = (now - T.lastTick) / 1000;
    T.lastTick = now;
    if(dt <= 0) return;
    if(dt > 90){
      /* the device slept: do not credit hours that never happened */
      if(!T.slept){ T.slept = true; toast('Timer paused while your device slept', 'warn'); }
      dt = 0;
    }
    if(dt > 0){
      if(T.mode === 'stopwatch'){
        T.studiedSec += dt;
      }else{
        if(T.phase === 'work') T.studiedSec += dt; else T.breakSec += dt;
        T.phaseLeft -= dt;
        while(T.phaseLeft <= 0 && T.active && !T.paused) phaseFlip();
      }
      const inWork = T.mode !== 'pomodoro' || T.phase === 'work';
      if(T.guard && inWork){
        if(T.attention === 'focused' || T.attention === 'init') T.focusSec += dt;
        else T.distractSec += dt;
        T.sampleAcc += dt;
        while(T.sampleAcc >= 2){
          T.sampleAcc -= 2;
          T.samples.push(T.attention === 'focused' || T.attention === 'init' ? 'f' : T.attention === 'away' ? 'a' : 'd');
        }
      }
    }
    renderLive();
  }

  function phaseFlip(){
    const c = cfg();
    if(T.phase === 'work'){
      T.pomodoros++;
      T.cycleCount++;
      const long = c.longBreak && T.cycleCount >= 4;
      T.phase = 'break';
      T.phaseLen = (long ? c.pomoLong : c.pomoBreak) * 60;
      T.phaseLeft = T.phaseLen;
      if(c.focusChime) Sound.sfx(long ? 'chime2' : 'chime');
      toast(long ? 'Four blocks complete — take a long break' : 'Pomodoro complete — take a break', 'success');
    }else{
      if(T.cycleCount >= 4) T.cycleCount = 0;
      T.phase = 'work';
      T.phaseLen = c.pomoWork * 60;
      T.phaseLeft = T.phaseLen;
      if(c.focusChime) Sound.sfx('chime2');
      toast('Break over — back to focus', 'info');
    }
    if(!c.autoNext) pauseAtBoundary();
    renderLive(true);
  }

  function pauseAtBoundary(){
    if(!T.active || T.paused) return;
    T.paused = true;
    if(T.interval){ clearInterval(T.interval); T.interval = null; }
    if(T.guard && window.Guard) Guard.setPaused(true);
    releaseWakeLock();
    toast('Phase ended — resume when you are ready', 'info');
    renderLive(true); renderStrip();
  }

  function pause(withSound = true){
    if(!T.active || T.paused) return;
    T.paused = true;
    if(T.interval){ clearInterval(T.interval); T.interval = null; }
    if(withSound) Sound.sfx('pause');
    if(T.guard && window.Guard) Guard.setPaused(true);
    releaseWakeLock();
    renderLive(true); renderStrip();
  }
  function resume(){
    if(!T.active || !T.paused) return;
    T.paused = false;
    T.lastTick = Date.now();
    T.interval = setInterval(tick, 250);
    if(T.guard && window.Guard) Guard.setPaused(false);
    requestWakeLock();
    Sound.sfx('start');
    renderLive(true); renderStrip();
  }
  function togglePause(){ T.paused ? resume() : pause(); }

  function addFive(){
    if(!T.active || T.mode !== 'pomodoro') return;
    T.phaseLeft += 300;
    T.phaseLen += 300;
    Sound.sfx('pop');
    toast('Added 5 minutes', 'info');
    renderLive(true);
  }

  function skipBreak(){
    if(!T.active || T.mode !== 'pomodoro' || T.phase !== 'break') return;
    const c = cfg();
    if(T.cycleCount >= 4) T.cycleCount = 0;
    T.phase = 'work'; T.phaseLen = c.pomoWork * 60; T.phaseLeft = T.phaseLen;
    if(c.focusChime) Sound.sfx('chime2');
    toast('Break skipped — back to focus', 'info');
    renderLive(true);
  }

  function onAttention(state, why){
    if(!T.guard) return;
    const prev = T.attention;
    T.attention = state;
    if(state === 'focused') T.guardArmed = true;
    if(T.guardArmed && (state === 'distracted' || state === 'away') && (prev === 'focused' || prev === 'init')){
      T.distractionCount++;
      Sound.sfx('alert');
    }
    if(T.guardArmed && state === 'distracted' && why === 'phone' && Date.now() - lastPhoneLogAt >= 60000){
      lastPhoneLogAt = Date.now();
      const all = Store.get('distractions', []);
      all.push({ cat: 'Phone', at: Date.now(), sessionId: T.sessionId, auto: true });
      Store.set('distractions', all);
      updateDistractCount();
    }
    renderGuardStats();
  }

  function onGuardFail(msg){
    T.guardFailed = true;
    T.guard = false;
    T.attention = 'focused';
    selGuard = false;
    syncZenGuard();
    paintToggle('#guard-toggle', false);
    $('#guard-sens').hidden = true;
    $('#guard-extra').hidden = true;
    updateStartSummary();
    toast(msg, 'error');
  }

  /* ================= finish & summary ================= */

  function finish(force){
    if(!T.active) return;
    const seconds = Math.floor(T.studiedSec + T.breakSec);
    if(!force && seconds < 60){ showFinishModal(seconds); return; }
    doFinish();
  }

  function doFinish(){
    if(!T.active) return;
    closeFinishModal();
    if(T.interval){ clearInterval(T.interval); T.interval = null; }
    if(window.Guard) Guard.stop();
    releaseWakeLock();
    setZen(false);

    const wasGuard = T.guard && !T.guardFailed;
    const sec = Math.floor(T.studiedSec);
    const breakSec = Math.floor(T.breakSec);
    const xpSec = wasGuard ? Math.floor(T.focusSec) : sec;
    const xp = sec >= 60 ? Math.floor(xpSec / 60) : 0;
    const ended = Date.now();
    const total = T.focusSec + T.distractSec;
    const guardReasons = wasGuard && window.Guard ? Guard.reasons() : {};

    const session = {
      id: T.sessionId, subject: T.subject, goal: T.goal, mode: T.mode,
      seconds: sec, breakSec: breakSec, totalSec: sec + breakSec,
      pomodoros: T.pomodoros, date: dateKey(), startedAt: T.startedAt, endedAt: ended,
      guard: wasGuard, reasons: guardReasons,
      focusSec: Math.floor(T.focusSec), distractSec: Math.floor(T.distractSec),
      focusPct: wasGuard && total > 3 ? Math.round(T.focusSec / total * 100) : null,
      distractionCount: T.distractionCount,
      xp: xp
    };
    const inMemory = Object.assign({ samples: T.samples.slice(-140) }, session);

    T.active = false; T.paused = false;
    Sound.sfx('stop');
    exitLive(); renderStrip(); resetTitle();

    if(sec >= 10){
      const all = Store.get('sessions', []);
      all.push(session);
      Store.set('sessions', all);
      if(xp > 0) awardXP(xp);
      checkBadges({ endedHour: new Date(ended).getHours(), startedHour: new Date(T.startedAt).getHours(), guardPct: session.focusPct });
      if(window.Rooms && sec >= 60) Rooms.onMySessionSaved(sec, T.subject);
      lastSummary = inMemory;
      showSummary(inMemory);
    }else{
      toast('Under 10 seconds — session was not recorded', 'warn');
    }

    selSubject = T.subject; selMode = T.mode; selGuard = false;
    syncSetup();
    renderLog(); renderToday();
    if(window.Dashboard) Dashboard.refresh();
  }

  function showFinishModal(seconds){
    const modal = $('#finish-modal');
    if(!modal) return;
    const short = seconds < 10;
    const title = $('#finish-title'), copy = $('#finish-copy'), confirm = $('#finish-confirm');
    if(title) title.textContent = short ? 'End without saving?' : 'This session is under a minute';
    if(copy) copy.textContent = short
      ? 'Sessions under 10 seconds are not recorded. Keep going if you can.'
      : 'It will be saved without XP. Staying a little longer is usually worth it.';
    if(confirm) confirm.textContent = short ? 'Discard session' : 'Finish anyway';
    modal.hidden = false;
  }
  function closeFinishModal(){
    const modal = $('#finish-modal');
    if(modal) modal.hidden = true;
  }
  function closeSummary(){
    const modal = $('#summary-modal');
    if(modal) modal.hidden = true;
  }

  function showSummary(s){
    const pct = s.focusPct;
    const dur = fmtClock(s.seconds);
    const title = $('#sum-title');
    if(title){
      title.textContent = pct != null
        ? (pct >= 90 ? 'Deep work logged' : pct >= 75 ? 'Solid session' : 'Session logged')
        : (s.seconds >= 1800 ? 'Deep work logged' : 'Session logged');
    }
    const goal = $('#sum-goal');
    if(goal) goal.textContent = s.goal ? '\u201c' + s.goal + '\u201d' : s.subject + ' \u00b7 ' + modeLabel(s.mode);
    const d = $('#sum-duration'); if(d) d.textContent = dur;
    const xp = $('#sum-xp');
    if(xp){
      xp.textContent = '+' + (s.xp || 0) + ' XP';
      xp.hidden = !s.xp;
    }

    const stats = [
      ['Focused', fmtClock(s.seconds)],
      ['Break', fmtClock(s.breakSec || 0)],
      ['Pomodoros', String(s.pomodoros || 0)],
      ['Distractions', String(s.distractionCount || 0)]
    ];
    if(pct != null) stats.push(['Focus score', pct + '%']);
    const st = $('#sum-stats');
    if(st) st.innerHTML = stats.map(([k, v]) =>
      '<div><span>' + k + '</span><b class="mono">' + v + '</b></div>').join('');

    const wrap = $('#sum-timeline-wrap'), tl = $('#sum-timeline');
    const segs = (s.samples || []).slice(-140);
    if(wrap) wrap.hidden = !(s.guard && segs.length);
    if(tl) tl.innerHTML = segs.length
      ? segs.map(x => '<span class="seg ' + x + '"></span>').join('')
      : '<span class="seg i"></span>';

    const tip = $('#sum-tip');
    if(tip) tip.textContent = tipFor(s);

    const badge = $('#sum-badge');
    if(badge) badge.className = 'sum-badge' + (pct != null && pct < 75 ? ' low' : '');

    const modal = $('#summary-modal');
    if(modal) modal.hidden = false;
  }

  function tipFor(s){
    const r = s.reasons || {};
    const top = Object.entries(r).sort((a, b) => b[1] - a[1])[0];
    const pct = s.focusPct;
    if(pct != null){
      if(pct >= 92) return 'Outstanding attention discipline. Your signal stayed green almost the whole session — try a longer block next time.';
      if(top){
        if(top[0] === 'phone') return 'The phone came into view ' + top[1] + ' times. Put it in another room before the next block.';
        if(top[0] === 'looking') return 'You looked away often. Facing a plain wall and closing extra tabs usually fixes this quickly.';
        if(top[0] === 'drowsy') return 'Drowsiness showed up. A short walk and water will do more than pushing through.';
        if(top[0] === 'away') return 'You left the desk ' + top[1] + ' times. Set everything you need within reach first.';
      }
      return pct >= 80
        ? 'Strong session. A short walk between blocks will keep the quality high.'
        : 'Set one clear micro-goal before the next session — attention follows intent.';
    }
    if(s.seconds >= 3600) return 'A full hour of focused work. Protect the recovery time that makes this repeatable.';
    if(s.mode === 'pomodoro' && (s.pomodoros || 0) >= 4) return 'A complete pomodoro cycle. Consistency like this is what compounds.';
    if(s.seconds < 300) return 'Short sessions are fine for starting. Try a 25-minute block when you have a clear target.';
    return 'Consistency beats intensity. Protect the same time tomorrow.';
  }

  /* ================= XP / level ================= */

  function levelInfo(xp){
    let level = 1, need = 100, acc = 0;
    while(xp >= acc + need){ acc += need; level++; need = 100 + (level - 1) * 40; }
    return { level, into: Math.floor(xp - acc), need, pct: Math.min(100, Math.floor((xp - acc) / need * 100)) };
  }
  function awardXP(min){
    if(min <= 0) return;
    const st = Store.get('stats', { xp: 0, badges: [] });
    const before = levelInfo(st.xp).level;
    st.xp += min;
    Store.set('stats', st);
    if(levelInfo(st.xp).level > before){
      Sound.sfx('level');
      toast('Level up! You reached level ' + levelInfo(st.xp).level, 'success');
    }
    renderXPPill();
  }
  function renderXPPill(){
    const st = Store.get('stats', { xp: 0, badges: [] });
    const li = levelInfo(st.xp);
    const lv = $('#xp-level'), fill = $('#xp-fill'), pill = $('#xp-pill');
    if(lv) lv.textContent = 'Lv ' + li.level;
    if(fill) fill.style.width = li.pct + '%';
    if(pill) pill.title = li.into + ' / ' + li.need + ' XP — 1 XP per focused minute';
  }

  /* ================= badges ================= */

  const BADGES = [
    { id:'first',   name:'First Steps',   icon:'fa-shoe-prints',       desc:'Complete your first session',               test:s => s.count >= 1 },
    { id:'hour1',   name:'One Hour Club', icon:'fa-clock',             desc:'Study 1 hour in total',                     test:s => s.totalMin >= 60 },
    { id:'hour10',  name:'Ten Hour Club', icon:'fa-medal',             desc:'Study 10 hours in total',                   test:s => s.totalMin >= 600 },
    { id:'streak3', name:'Warming Up',    icon:'fa-fire',              desc:'Keep a 3-day streak',                       test:s => s.streak >= 3 },
    { id:'streak7', name:'Unstoppable',   icon:'fa-fire-flame-curved', desc:'Keep a 7-day streak',                       test:s => s.streak >= 7 },
    { id:'pomo10',  name:'Tomato Farmer', icon:'fa-stopwatch',         desc:'Complete 10 pomodoros',                     test:s => s.pomos >= 10 },
    { id:'night',   name:'Night Owl',     icon:'fa-moon',              desc:'Finish a session between midnight and 5am', test:(s,c) => !!(c && c.endedHour != null && c.endedHour < 5) },
    { id:'early',   name:'Early Bird',    icon:'fa-sun',               desc:'Start a session before 7am',                test:(s,c) => !!(c && c.startedHour != null && c.startedHour < 7) },
    { id:'task25',  name:'Taskmaster',    icon:'fa-list-check',        desc:'Complete 25 tasks',                         test:s => s.tasksDone >= 25 },
    { id:'social',  name:'Team Player',   icon:'fa-users',             desc:'Join a study room',                         test:s => s.rooms >= 1 },
    { id:'laser',   name:'Laser Focus',   icon:'fa-crosshairs',        desc:'90%+ focus in an AI Guard session',         test:(s,c) => !!(c && c.guardPct != null && c.guardPct >= 90) },
  ];

  function stats(){
    const sessions = Store.get('sessions', []);
    return {
      sessions, count: sessions.length,
      totalMin: sessions.reduce((a, x) => a + x.seconds, 0) / 60,
      pomos: sessions.reduce((a, x) => a + (x.pomodoros || 0), 0),
      streak: calcStreak(sessions),
      tasksDone: Store.get('tasks', []).filter(t => t.done).length,
      rooms: Object.keys(Store.get('rooms', {})).length
    };
  }
  function checkBadges(ctx){
    const st = Store.get('stats', { xp: 0, badges: [] });
    const s = stats();
    let gained = false;
    BADGES.forEach(b => {
      if(st.badges.some(x => x.id === b.id)) return;
      let pass = false;
      try{ pass = !!b.test(s, ctx); }catch(e){}
      if(pass){
        st.badges.push({ id: b.id, at: Date.now() });
        gained = true;
        toast('Badge unlocked — ' + b.name, 'success');
        Sound.sfx('done');
      }
    });
    if(gained) Store.set('stats', st);
  }
  function todaySeconds(){
    const key = dateKey();
    return Store.get('sessions', [])
      .filter(s => s.date === key)
      .reduce((a, s) => a + (Number(s.seconds) || 0), 0);
  }
  function calcStreak(sessions){
    const days = new Set(sessions.map(s => s.date));
    const d = new Date();
    if(!days.has(dateKey(d))) d.setDate(d.getDate() - 1);
    let streak = 0;
    while(days.has(dateKey(d))){ streak++; d.setDate(d.getDate() - 1); }
    return streak;
  }

  /* ================= subjects ================= */

  function customSubjectList(){
    const raw = Store.get('customSubjects', []);
    const out = [];
    raw.forEach(v => {
      if(typeof v !== 'string') return;
      const name = v.trim().slice(0, 24);
      if(!name) return;
      if(out.some(x => x.toLowerCase() === name.toLowerCase())) return;
      out.push(name);
    });
    return out.slice(0, MAX_CUSTOM_SUBJECTS);
  }
  function addCustomSubject(name){
    name = String(name == null ? '' : name).trim().slice(0, 24);
    if(!name) return '';
    const builtin = SUBJECTS.find(s => s.toLowerCase() === name.toLowerCase());
    if(builtin) return builtin;
    const list = customSubjectList();
    const existing = list.find(s => s.toLowerCase() === name.toLowerCase());
    if(existing) return existing;
    if(list.length >= MAX_CUSTOM_SUBJECTS) return '';
    list.push(name);
    Store.set('customSubjects', list);
    renderSubjects();
    return name;
  }
  function removeCustomSubject(name){
    const target = String(name == null ? '' : name).toLowerCase();
    Store.set('customSubjects', customSubjectList().filter(s => s.toLowerCase() !== target));
  }
  function renderSubjects(){
    const box = $('#subject-chips'); if(!box) return;
    box.innerHTML = '';
    SUBJECTS.forEach(s => {
      box.append(el('button', {
        type: 'button',
        class: 'chip' + (s === selSubject ? ' active' : ''),
        onclick(){ selSubject = s; renderSubjects(); updateStartSummary(); }
      }, s));
    });
    customSubjectList().forEach(s => {
      const chip = el('button', {
        type: 'button',
        class: 'chip' + (s === selSubject ? ' active' : ''),
        onclick(){ selSubject = s; renderSubjects(); updateStartSummary(); }
      }, s);
      const del = el('i', { class: 'fa-solid fa-xmark', title: 'Delete subject' });
      del.addEventListener('click', e => {
        e.stopPropagation();
        removeCustomSubject(s);
        if(selSubject === s) selSubject = SUBJECTS[0];
        renderSubjects(); updateStartSummary();
      });
      chip.append(del);
      box.append(chip);
    });
  }

  /* ---------- distractions ---------- */
  const distractCats = () => Store.get('distractCats', DEFAULT_DISTRACT_CATS.slice());
  const saveDistractCats = cats => Store.set('distractCats', cats);

  function renderDistractCats(){
    const box = $('#distract-cats'); if(!box) return;
    const cats = distractCats();
    if(!cats.includes(selDistractCat)) selDistractCat = cats[0] || null;
    box.innerHTML = '';
    cats.forEach(c => {
      const chip = el('button', {
        type: 'button',
        class: 'chip' + (c === selDistractCat ? ' active' : ''),
        'data-distract-cat': c
      }, c);
      chip.append(
        el('i', { class: 'fa-solid fa-pen', 'data-distract-rename': c, title: 'Rename' }),
        el('i', { class: 'fa-solid fa-xmark', 'data-distract-del': c, title: 'Delete' })
      );
      box.append(chip);
    });
    if(!cats.length) box.append(el('span', { class: 'sub' }, 'No categories — add one'));
    updateDistractCount();
  }
  function updateDistractCount(){
    const badge = $('#distract-session-count'); if(!badge) return;
    const n = T.active ? Store.get('distractions', []).filter(d => d.sessionId === T.sessionId).length : 0;
    badge.textContent = n + ' logged';
  }
  function addDistractCat(name){
    name = String(name || '').trim().slice(0, 24);
    if(!name) return;
    const cats = distractCats();
    if(cats.some(c => c.toLowerCase() === name.toLowerCase())){ toast('Category already exists', 'warn'); return; }
    cats.push(name);
    saveDistractCats(cats);
    selDistractCat = name;
    renderDistractCats();
    toast('Category added — ' + name, 'info');
  }
  function renameDistractCat(oldName){
    const next = prompt('Rename category', oldName);
    if(next == null) return;
    const name = next.trim().slice(0, 24);
    if(!name || name === oldName) return;
    const cats = distractCats();
    if(cats.some(c => c !== oldName && c.toLowerCase() === name.toLowerCase())){ toast('Category already exists', 'warn'); return; }
    const i = cats.indexOf(oldName);
    if(i < 0) return;
    cats[i] = name;
    saveDistractCats(cats);
    const entries = Store.get('distractions', []);
    entries.forEach(d => { if(d.cat === oldName) d.cat = name; });
    Store.set('distractions', entries);
    if(selDistractCat === oldName) selDistractCat = name;
    renderDistractCats();
    toast('Category renamed — ' + name, 'info');
  }
  function deleteDistractCat(name){
    const cats = distractCats().filter(c => c !== name);
    saveDistractCats(cats);
    if(selDistractCat === name) selDistractCat = cats[0] || null;
    renderDistractCats();
    toast('Category deleted', 'warn');
  }
  function logDistraction(){
    if(!T.active){ toast('Start a session first', 'warn'); return; }
    if(!selDistractCat){ toast('Add a distraction category first', 'warn'); return; }
    const all = Store.get('distractions', []);
    all.push({ cat: selDistractCat, at: Date.now(), sessionId: T.sessionId });
    Store.set('distractions', all);
    updateDistractCount();
    Sound.sfx('pop');
    toast('Logged — ' + selDistractCat, 'info');
  }

  /* ================= focus view UI ================= */

  function paintToggle(sel, on){
    const b = $(sel); if(!b) return;
    b.classList.toggle('on', !!on);
    b.setAttribute('aria-pressed', String(!!on));
  }
  function paintMode(){
    $$('#mode-seg .mode-card').forEach(b => b.classList.toggle('active', b.dataset.mode === selMode));
    const pc = $('#pomo-config');
    if(pc) pc.hidden = selMode !== 'pomodoro';
  }
  function paintPomo(){
    const c = cfg();
    const w = $('#pomo-work'), b = $('#pomo-break'), l = $('#pomo-long');
    if(w) w.value = c.pomoWork;
    if(b) b.value = c.pomoBreak;
    if(l) l.value = c.pomoLong;
    $$('#pomo-presets .chip').forEach(x => {
      const [pw, pb] = String(x.dataset.pomo || '').split('-').map(Number);
      x.classList.toggle('active', pw === c.pomoWork && pb === c.pomoBreak);
    });
    paintToggle('#longbreak-toggle', c.longBreak);
  }
  function paintGuard(){
    paintToggle('#guard-toggle', selGuard);
    const sens = $('#guard-sens'), extra = $('#guard-extra');
    if(sens) sens.hidden = !selGuard;
    if(extra) extra.hidden = !selGuard;
  }
  function paintSettings(){
    const c = cfg();
    paintToggle('#guard-phone-toggle', c.guardPhone);
    paintToggle('#guard-preview-toggle', c.guardPreview);
    paintToggle('#zen-toggle', c.focusZen);
    paintToggle('#chime-toggle', c.focusChime);
    paintToggle('#wake-toggle', c.focusWake);
    paintToggle('#auto-next-toggle', c.autoNext);
    $$('#guard-sens-chips .chip').forEach(x => x.classList.toggle('active', x.dataset.sens === c.guardSens));
    $$('#start-sound .chip').forEach(x => x.classList.toggle('active', x.dataset.startSound === c.startSound));
    selAmbience = c.startSound;
  }
  function updateStartSummary(){
    const c = cfg();
    const text = $('#start-summary-text'), sub = $('#start-summary-sub');
    const btn = $('#start-btn span'), hint = $('#mode-hint');
    if(text) text.textContent = (selMode === 'pomodoro' ? 'Pomodoro ' + c.pomoWork + '/' + c.pomoBreak : 'Stopwatch') + ' \u00b7 ' + selSubject;
    if(sub){
      const goal = $('#session-goal');
      const hasGoal = goal && goal.value.trim();
      sub.textContent = (selMode === 'pomodoro' ? c.pomoWork + ' min focus \u00b7 ' + c.pomoBreak + ' min break' : 'No time limit')
        + (selGuard ? ' \u00b7 Guard on' : ' \u00b7 Guard off')
        + (hasGoal ? ' \u00b7 goal set' : '');
    }
    if(btn) btn.textContent = selMode === 'pomodoro' ? 'Start ' + c.pomoWork + ' min focus' : 'Start session';
    if(hint) hint.textContent = selMode === 'pomodoro' ? 'Focused blocks' : 'Open-ended';
    const count = $('#custom-subject-count');
    if(count) count.textContent = customSubjectList().length + '/' + MAX_CUSTOM_SUBJECTS;
  }
  function syncSetup(){
    const c = cfg();
    selMode = c.lastMode;
    selSubject = c.lastSubject || SUBJECTS[0];
    if(!SUBJECTS.includes(selSubject) && !customSubjectList().includes(selSubject)) selSubject = SUBJECTS[0];
    selGuard = false;
    paintMode(); paintPomo(); paintGuard(); paintSettings();
    renderSubjects(); updateStartSummary();
  }

  function renderToday(){
    const all = Store.get('sessions', []);
    const key = dateKey();
    const today = all.filter(s => s.date === key);
    const total = todaySeconds();
    const t = $('#focus-today-time');
    if(t) t.textContent = total > 0 ? fmtDur(total) : '0m';
    const c = $('#focus-today-count');
    if(c) c.textContent = today.length + (today.length === 1 ? ' session' : ' sessions');
    const s = $('#focus-today-streak');
    if(s) s.textContent = calcStreak(all) + '-day streak';
  }

  function renderLog(){
    const box = $('#session-log'); if(!box) return;
    const key = dateKey();
    const all = Store.get('sessions', []).filter(s => s.date === key);
    const total = all.reduce((a, s) => a + s.seconds, 0);
    const tot = $('#log-total');
    if(tot) tot.textContent = (total > 0 ? fmtDur(total) : '0m') + ' total';
    const list = all.slice(-12).reverse();
    if(!list.length){
      box.innerHTML = '<div class="empty"><i class="fa-solid fa-mug-hot"></i><p>No sessions yet today — start one above</p></div>';
      return;
    }
    box.innerHTML = list.map(s =>
      '<div class="log-row">' +
        '<span class="subj-chip" style="background:' + hueFor(s.subject) + '1E;color:color-mix(in srgb,' + hueFor(s.subject) + ' 55%,var(--text))">' + escapeHTML(s.subject) + '</span>' +
        (s.guard
          ? '<span class="mode"><i class="fa-solid fa-camera"></i>' + (s.focusPct != null ? s.focusPct + '% focus' : 'AI guard') + '</span>'
          : '<span class="mode">' + (s.mode === 'pomodoro' ? 'pomodoro \u00d7 ' + (s.pomodoros || 0) : 'stopwatch') + '</span>') +
        '<span class="dur mono">' + escapeHTML(fmtDur(s.seconds)) + '</span>' +
        '<span class="ago">' + fmtAgo(s.endedAt) + '</span>' +
        '<button class="del" data-del="' + s.id + '" title="Delete"><i class="fa-solid fa-xmark"></i></button>' +
      '</div>').join('');
  }

  function enterLive(){
    const setup = $('#focus-setup'), live = $('#focus-live'), view = $('#view-focus');
    if(view) view.classList.add('session-live');
    if(setup) setup.hidden = true;
    if(live) live.hidden = false;
    const s = $('#live-subject'), m = $('#live-mode');
    if(s) s.textContent = T.subject;
    if(m) m.textContent = T.guard ? 'Guard \u00b7 ' + modeLabel() : modeLabel();
    const g = $('#live-goal'), gt = $('#live-goal-text');
    if(g) g.hidden = !T.goal;
    if(gt) gt.textContent = T.goal;
    const panel = $('#guard-panel');
    if(panel) panel.hidden = !(T.guard || T.guardFailed);
    const cam = $('#camera-box');
    if(cam) cam.classList.toggle('preview-off', cfg().guardPreview === false);
    updateDistractCount();
    renderLive(true); renderStrip(); syncZenGuard();
  }
  function exitLive(){
    const setup = $('#focus-setup'), live = $('#focus-live'), view = $('#view-focus');
    if(view) view.classList.remove('session-live');
    if(setup) setup.hidden = false;
    if(live) live.hidden = true;
    const panel = $('#guard-panel');
    if(panel) panel.hidden = true;
    setZen(false);
  }

  function setZen(on){
    T.zen = !!on;
    const active = T.zen && T.active && State.view === 'focus';
    document.body.classList.toggle('focus-zen', active);
    const z = $('#live-zen');
    if(z){
      z.innerHTML = active
        ? '<i class="fa-solid fa-expand"></i><span>Minimal on</span>'
        : '<i class="fa-solid fa-compress"></i><span>Minimal</span>';
    }
    if(z) z.hidden = active;
    const leave = $('#live-leave');
    if(leave) leave.hidden = !active;
    syncZenGuard();
  }

  function syncZenGuard(){
    const z = $('#zen-guard');
    if(!z) return;
    z.hidden = !(T.active && !!T.guard && !T.guardFailed && document.body.classList.contains('focus-zen'));
  }

  function setRing(p, isBreak){
    const cont = $('#timer-ring-wrap'), ring = $('#timer-ring');
    if(!ring || !cont) return;
    ring.style.strokeDashoffset = RING_C * (1 - Math.max(0, Math.min(1, p)));
    cont.classList.toggle('break', !!isBreak);
  }
  function renderPomoDots(){
    const box = $('#pomo-dots'); if(!box) return;
    if(T.mode !== 'pomodoro'){ box.hidden = true; return; }
    box.hidden = false;
    let html = '';
    for(let i = 0; i < 4; i++){
      let cls = '';
      if(i < T.cycleCount) cls = 'done';
      else if(T.phase === 'work' && i === T.cycleCount) cls = 'now';
      html += '<span class="' + cls + '"></span>';
    }
    box.innerHTML = html;
  }

  function renderLive(force){
    if(!T.active) return;
    const key = T.mode === 'pomodoro'
      ? Math.ceil(Math.max(0, T.phaseLeft)) + '|' + T.phase + '|' + T.paused + '|' + (T.guard ? T.attention : '')
      : Math.floor(T.studiedSec) + '|' + T.paused + '|' + (T.guard ? T.attention : '');
    if(!force && key === T.lastRenderKey) return;
    T.lastRenderKey = key;

    const disp = $('#timer-display'), ph = $('#timer-phase');
    if(T.mode === 'pomodoro'){
      if(disp) disp.textContent = fmtClock(Math.max(0, Math.ceil(T.phaseLeft)));
      if(ph) ph.textContent = T.paused ? 'paused' : T.phase === 'work' ? 'focus' : 'break';
      setRing(T.phaseLen ? 1 - Math.max(0, T.phaseLeft) / T.phaseLen : 0, T.phase !== 'work');
    }else{
      if(disp) disp.textContent = fmtClock(T.studiedSec);
      if(ph) ph.textContent = T.paused ? 'paused' : 'counting';
      setRing((T.studiedSec % 60) / 60, false);
    }
    renderPomoDots();

    const sessionEl = $('#stat-session'); if(sessionEl) sessionEl.textContent = fmtClock(T.studiedSec + T.breakSec);
    const focusEl = $('#stat-focus'); if(focusEl) focusEl.textContent = fmtClock(T.guard ? T.focusSec : T.studiedSec);
    const breakEl = $('#stat-break'); if(breakEl) breakEl.textContent = fmtClock(T.breakSec);
    const pomoEl = $('#stat-pomos'); if(pomoEl) pomoEl.textContent = T.pomodoros;
    const alertEl = $('#stat-alerts'); if(alertEl) alertEl.textContent = T.distractionCount;

    const tg = $('#live-toggle');
    if(tg) tg.innerHTML = T.paused
      ? '<i class="fa-solid fa-play"></i><span>Resume</span>'
      : '<i class="fa-solid fa-pause"></i><span>Pause</span>';
    const add = $('#live-add'); if(add) add.hidden = T.mode !== 'pomodoro';
    const skip = $('#live-skip'); if(skip) skip.hidden = !(T.mode === 'pomodoro' && T.phase === 'break');

    const meta = $('.live-meta');
    if(meta) meta.classList.toggle('paused', T.paused);
    const liveMode = $('#live-mode');
    if(liveMode) liveMode.textContent = T.guard ? 'Guard \u00b7 ' + modeLabel() : modeLabel();

    if(!document.hidden){
      document.title = (T.paused ? 'Paused \u00b7 ' + T.subject
        : (T.mode === 'pomodoro' ? fmtClock(Math.max(0, Math.ceil(T.phaseLeft))) : fmtClock(T.studiedSec))
          + ' \u00b7 ' + T.subject) + ' — FocusFlow';
    }

    renderGuardStats();
    updateStrip();
    const now = Date.now();
    if(now - T.lastDash > 5000){
      T.lastDash = now;
      if(window.Dashboard) Dashboard.onTick();
      if(window.Rooms) Rooms.onTick();
    }
  }

  function renderGuardStats(){
    if(!T.guard) return;
    const total = T.focusSec + T.distractSec;
    const pct = total > 3 ? Math.round(T.focusSec / total * 100) : null;
    const gf = $('#g-focus'); if(gf) gf.textContent = fmtClock(T.focusSec);
    const gd = $('#g-distract'); if(gd) gd.textContent = fmtClock(T.distractSec);
    const gp = $('#g-pct'); if(gp) gp.textContent = pct == null ? '\u2014' : pct + '%';
    if(T.samples.length !== T.lastSampleCount){
      T.lastSampleCount = T.samples.length;
      const tl = $('#guard-timeline');
      if(tl){
        const s = T.samples.slice(-90);
        tl.innerHTML = s.length ? s.map(x => '<span class="seg ' + x + '"></span>').join('') : '<span class="seg i"></span>';
      }
    }
  }

  /* ---------- session strip ---------- */
  function renderStrip(){
    const strip = $('#session-strip'); if(!strip) return;
    if(!T.active){
      strip.style.display = 'none';
      strip.dataset.built = '0';
      return;
    }
    strip.style.display = 'block';
    strip.classList.toggle('paused', T.paused);
    if(strip.dataset.built !== '1' || strip.dataset.paused !== String(T.paused)){
      strip.dataset.built = '1';
      strip.dataset.paused = String(T.paused);
      strip.innerHTML =
        '<div class="strip-inner">' +
          '<span class="strip-dot"></span>' +
          '<span class="strip-time mono" id="strip-time">' + fmtClock(T.studiedSec) + '</span>' +
          '<span class="strip-sub">' + escapeHTML(T.subject) + ' \u00b7 ' + escapeHTML(modeLabel()) + '<span id="strip-phase"></span></span>' +
          '<span class="strip-actions">' +
            '<button class="btn btn-ghost" id="strip-toggle" type="button">' +
              (T.paused ? '<i class="fa-solid fa-play"></i>Resume' : '<i class="fa-solid fa-pause"></i>Pause') +
            '</button>' +
            '<button class="btn btn-primary" id="strip-finish" type="button"><i class="fa-solid fa-stop"></i>Finish</button>' +
          '</span>' +
        '</div>';
      $('#strip-toggle').addEventListener('click', togglePause);
      $('#strip-finish').addEventListener('click', () => finish());
    }
    updateStrip();
  }
  function updateStrip(){
    const t = $('#strip-time'); if(!t) return;
    t.textContent = fmtClock(T.studiedSec);
    const ph = $('#strip-phase');
    if(ph) ph.textContent = T.mode === 'pomodoro'
      ? ' \u00b7 ' + (T.phase === 'work' ? 'Focus ' : 'Break ') + fmtClock(Math.max(0, Math.ceil(T.phaseLeft)))
      : (T.paused ? ' \u00b7 paused' : '');
  }
  function resetTitle(){ document.title = 'FocusFlow — Study, Focus, Compete'; }

  /* ---------- events ---------- */
  function bindDistractions(){
    const box = $('#distract-cats');
    if(box) box.addEventListener('click', e => {
      const del = e.target.closest('[data-distract-del]');
      if(del){ deleteDistractCat(del.dataset.distractDel); return; }
      const ren = e.target.closest('[data-distract-rename]');
      if(ren){ renameDistractCat(ren.dataset.distractRename); return; }
      const chip = e.target.closest('[data-distract-cat]');
      if(chip){ selDistractCat = chip.dataset.distractCat; renderDistractCats(); }
    });
    const add = $('#distract-new');
    const addBtn = $('#distract-add');
    const addNow = () => {
      if(!add || !add.value.trim()) return;
      const name = add.value.trim();
      add.value = '';
      addDistractCat(name);
    };
    if(add) add.addEventListener('keydown', e => {
      if(e.key === 'Enter'){ e.preventDefault(); addNow(); }
    });
    if(addBtn) addBtn.addEventListener('click', addNow);
    const logBtn = $('#distract-log'); if(logBtn) logBtn.addEventListener('click', logDistraction);
    renderDistractCats();
  }

  function bindFocus(){
    syncSetup();
    paintSettings();

    const custom = $('#custom-subject');
    const addCustom = () => {
      if(!custom || !custom.value.trim()) return;
      const name = addCustomSubject(custom.value);
      if(!name){ toast('You can save up to 12 custom subjects', 'warn'); return; }
      selSubject = name;
      custom.value = '';
      renderSubjects(); updateStartSummary();
      toast('Subject added \u2014 ' + name, 'success');
    };
    if(custom) custom.addEventListener('keydown', e => {
      if(e.key === 'Enter'){ e.preventDefault(); addCustom(); }
    });
    const addBtn = $('#custom-subject-add'); if(addBtn) addBtn.addEventListener('click', addCustom);

    const goal = $('#session-goal');
    if(goal) goal.addEventListener('input', updateStartSummary);

    $$('#mode-seg .mode-card').forEach(b => b.addEventListener('click', () => {
      selMode = b.dataset.mode;
      paintMode(); updateStartSummary();
    }));

    $$('#pomo-presets .chip').forEach(b => b.addEventListener('click', () => {
      const [w, br] = String(b.dataset.pomo || '').split('-').map(Number);
      if(!w || !br) return;
      saveCfg({ pomoWork: w, pomoBreak: br });
      paintPomo(); updateStartSummary();
    }));
    const work = $('#pomo-work'), brk = $('#pomo-break'), lng = $('#pomo-long');
    [[work, 'pomoWork', 5, 120], [brk, 'pomoBreak', 1, 45], [lng, 'pomoLong', 5, 60]].forEach(([inp, key, min, max]) => {
      if(!inp) return;
      inp.addEventListener('change', () => {
        const c = cfg();
        const v = clampInt(inp.value, min, max, c[key]);
        inp.value = v;
        saveCfg({ [key]: v });
        paintPomo(); updateStartSummary();
      });
    });
    const lb = $('#longbreak-toggle');
    if(lb) lb.addEventListener('click', () => {
      const on = !cfg().longBreak;
      saveCfg({ longBreak: on });
      paintToggle('#longbreak-toggle', on);
    });

    const gt = $('#guard-toggle');
    if(gt) gt.addEventListener('click', () => {
      selGuard = !selGuard;
      paintGuard(); updateStartSummary();
    });
    $$('#guard-sens-chips .chip').forEach(ch => ch.addEventListener('click', () => {
      saveCfg({ guardSens: ch.dataset.sens });
      paintSettings();
      toast('Guard sensitivity — ' + ch.textContent, 'info');
    }));
    const phone = $('#guard-phone-toggle');
    if(phone) phone.addEventListener('click', () => {
      const on = !cfg().guardPhone;
      saveCfg({ guardPhone: on }); paintToggle('#guard-phone-toggle', on);
      toast('Phone detection ' + (on ? 'on' : 'off'), 'info');
    });
    const preview = $('#guard-preview-toggle');
    if(preview) preview.addEventListener('click', () => {
      const on = !cfg().guardPreview;
      saveCfg({ guardPreview: on }); paintToggle('#guard-preview-toggle', on);
    });
    const zen = $('#zen-toggle');
    if(zen) zen.addEventListener('click', () => {
      const on = !cfg().focusZen;
      saveCfg({ focusZen: on }); paintToggle('#zen-toggle', on);
    });
    const chime = $('#chime-toggle');
    if(chime) chime.addEventListener('click', () => {
      const on = !cfg().focusChime;
      saveCfg({ focusChime: on }); paintToggle('#chime-toggle', on);
    });
    const wake = $('#wake-toggle');
    if(wake) wake.addEventListener('click', () => {
      const on = !cfg().focusWake;
      saveCfg({ focusWake: on }); paintToggle('#wake-toggle', on);
      if(on) requestWakeLock(); else releaseWakeLock();
    });
    const autoNext = $('#auto-next-toggle');
    if(autoNext) autoNext.addEventListener('click', () => {
      const on = !cfg().autoNext;
      saveCfg({ autoNext: on }); paintToggle('#auto-next-toggle', on);
    });
    $$('#start-sound .chip').forEach(ch => ch.addEventListener('click', () => {
      selAmbience = ch.dataset.startSound || '';
      saveCfg({ startSound: selAmbience });
      paintSettings();
    }));

    const sb = $('#start-btn'); if(sb) sb.addEventListener('click', () => start());
    const tg = $('#live-toggle'); if(tg) tg.addEventListener('click', togglePause);
    const add5 = $('#live-add'); if(add5) add5.addEventListener('click', addFive);
    const skip = $('#live-skip'); if(skip) skip.addEventListener('click', skipBreak);
    const fin = $('#live-finish'); if(fin) fin.addEventListener('click', () => finish());
    const lz = $('#live-zen'); if(lz) lz.addEventListener('click', () => setZen(!T.zen));
    const ll = $('#live-leave'); if(ll) ll.addEventListener('click', () => setZen(false));

    const fc = $('#finish-cancel'); if(fc) fc.addEventListener('click', closeFinishModal);
    const fok = $('#finish-confirm'); if(fok) fok.addEventListener('click', () => finish(true));

    const sc = $('#sum-close'); if(sc) sc.addEventListener('click', closeSummary);
    const sa = $('#sum-again');
    if(sa) sa.addEventListener('click', () => {
      if(!lastSummary) return;
      const s = lastSummary;
      closeSummary();
      start({ subject: s.subject, mode: s.mode, goal: s.goal, guard: s.guard });
    });

    const box = $('#session-log');
    if(box) box.addEventListener('click', e => {
      const b = e.target.closest('[data-del]');
      if(!b) return;
      Store.set('sessions', Store.get('sessions', []).filter(s => s.id !== b.dataset.del));
      renderLog(); renderToday();
      if(window.Dashboard) Dashboard.refresh();
      toast('Session deleted', 'warn');
    });

    document.addEventListener('keydown', e => {
      if(!T.active || State.view !== 'focus') return;
      const t = e.target;
      if(t && t.matches && (t.matches('input,select,textarea') || t.isContentEditable)) return;
      if(e.key === 'd' || e.key === 'D'){ e.preventDefault(); logDistraction(); }
      else if(e.key === 'z' || e.key === 'Z'){ e.preventDefault(); setZen(!T.zen); }
    });

    document.addEventListener('visibilitychange', () => {
      if(!document.hidden && T.active && !T.paused) requestWakeLock();
      if(!document.hidden && T.active) renderLive(true);
    });

    bindDistractions();
    renderLog(); renderToday();
  }

  return {
    start, pause, resume, togglePause, finish,
    isActive: () => T.active,
    isPaused: () => T.paused,
    activeSubject: () => T.subject,
    liveSec: () => T.active ? T.studiedSec : 0,
    todaySeconds, calcStreak, stats, checkBadges, levelInfo, renderXPPill,
    badges: () => BADGES,
    customSubjects: customSubjectList, addCustomSubject,
    bindFocus, renderLog,
    onShow(){
      if(T.active){ enterLive(); setZen(T.zen); }
      else exitLive();
      renderLog(); renderToday();
    },
    onLeaveFocus(){ document.body.classList.remove('focus-zen'); }
  };
})();
window.Tracker = Tracker;
