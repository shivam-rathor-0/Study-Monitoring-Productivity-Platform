/* demo.js — seeded demo data for testing. Backs up real data to ff_demobackup. */
'use strict';

const Demo = (function(){

  const SEED = 0x1D3A55;
  const DAY = 86400000;
  const HOURS = [6, 7, 8, 9, 10, 11, 14, 15, 16, 17, 19, 20, 21, 22, 23, 0, 1];
  const CUSTOM_SUBJECTS = ['Statistics', 'Organic Chem', 'Data Structures', 'Hindi'];
  const KEYS = ['user', 'settings', 'sessions', 'tasks', 'stats', 'distractions', 'distractCats',
    'customSubjects', 'quizzes', 'quizcustom', 'codecustom', 'codedrafts', 'codesolved', 'rooms', 'chanvol'];

  function mulberry32(seed){
    let a = seed >>> 0;
    return function(){
      a = (a + 0x6D2B79F5) >>> 0;
      let t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  const pick = (arr, rand) => arr[Math.floor(rand() * arr.length)];
  let demoRand = null;

  function isLoaded(){
    return Store.get('demobackup', null) !== null;
  }

  function seedCore(){
    const rand = demoRand = mulberry32(SEED);
    const now = Date.now();
    const nowD = new Date();
    const nowHour = nowD.getHours();
    const nowMin = nowD.getMinutes();

    Store.set('settings', {
      dailyGoal: 180, pomoWork: 25, pomoBreak: 5, pomoLong: 15, longBreak: true,
      guardSens: 'balanced', guardPhone: true, guardPreview: true,
      focusZen: true, focusChime: true, focusWake: true, autoNext: true,
      startSound: '', lastSubject: 'Mathematics', lastMode: 'stopwatch'
    });
    Store.set('customSubjects', CUSTOM_SUBJECTS.slice());
    Store.set('distractCats', ['Phone', 'Noise', 'Daydreaming', 'Social media', 'Hunger']);

    const subjects = SUBJECTS.concat(CUSTOM_SUBJECTS);
    const weights = SUBJECTS.map(() => 1).concat(CUSTOM_SUBJECTS.map(() => .55));
    const totalWeight = weights.reduce((a, b) => a + b, 0);
    const pickSubject = () => {
      let r = rand() * totalWeight;
      for(let i = 0; i < subjects.length; i++){
        r -= weights[i];
        if(r <= 0) return subjects[i];
      }
      return subjects[subjects.length - 1];
    };

    const usedStarts = new Set();
    const sessions = [];

    for(let off = 89; off >= 0; off--){
      const recent = off < 10;
      if(!recent && rand() < .72) continue;

      const day = new Date(nowD.getFullYear(), nowD.getMonth(), nowD.getDate() - off);
      const count = 1 + Math.floor(rand() * 3);

      for(let n = 0; n < count; n++){
        const today = off === 0;
        let hours = HOURS;
        if(today) hours = HOURS.filter(h => h <= nowHour);
        if(!hours.length) hours = [nowHour];

        const hour = pick(hours, rand);
        const maxMin = today && hour === nowHour ? nowMin : 59;
        const minute = Math.floor(rand() * (maxMin + 1));
        let startedAt = new Date(day.getFullYear(), day.getMonth(), day.getDate(), hour, minute, 0, 0).getTime();
        let guardLoop = 0;
        while(usedStarts.has(startedAt) && guardLoop++ < 120) startedAt -= 60000;
        if(startedAt > now) startedAt = now - 60000;
        usedStarts.add(startedAt);

        const seconds = (22 + Math.floor(rand() * 74)) * 60;
        const endedAt = startedAt + seconds * 1000;
        const mode = rand() < .55 ? 'pomodoro' : 'stopwatch';
        const guard = rand() < .45;

        let reasons = {};
        let focusPct = null, focusSec = 0, distractSec = 0;
        let distractionCount = 0;

        if(guard){
          const base = hour >= 5 && hour < 12 ? 90 : hour >= 12 && hour < 17 ? 80 : 68;
          focusPct = Math.max(38, Math.min(99, base + Math.floor(rand() * 15) - 7));
          focusSec = Math.round(seconds * focusPct / 100);
          distractSec = seconds - focusSec;
          reasons = {
            looking: Math.floor(rand() * 4),
            drowsy: Math.floor(rand() * 3),
            phone: Math.floor(rand() * 3),
            away: Math.floor(rand() * 2)
          };
          distractionCount = reasons.looking + reasons.drowsy + reasons.phone + reasons.away;
        }

        sessions.push({
          id: 's' + startedAt,
          subject: pickSubject(),
          mode: mode,
          seconds: seconds,
          pomodoros: mode === 'pomodoro' ? Math.floor(seconds / 1500) : 0,
          date: dateKey(new Date(startedAt)),
          startedAt: startedAt,
          endedAt: endedAt,
          guard: guard,
          reasons: reasons,
          focusSec: focusSec,
          distractSec: distractSec,
          focusPct: focusPct,
          distractionCount: distractionCount
        });
      }
    }

    sessions.sort((a, b) => a.startedAt - b.startedAt);
    Store.set('sessions', sessions);

    const titles = [
      'Revise integration formulas', 'Finish physics lab write-up', 'Read chapter 4 — cell division',
      'Practice 10 SQL queries', 'Summarise the history reading', 'Draft essay outline',
      'Solve 5 array problems', 'Review economics graphs', 'Memorise 20 Hindi words',
      'Write chemistry notes', 'Do geography map work', 'Redo maths mistakes',
      'Prepare English presentation', 'Plan next week', 'Review statistics formulas',
      'Read organic chemistry mechanisms', 'Build a data structures cheat sheet', 'Practice Hindi verbs',
      'Complete physics numericals', 'Update flashcards', 'Review biology diagrams',
      'Take a mock quiz', 'Clean up notes', 'Do 20 minutes of revision',
      'Read ahead for tomorrow', 'Organise the desk', 'Write a summary sheet',
      'Check homework answers', 'Practise past paper', 'Set tomorrow goals'
    ];
    const tasks = titles.map((title, i) => {
      const created = now - Math.floor(rand() * 30) * DAY - Math.floor(rand() * DAY);
      const done = i < 26;
      const doneAt = done ? Math.min(now, created + Math.floor(rand() * 72) * 3600000) : null;
      return {
        id: 't' + (i + 1),
        title: title,
        subject: pickSubject(),
        p: Math.floor(rand() * 3),
        done: done,
        created: created,
        doneAt: doneAt
      };
    });
    Store.set('tasks', tasks);

    const xp = Math.floor(sessions.reduce((a, s) => a + (s.guard ? s.focusSec : s.seconds), 0) / 60);
    Store.set('stats', { xp: xp, badges: [] });

    const cats = ['Phone', 'Noise', 'Daydreaming', 'Social media', 'Hunger'];
    const distractions = [];
    for(let i = 0; i < 90; i++){
      const s = sessions[Math.floor(rand() * sessions.length)];
      const cat = rand() < .65 ? 'Phone' : pick(cats, rand);
      const at = s.startedAt + Math.floor(rand() * Math.max(1, s.seconds)) * 1000;
      const entry = { cat: cat, at: at, sessionId: s.id };
      if(cat === 'Phone' && rand() < .35) entry.auto = true;
      distractions.push(entry);
    }
    distractions.sort((a, b) => a.at - b.at);
    Store.set('distractions', distractions);

    if(Store.get('user', null) === null){
      Store.set('user', { name: 'Demo Topper', hue: '#F6B93B', since: now - 95 * DAY });
    }

    Store.set('chanvol', { lofi: .85, rain: .6, jazz: .9, fire: .45, piano: .65 });

    if(window.Tracker && Tracker.checkBadges) Tracker.checkBadges();
  }

  function seedExtra(){
    const rand = demoRand || (demoRand = mulberry32(SEED));
    const now = Date.now();

    const quizzes = [];
    const totals = [5, 10, 20];
    for(let i = 0; i < 26; i++){
      const total = pick(totals, rand);
      const pct = 45 + rand() * 53;
      const low = Math.ceil(total * 0.45);
      const high = Math.floor(total * 0.98);
      const correct = Math.max(low, Math.min(high, Math.round(total * pct / 100)));
      const subject = rand() < .3 ? 'Mixed' : pick(SUBJECTS, rand);
      const at = now - Math.floor(rand() * 60) * DAY - Math.floor(rand() * 24) * 3600000;
      quizzes.push({ date: dateKey(new Date(at)), subject: subject, total: total, correct: correct, at: at });
    }
    quizzes.sort((a, b) => a.at - b.at);
    Store.set('quizzes', quizzes);

    Store.set('quizcustom', [
      {
        q: 'What does the mean of a dataset measure?',
        options: ['Average value', 'Middle value', 'Most frequent value', 'Spread of values'],
        answer: 0,
        subject: 'Statistics'
      },
      {
        q: 'Which measure is most affected by extreme outliers?',
        options: ['Median', 'Mode', 'Mean', 'Interquartile range'],
        answer: 2,
        subject: 'Statistics'
      },
      {
        q: 'What is the median of 3, 7, 9, 12, 15?',
        options: ['7', '9', '12', '15'],
        answer: 1,
        subject: 'Statistics'
      },
      {
        q: 'In a normal distribution, approximately what percentage of data lies within one standard deviation of the mean?',
        options: ['50%', '68%', '95%', '99%'],
        answer: 1,
        subject: 'Statistics'
      },
      {
        q: 'What is the general formula for alkanes?',
        options: ['CnH2n', 'CnH2n+2', 'CnH2n-2', 'CnHn'],
        answer: 1,
        subject: 'Organic Chem'
      },
      {
        q: 'Which functional group is present in alcohols?',
        options: ['-CHO', '-COOH', '-OH', '-NH2'],
        answer: 2,
        subject: 'Organic Chem'
      },
      {
        q: 'What is the hybridization of carbon in ethyne (C2H2)?',
        options: ['sp', 'sp2', 'sp3', 'sp3d'],
        answer: 0,
        subject: 'Organic Chem'
      },
      {
        q: 'Which reaction converts an alkene to an alkane?',
        options: ['Hydration', 'Hydrogenation', 'Halogenation', 'Oxidation'],
        answer: 1,
        subject: 'Organic Chem'
      },
      {
        q: 'Which data structure follows FIFO order?',
        options: ['Stack', 'Queue', 'Heap', 'Tree'],
        answer: 1,
        subject: 'Data Structures'
      },
      {
        q: 'What is the average time complexity of searching in a balanced binary search tree?',
        options: ['O(1)', 'O(log n)', 'O(n)', 'O(n log n)'],
        answer: 1,
        subject: 'Data Structures'
      },
      {
        q: 'Which structure is best for implementing a priority queue?',
        options: ['Array', 'Linked list', 'Heap', 'Hash table'],
        answer: 2,
        subject: 'Data Structures'
      },
      {
        q: 'What does a hash table use to map keys to values?',
        options: ['A hash function', 'A pointer', 'A stack', 'A queue'],
        answer: 0,
        subject: 'Data Structures'
      },
      {
        q: "What does 'पुस्तक' mean in English?",
        options: ['Book', 'Pen', 'Chair', 'Bag'],
        answer: 0,
        subject: 'Hindi'
      },
      {
        q: "Which word means 'water'?",
        options: ['आग', 'जल', 'मिट्टी', 'हवा'],
        answer: 1,
        subject: 'Hindi'
      },
      {
        q: "What does 'सूर्य' refer to?",
        options: ['Moon', 'Star', 'Sun', 'Sky'],
        answer: 2,
        subject: 'Hindi'
      }
    ]);

    const codeBase = SEED.toString(36);
    const sumId = 'c-' + codeBase + '-a1';
    const vowelsId = 'c-' + codeBase + '-a2';
    const secondId = 'c-' + codeBase + '-a3';
    const sumStarter = 'function sumDigits(n) {\n  // your code\n}';
    const vowelsStarter = 'function countVowels(s) {\n  // your code\n}';
    const secondStarter = 'function secondLargest(nums) {\n  // your code\n}';

    Store.set('codecustom', [
      {
        id: sumId,
        title: 'Sum of Digits',
        difficulty: 'Easy',
        fn: 'sumDigits',
        statement: 'Given a non-negative integer n, return the sum of its digits. For example, 123 gives 1 + 2 + 3 = 6.',
        starter: sumStarter,
        starters: {
          javascript: sumStarter,
          python: 'def sumDigits(n):\n    return None'
        },
        tests: [
          { name: 'Three digits', args: [123], expected: 6 },
          { name: 'Zero', args: [0], expected: 0 },
          { name: 'Repeated nines', args: [999], expected: 27 },
          { name: 'Power of ten', args: [1000], expected: 1 },
          { name: 'Larger number', args: [123456], expected: 21 }
        ]
      },
      {
        id: vowelsId,
        title: 'Count Vowels',
        difficulty: 'Easy',
        fn: 'countVowels',
        statement: 'Given a string s, return the number of vowels in it. Count a, e, i, o and u in either case.',
        starter: vowelsStarter,
        starters: {
          javascript: vowelsStarter,
          python: 'def countVowels(s):\n    return None'
        },
        tests: [
          { name: 'Simple word', args: ['hello'], expected: 2 },
          { name: 'All upper case', args: ['AEIOU'], expected: 5 },
          { name: 'No vowels', args: ['xyz'], expected: 0 },
          { name: 'Mixed case', args: ['Statistics'], expected: 3 },
          { name: 'Empty string', args: [''], expected: 0 }
        ]
      },
      {
        id: secondId,
        title: 'Second Largest',
        difficulty: 'Medium',
        fn: 'secondLargest',
        statement: 'Given an array of numbers, return the second largest distinct value. Return null if there is no second largest value.',
        starter: secondStarter,
        starters: {
          javascript: secondStarter,
          python: 'def secondLargest(nums):\n    return None'
        },
        tests: [
          { name: 'Three values', args: [[1, 2, 3]], expected: 2 },
          { name: 'With duplicates', args: [[5, 5, 2]], expected: 2 },
          { name: 'All equal', args: [[7, 7]], expected: null },
          { name: 'Single value', args: [[1]], expected: null },
          { name: 'Empty array', args: [[]], expected: null },
          { name: 'Negative values', args: [[-1, -2, -3]], expected: -2 }
        ]
      }
    ]);

    Store.set('codesolved', ['two-sum', 'reverse-string', 'valid-parentheses', 'fizzbuzz',
      'palindrome-number', 'max-subarray', 'merge-sorted-arrays', 'fibonacci', sumId]);

    Store.set('codedrafts', {
      'two-sum': {
        javascript: 'function twoSum(nums, target) {\n  const seen = new Map();\n  for (let i = 0; i < nums.length; i++) {\n    const need = target - nums[i];\n    if (seen.has(need)) return [seen.get(need), i];\n    seen.set(nums[i], i);\n  }\n  return [];\n}',
        python: 'def twoSum(nums, target):\n    seen = {}\n    for i, n in enumerate(nums):\n        need = target - n\n        if need in seen:\n            return [seen[need], i]\n        seen[n] = i\n    return []'
      }
    });

    const safeHue = v => typeof safeColor === 'function'
      ? safeColor(v, '#F6B93B')
      : (/^#[0-9a-f]{6}$/i.test(v || '') ? v : '#F6B93B');
    const user = (typeof State !== 'undefined' && State.user)
      ? State.user
      : (Store.get('user', null) || { name: 'You', hue: '#F6B93B' });
    const me = {
      id: 'me',
      name: user.name,
      bot: false,
      hue: safeHue(user.hue),
      level: 8,
      todaySec: 0,
      weekSec: 0,
      studying: false,
      subject: ''
    };

    const roomHues = ['#F6B93B', '#4FB286', '#5B9BD5', '#C97B63',
      '#A78BDB', '#E4739C', '#56C4C6', '#8FBF4D'];
    const names = ['Aarav', 'Maya', 'Ishaan', 'Zara', 'Kabir', 'Ananya', 'Rohan', 'Diya',
      'Vivaan', 'Sara', 'Arjun', 'Meera'];
    const chatLines = [
      'Morning all, starting a 45 minute block now.',
      'Anyone else revising statistics today?',
      'Just finished a pomodoro, taking five.',
      'The board exam timetable is out, check it.',
      'I am on the coding problems track this week.',
      'Coffee break, back in ten.',
      'Dropping my daily goal: three focused hours.',
      'Night session starting, joining the sprint.'
    ];

    function makeRoom(code, name, count){
      const pool = names.slice();
      for(let i = pool.length - 1; i > 0; i--){
        const j = Math.floor(rand() * (i + 1));
        const tmp = pool[i]; pool[i] = pool[j]; pool[j] = tmp;
      }
      const bots = pool.slice(0, count - 1).map((n, i) => {
        const todaySec = rand() < .15 ? 0 : Math.floor(rand() * 170 + 5) * 60;
        return {
          id: 'b' + code.toLowerCase() + (i + 1),
          name: n,
          bot: true,
          hue: pick(roomHues, rand),
          level: 1 + Math.floor(rand() * 16),
          todaySec: todaySec,
          weekSec: todaySec + Math.floor(rand() * 9 * 3600),
          studying: rand() < .65,
          subject: pick(SUBJECTS, rand)
        };
      });
      const chat = [];
      for(let i = 0; i < 8; i++){
        const m = bots[i % bots.length];
        chat.push({
          me: false,
          name: m.name,
          hue: m.hue,
          text: chatLines[i],
          ts: now - (9 - i) * 300000
        });
      }
      chat.push({
        me: true,
        name: me.name,
        hue: me.hue,
        text: 'Checking in — 25 minute sprint starting now.',
        ts: now - 60000
      });
      return {
        code: code,
        name: name,
        createdAt: now - Math.floor(3 + rand() * 20) * DAY,
        members: bots.concat([me]),
        chat: chat
      };
    }

    Store.set('rooms', {
      FOCUS7: makeRoom('FOCUS7', 'Night Owls', 7),
      BOARDS26: makeRoom('BOARDS26', 'Board Exam Grind', 6),
      CODE42: makeRoom('CODE42', 'Coding Club', 5)
    });
  }

  function refreshUI(){
    if(window.Dashboard && Dashboard.refresh) Dashboard.refresh();
    if(window.Tracker && Tracker.renderXPPill) Tracker.renderXPPill();
    if(window.Tracker && Tracker.renderLog) Tracker.renderLog();
    if(window.Tasks && Tasks.render) Tasks.render();
  }

  function load(){
    try{
      if(window.Tracker && Tracker.isActive && Tracker.isActive()){
        toast('Finish the current session before loading demo data', 'warn');
        return;
      }
      if(!isLoaded()){
        const snap = {};
        KEYS.forEach(k => { snap[k] = Store.get(k, null); });
        Store.set('demobackup', snap);
      }
      seedCore();
      if(typeof seedExtra === 'function') seedExtra();
      refreshUI();
      toast('Demo data loaded', 'success');
    }catch(e){
      toast('Could not load demo data', 'error');
    }
  }

  function restore(){
    try{
      const snap = Store.get('demobackup', null);
      if(snap === null || typeof snap !== 'object'){
        toast('Nothing to restore', 'warn');
        return;
      }
      KEYS.forEach(k => {
        if(snap[k] == null) Store.del(k);
        else Store.set(k, snap[k]);
      });
      Store.del('demobackup');
      refreshUI();
      toast('Your real data has been restored', 'success');
    }catch(e){
      toast('Could not restore data', 'error');
    }
  }

  return { load, restore, isLoaded };
})();
window.Demo = Demo;
