'use strict';

Quiz.addBank([
  {
    q: 'Which civilization built the ancient cities of Harappa and Mohenjo-daro?',
    options: ['Indus Valley Civilization', 'Mesopotamian Civilization', 'Egyptian Civilization', 'Chinese Civilization'],
    answer: 0,
    subject: 'History',
    explain: 'Harappa and Mohenjo-daro were major cities of the Indus Valley Civilization.'
  },
  {
    q: 'Who founded the Mauryan Empire?',
    options: ['Ashoka', 'Chandragupta Maurya', 'Bindusara', 'Samudragupta'],
    answer: 1,
    subject: 'History',
    explain: 'Chandragupta Maurya founded the Mauryan Empire around 321 BCE.'
  },
  {
    q: 'Which Mauryan emperor fought the Kalinga War and later embraced Buddhism?',
    options: ['Chandragupta Maurya', 'Bindusara', 'Harshavardhana', 'Ashoka'],
    answer: 3,
    subject: 'History',
    explain: 'Ashoka fought the Kalinga War and afterwards promoted Buddhism.'
  },
  {
    q: 'Who wrote the ancient Indian astronomical text Aryabhatiya?',
    options: ['Aryabhata', 'Varahamihira', 'Brahmagupta', 'Bhaskara I'],
    answer: 0,
    subject: 'History',
    explain: 'Aryabhata wrote the Aryabhatiya in the late fifth century CE.'
  },
  {
    q: 'Who founded the Mughal Empire in India?',
    options: ['Akbar', 'Babur', 'Humayun', 'Shah Jahan'],
    answer: 1,
    subject: 'History',
    explain: 'Babur founded the Mughal Empire after the First Battle of Panipat in 1526.'
  },
  {
    q: 'In which year was the First Battle of Panipat fought?',
    options: ['1556', '1600', '1526', '1707'],
    answer: 2,
    subject: 'History',
    explain: 'The First Battle of Panipat was fought in 1526 between Babur and Ibrahim Lodi.'
  },
  {
    q: 'Which Mughal emperor commissioned the Taj Mahal?',
    options: ['Akbar', 'Jahangir', 'Aurangzeb', 'Shah Jahan'],
    answer: 3,
    subject: 'History',
    explain: 'Shah Jahan commissioned the Taj Mahal in memory of Mumtaz Mahal.'
  },
  {
    q: 'Who founded the Slave Dynasty of the Delhi Sultanate?',
    options: ['Qutb-ud-din Aibak', 'Iltutmish', 'Balban', 'Alauddin Khalji'],
    answer: 0,
    subject: 'History',
    explain: 'Qutb-ud-din Aibak founded the Slave Dynasty in 1206.'
  },
  {
    q: 'In which year was the Indian National Congress founded?',
    options: ['1857', '1885', '1905', '1919'],
    answer: 1,
    subject: 'History',
    explain: 'The Indian National Congress was founded in 1885.'
  },
  {
    q: 'In which year did Lord Curzon partition Bengal?',
    options: ['1885', '1911', '1905', '1919'],
    answer: 2,
    subject: 'History',
    explain: 'Lord Curzon partitioned Bengal in 1905, sparking the Swadeshi movement.'
  },
  {
    q: 'In which city did the Jallianwala Bagh massacre take place?',
    options: ['Delhi', 'Lahore', 'Kolkata', 'Amritsar'],
    answer: 3,
    subject: 'History',
    explain: 'The Jallianwala Bagh massacre took place in Amritsar in 1919.'
  },
  {
    q: 'Who led the Dandi March in 1930?',
    options: ['Jawaharlal Nehru', 'Subhas Chandra Bose', 'Mahatma Gandhi', 'Sardar Patel'],
    answer: 2,
    subject: 'History',
    explain: 'Mahatma Gandhi led the Dandi March, also called the Salt Satyagraha, in 1930.'
  },
  {
    q: 'In which year was the Quit India Movement launched?',
    options: ['1930', '1935', '1947', '1942'],
    answer: 3,
    subject: 'History',
    explain: 'The Quit India Movement was launched in August 1942.'
  },
  {
    q: 'In which year did India become independent?',
    options: ['1942', '1945', '1947', '1950'],
    answer: 2,
    subject: 'History',
    explain: 'India became independent on 15 August 1947.'
  },
  {
    q: 'In which year did World War I begin?',
    options: ['1912', '1914', '1918', '1939'],
    answer: 1,
    subject: 'History',
    explain: 'World War I began in 1914.'
  },
  {
    q: 'Which country did Germany invade in 1939, starting World War II in Europe?',
    options: ['Poland', 'France', 'Belgium', 'Soviet Union'],
    answer: 0,
    subject: 'History',
    explain: 'Germany invaded Poland on 1 September 1939, starting World War II in Europe.'
  },
  {
    q: 'In which year did World War II end?',
    options: ['1939', '1941', '1943', '1945'],
    answer: 3,
    subject: 'History',
    explain: 'World War II ended in 1945.'
  },
  {
    q: 'Which city was the target of the first atomic bomb used in war?',
    options: ['Nagasaki', 'Tokyo', 'Hiroshima', 'Osaka'],
    answer: 2,
    subject: 'History',
    explain: 'The first atomic bomb used in war was dropped on Hiroshima in 1945.'
  },
  {
    q: 'In which year did the French Revolution begin?',
    options: ['1789', '1776', '1848', '1917'],
    answer: 0,
    subject: 'History',
    explain: 'The French Revolution began in 1789.'
  },
  {
    q: 'In which year did the October Revolution take place in Russia?',
    options: ['1905', '1917', '1929', '1945'],
    answer: 1,
    subject: 'History',
    explain: 'The Bolsheviks seized power in the October Revolution of 1917.'
  }
]);
