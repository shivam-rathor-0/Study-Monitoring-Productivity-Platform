/* tasks.js — to-do list with custom subjects and priorities */
'use strict';

const Tasks = (function(){

  let filter = 'all';
  const list = () => Store.get('tasks', []);
  const prio = t => (t.p == null ? 1 : t.p);

  function fillSubjectDatalist(){
    const dl = $('#subject-options'); if(!dl) return;
    const custom = window.Tracker && typeof Tracker.customSubjects === 'function'
      ? Tracker.customSubjects() : [];
    const seen = new Set();
    const names = SUBJECTS.concat(['General'], custom).filter(s => {
      const key = s.toLowerCase();
      if(seen.has(key)) return false;
      seen.add(key);
      return true;
    });
    dl.innerHTML = names.map(s => '<option value="' + escapeHTML(s) + '"></option>').join('');
  }

  function bind(){
    const form = $('#task-form');
    if(form) form.addEventListener('submit', e => {
      e.preventDefault();
      const input = $('#task-input'), subj = $('#task-subject'), pr = $('#task-priority');
      const title = input.value.trim();
      if(!title) return;
      add(title,
        (subj ? subj.value.trim() : '') || 'General',
        pr ? (isNaN(parseInt(pr.value, 10)) ? 1 : parseInt(pr.value, 10)) : 1);
      input.value = '';
      if(subj) subj.value = '';
      input.focus();
    });

    $$('.filter-row .chip[data-filter]').forEach(c => c.addEventListener('click', () => {
      filter = c.dataset.filter;
      $$('.filter-row .chip[data-filter]').forEach(x => x.classList.toggle('active', x === c));
      render();
    }));

    const box = $('#task-list');
    if(box) box.addEventListener('click', e => {
      const check = e.target.closest('[data-check]');
      if(check){ toggle(check.dataset.check); return; }

      const focus = e.target.closest('[data-focus]');
      if(focus){
        const t = list().find(x => x.id === focus.dataset.focus);
        if(t && window.Tracker){
          if(Tracker.isActive()){
            toast('A session is already running', 'warn');
          }else{
            Tracker.start({ subject: t.subject });
            location.hash = '#/focus';
            toast('Focus session started — ' + t.subject, 'success');
          }
        }
        return;
      }

      const del = e.target.closest('[data-del]');
      if(del){
        Store.set('tasks', list().filter(x => x.id !== del.dataset.del));
        render();
        if(window.Dashboard) Dashboard.refresh();
      }
    });
    fillSubjectDatalist();
    render();
  }

  function add(title, subject, p){
    const l = list();
    l.push({ id:'t' + Date.now(), title, subject, p, done:false, created:Date.now(), doneAt:null });
    Store.set('tasks', l);
    const builtIn = SUBJECTS.some(s => s.toLowerCase() === String(subject).toLowerCase());
    if(subject && subject !== 'General' && !builtIn && window.Tracker && Tracker.addCustomSubject){
      Tracker.addCustomSubject(subject);
    }
    fillSubjectDatalist();
    Sound.sfx('done');
    render();
    if(window.Dashboard) Dashboard.refresh();
    if(window.Tracker) Tracker.checkBadges();
  }

  function toggle(id){
    const l = list();
    const t = l.find(x => x.id === id);
    if(!t) return;
    t.done = !t.done;
    t.doneAt = t.done ? Date.now() : null;
    Store.set('tasks', l);
    Sound.sfx(t.done ? 'done' : 'pause');
    render();
    if(window.Dashboard) Dashboard.refresh();
    if(window.Tracker) Tracker.checkBadges();
  }

  function render(){
    const box = $('#task-list'); if(!box) return;
    let l = list();
    if(filter === 'pending') l = l.filter(t => !t.done);
    if(filter === 'done')    l = l.filter(t => t.done);

    l = [...l].sort((a, b) => (a.done - b.done) || (prio(b) - prio(a)) || (b.created - a.created));

    const all = list();
    const doneN = all.filter(t => t.done).length;
    const fill = $('#task-progress-fill'), txt = $('#task-progress-text');
    if(fill) fill.style.width = (all.length ? doneN / all.length * 100 : 0) + '%';
    if(txt) txt.textContent = doneN + '/' + all.length + ' done';

    if(!l.length){
      box.innerHTML = '<div class="empty"><i class="fa-solid fa-list-check"></i><p>' +
        (all.length ? 'No tasks in this filter' : 'No tasks yet — add one above') + '</p></div>';
      return;
    }
    const PN = ['Low', 'Medium', 'High'];
    box.innerHTML = l.map(t => {
      const c = hueFor(t.subject);
      return '<div class="task-row ' + (t.done ? 'done' : '') + '">' +
        '<button class="task-check" data-check="' + t.id + '" type="button" title="Toggle">' +
          (t.done ? '<i class="fa-solid fa-check"></i>' : '') + '</button>' +
        '<span class="task-title">' + escapeHTML(t.title) + '</span>' +
        '<span class="prio p' + prio(t) + '">' + PN[prio(t)] + '</span>' +
        '<span class="task-subject" style="color:color-mix(in srgb,' + c + ' 55%,var(--text));border-color:' + c + '55">' + escapeHTML(t.subject) + '</span>' +
        '<span class="task-ago">' + fmtAgo(t.created) + '</span>' +
        '<span class="task-actions">' +
          (!t.done ? '<button data-focus="' + t.id + '" type="button" title="Start a focus session for this subject"><i class="fa-solid fa-play"></i></button>' : '') +
          '<button class="trash" data-del="' + t.id + '" type="button" title="Delete"><i class="fa-solid fa-xmark"></i></button>' +
        '</span>' +
      '</div>';
    }).join('');
  }

  return { bind, render, list, toggle };
})();
window.Tasks = Tasks;