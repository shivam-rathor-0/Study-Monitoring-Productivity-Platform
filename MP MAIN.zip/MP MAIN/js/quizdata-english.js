'use strict';

Quiz.addBank([
  {
    q: 'Which sentence is grammatically correct?',
    options: ['She don\'t like coffee.', 'She doesn\'t like coffee.', 'She not likes coffee.', 'She doesn\'t likes coffee.'],
    answer: 1,
    subject: 'English',
    explain: 'The third-person singular subject "she" takes "doesn\'t" followed by the base verb "like".'
  },
  {
    q: 'In the sentence "She sings beautifully", what part of speech is "beautifully"?',
    options: ['Adverb', 'Adjective', 'Noun', 'Verb'],
    answer: 0,
    subject: 'English',
    explain: '"Beautifully" describes how she sings, so it is an adverb.'
  },
  {
    q: 'Choose the correct indefinite article: ___ European country.',
    options: ['An', 'The', 'A', 'No article'],
    answer: 2,
    subject: 'English',
    explain: '"European" begins with a consonant sound, so the correct indefinite article is "a".'
  },
  {
    q: 'Identify the subject in the sentence "The tall boy ran quickly."',
    options: ['The tall boy', 'Ran', 'Quickly', 'Boy ran'],
    answer: 0,
    subject: 'English',
    explain: '"The tall boy" is the person performing the action, so it is the subject.'
  },
  {
    q: 'Which sentence is in the passive voice?',
    options: ['The chef cooked the meal.', 'The chef is cooking the meal.', 'The chef will cook the meal.', 'The meal was cooked by the chef.'],
    answer: 3,
    subject: 'English',
    explain: 'In the passive voice, the object ("the meal") becomes the subject and is acted upon.'
  },
  {
    q: 'Choose the correct indirect speech: The teacher said to us, "Open your books."',
    options: ['The teacher said us to open our books.', 'The teacher said that open your books.', 'The teacher told us to open our books.', 'The teacher told that we open our books.'],
    answer: 2,
    subject: 'English',
    explain: 'For a command, "said to" becomes "told" followed by the object and the infinitive.'
  },
  {
    q: 'Choose the correct form: If I ___ rich, I would travel the world.',
    options: ['am', 'were', 'be', 'is'],
    answer: 1,
    subject: 'English',
    explain: 'The unreal conditional uses "were" for all subjects.'
  },
  {
    q: 'Which sentence uses the present perfect tense?',
    options: ['She writes a letter.', 'She wrote a letter.', 'She is writing a letter.', 'She has written a letter.'],
    answer: 3,
    subject: 'English',
    explain: 'The present perfect is formed with "has" or "have" plus the past participle.'
  },
  {
    q: 'Choose the correct past tense: He ___ to school yesterday.',
    options: ['go', 'goes', 'went', 'gone'],
    answer: 2,
    subject: 'English',
    explain: '"Went" is the simple past tense of "go".'
  },
  {
    q: 'Which word is a synonym of "abundant"?',
    options: ['Plentiful', 'Scarce', 'Tiny', 'Weak'],
    answer: 0,
    subject: 'English',
    explain: '"Abundant" means existing in large quantities, or plentiful.'
  },
  {
    q: 'Which word is an antonym of "brave"?',
    options: ['Courageous', 'Cowardly', 'Bold', 'Fearless'],
    answer: 1,
    subject: 'English',
    explain: '"Cowardly" means lacking courage, which is the opposite of brave.'
  },
  {
    q: 'What does the idiom "to let the cat out of the bag" mean?',
    options: ['To release a pet', 'To cause trouble', 'To reveal a secret', 'To run away'],
    answer: 2,
    subject: 'English',
    explain: 'The idiom means to reveal information that was meant to be secret.'
  },
  {
    q: 'Choose the correctly spelled word.',
    options: ['Recieve', 'Receeve', 'Receve', 'Receive'],
    answer: 3,
    subject: 'English',
    explain: '"Receive" follows the rule "i before e except after c".'
  },
  {
    q: 'What is the meaning of the prefix "anti-"?',
    options: ['Before', 'After', 'Between', 'Against'],
    answer: 3,
    subject: 'English',
    explain: 'The prefix "anti-" means against or opposed to.'
  },
  {
    q: 'Identify the figure of speech: "The wind whispered through the trees."',
    options: ['Simile', 'Metaphor', 'Personification', 'Hyperbole'],
    answer: 2,
    subject: 'English',
    explain: 'Giving human qualities to the wind is personification.'
  },
  {
    q: 'Which of these is a simile?',
    options: ['As brave as a lion', 'He is a lion.', 'The lion roared.', 'Lions are brave.'],
    answer: 0,
    subject: 'English',
    explain: 'A simile compares two things using "like" or "as".'
  },
  {
    q: 'Who wrote the play "Romeo and Juliet"?',
    options: ['Charles Dickens', 'John Keats', 'George Orwell', 'William Shakespeare'],
    answer: 3,
    subject: 'English',
    explain: 'William Shakespeare wrote the tragedy "Romeo and Juliet".'
  },
  {
    q: 'Who is the author of the novel "Pride and Prejudice"?',
    options: ['Jane Austen', 'Emily Brontë', 'Virginia Woolf', 'Mary Shelley'],
    answer: 0,
    subject: 'English',
    explain: 'Jane Austen published "Pride and Prejudice" in 1813.'
  },
  {
    q: 'In "The Merchant of Venice", who is the moneylender?',
    options: ['Antonio', 'Shylock', 'Bassanio', 'Portia'],
    answer: 1,
    subject: 'English',
    explain: 'Shylock is the moneylender who demands a pound of Antonio\'s flesh.'
  },
  {
    q: 'Who wrote the epic poem "Paradise Lost"?',
    options: ['Charles Dickens', 'John Milton', 'John Keats', 'George Orwell'],
    answer: 1,
    subject: 'English',
    explain: 'John Milton wrote the epic poem "Paradise Lost", first published in 1667.'
  }
]);
