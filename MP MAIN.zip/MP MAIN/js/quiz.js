'use strict';

const Quiz = (function(){

  let bank = [];
  let screen = 'setup';
  let session = null;
  let selectedSubjects = null;
  let count = 10;
  let timerOn = false;
  let timerId = null;
  let bound = false;
  let onlyMine = false;
  let customFilter = 'all';
  let editingIndex = null;
  let managerOpen = false;

  const container = () => $('#practice-quiz');

  function isQuestion(q){
    return !!q && typeof q.q === 'string' && q.q.trim() &&
      Array.isArray(q.options) && q.options.length === 4 &&
      q.options.every(o => typeof o === 'string' && o.trim()) &&
      Number.isInteger(q.answer) && q.answer >= 0 && q.answer < 4 &&
      typeof q.subject === 'string' && q.subject.trim();
  }

  function cleanQuestion(q){
    return {
      q: String(q.q),
      options: q.options.map(String),
      answer: Number(q.answer),
      subject: String(q.subject),
      explain: q.explain ? String(q.explain) : ''
    };
  }

  function addBank(list){
    if(!Array.isArray(list)) return;
    list.forEach(q => { if(isQuestion(q)) bank.push(cleanQuestion(q)); });
  }

  function customEntries(){
    const list = Store.get('quizcustom', []);
    if(!Array.isArray(list)) return [];
    const out = [];
    list.forEach((q, index) => {
      if(isQuestion(q)) out.push({ q: cleanQuestion(q), index });
    });
    return out;
  }

  function customQuestions(){
    return customEntries().map(entry => entry.q);
  }

  function allQuestions(){
    return bank.concat(customQuestions());
  }

  function poolQuestions(){
    return onlyMine ? customQuestions() : allQuestions();
  }

  function subjectsFor(list){
    const set = new Set(list.map(q => q.subject));
    return SUBJECTS.filter(s => set.has(s)).concat(Array.from(set).filter(s => !SUBJECTS.includes(s)).sort());
  }

  function subjects(){
    return subjectsFor(poolQuestions());
  }

  function recentAttempts(){
    const list = Store.get('quizzes', []);
    if(!Array.isArray(list)) return [];
    return list.filter(a => {
      if(!a || typeof a.subject !== 'string') return false;
      const total = Number(a.total), correct = Number(a.correct);
      return Number.isFinite(total) && total > 0 && Number.isFinite(correct);
    }).slice(-10).reverse();
  }

  function managerIsOpen(){
    const box = container();
    const details = box ? $('[data-quiz-manager]', box) : null;
    return !!(details && details.open);
  }

  function ensureSelected(){
    const list = subjects();
    if(!list.length){ selectedSubjects = []; return; }
    if(!Array.isArray(selectedSubjects) || !selectedSubjects.length){
      selectedSubjects = list.slice();
      return;
    }
    selectedSubjects = selectedSubjects.filter(s => list.includes(s));
    if(!selectedSubjects.length) selectedSubjects = list.slice();
  }

  function shuffle(list){
    const a = list.slice();
    for(let i = a.length - 1; i > 0; i--){
      const j = Math.floor(Math.random() * (i + 1));
      const t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }

  function shuffleQuestion(q){
    const order = shuffle(q.options.map((_, i) => i));
    return Object.assign({}, q, {
      options: order.map(i => q.options[i]),
      answer: order.indexOf(q.answer)
    });
  }

  function clearTimer(){
    if(timerId){ clearInterval(timerId); timerId = null; }
  }

  function updateTimer(sec){
    const t = $('#quiz-timer');
    if(!t) return;
    t.textContent = fmtClock(sec);
    t.classList.toggle('low', sec <= 5);
  }

  function startTimer(){
    if(!session || !session.timerOn || timerId) return;
    if(session.remaining == null) session.remaining = 30;
    updateTimer(session.remaining);
    timerId = setInterval(() => {
      if(screen !== 'question' || !session) return;
      const box = container();
      if(!box || box.offsetParent === null) return;
      session.remaining -= 1;
      updateTimer(session.remaining);
      if(session.remaining <= 0){
        clearTimer();
        submitCurrent();
      }
    }, 1000);
  }

  function bind(){
    const box = container();
    if(!box || bound) return;
    bound = true;
    box.addEventListener('click', handleClick);
    box.addEventListener('submit', handleSubmit);
    box.addEventListener('change', handleChange);
  }

  function handleClick(e){
    const box = container();
    if(!box) return;

    const subjectBtn = e.target.closest('[data-quiz-subject]');
    if(subjectBtn){
      const s = subjectBtn.dataset.quizSubject;
      if(selectedSubjects.includes(s)){
        if(selectedSubjects.length === 1){ toast('Keep at least one subject selected', 'warn'); return; }
        selectedSubjects = selectedSubjects.filter(x => x !== s);
      }else{
        selectedSubjects.push(s);
      }
      $$('.chip[data-quiz-subject]', box).forEach(b => {
        const on = selectedSubjects.includes(b.dataset.quizSubject);
        b.classList.toggle('active', on);
        b.setAttribute('aria-pressed', String(on));
      });
      return;
    }

    if(e.target.closest('[data-quiz-only-mine]')){
      managerOpen = managerIsOpen();
      onlyMine = !onlyMine;
      ensureSelected();
      renderSetup();
      return;
    }

    const countBtn = e.target.closest('[data-quiz-count]');
    if(countBtn){
      const n = parseInt(countBtn.dataset.quizCount, 10);
      if([5, 10, 20].includes(n)){
        count = n;
        $$('[data-quiz-count]', box).forEach(b => b.classList.toggle('active', parseInt(b.dataset.quizCount, 10) === n));
      }
      return;
    }

    const timerBtn = e.target.closest('[data-quiz-timer]');
    if(timerBtn){
      timerOn = !timerOn;
      timerBtn.classList.toggle('on', timerOn);
      timerBtn.setAttribute('aria-pressed', String(timerOn));
      return;
    }

    const customFilterBtn = e.target.closest('[data-quiz-custom-filter]');
    if(customFilterBtn){
      customFilter = customFilterBtn.dataset.quizCustomFilter;
      managerOpen = true;
      renderSetup();
      return;
    }

    const editBtn = e.target.closest('[data-quiz-edit]');
    if(editBtn){
      editingIndex = Number(editBtn.dataset.quizEdit);
      managerOpen = managerIsOpen();
      renderSetup();
      const add = $('[data-quiz-add]', box);
      if(add){
        add.open = true;
        const input = $('input[name="q"]', add);
        if(input) input.focus();
      }
      return;
    }

    const deleteBtn = e.target.closest('[data-quiz-delete]');
    if(deleteBtn){
      deleteCustom(Number(deleteBtn.dataset.quizDelete));
      return;
    }

    if(e.target.closest('[data-quiz-cancel-edit]')){
      editingIndex = null;
      renderSetup();
      return;
    }

    if(e.target.closest('[data-quiz-export]')){ exportCustom(); return; }

    if(e.target.closest('[data-quiz-import-btn]')){
      const input = $('[data-quiz-import]', box);
      if(input) input.click();
      return;
    }

    if(e.target.closest('[data-quiz-clear-history]')){ clearHistory(); return; }

    if(e.target.closest('[data-quiz-start]')){ startQuiz(); return; }

    const opt = e.target.closest('[data-quiz-opt]');
    if(opt){
      if(!session || screen !== 'question') return;
      const i = Number(opt.dataset.quizOpt);
      session.currentSelection = i;
      $$('.quiz-opt', box).forEach(b => {
        const on = Number(b.dataset.quizOpt) === i;
        b.classList.toggle('selected', on);
        b.setAttribute('aria-pressed', String(on));
      });
      const next = $('[data-quiz-next]', box);
      if(next) next.disabled = false;
      return;
    }

    if(e.target.closest('[data-quiz-next]')){ submitCurrent(); return; }

    if(e.target.closest('[data-quiz-retry]')){ startQuiz(); return; }

    if(e.target.closest('[data-quiz-new]')){
      clearTimer();
      screen = 'setup';
      session = null;
      renderSetup();
    }
  }

  function handleSubmit(e){
    const form = e.target.closest('[data-quiz-add-form]');
    if(!form) return;
    e.preventDefault();
    addCustom(form);
  }

  function handleChange(e){
    const input = e.target.closest('[data-quiz-import]');
    if(!input) return;
    const file = input.files && input.files[0];
    if(!file) return;
    const reader = new FileReader();
    reader.onload = () => { importCustom(reader.result); input.value = ''; };
    reader.onerror = () => { toast('Could not read that file', 'error'); input.value = ''; };
    reader.readAsText(file);
  }

  function importCustom(text){
    let parsed;
    try{
      parsed = JSON.parse(String(text).replace(/^\uFEFF/, ''));
    }catch(e){
      toast('That file is not valid JSON', 'error');
      return;
    }

    const items = Array.isArray(parsed) ? parsed : (parsed && Array.isArray(parsed.questions) ? parsed.questions : null);
    if(!items){ toast('JSON must be a list of questions', 'warn'); return; }
    if(!items.length){ toast('That file has no questions', 'warn'); return; }

    const raw = Store.get('quizcustom', []);
    const custom = Array.isArray(raw) ? raw : [];
    const imported = [];
    let skipped = 0;

    items.forEach(item => {
      if(!isQuestion(item)){ skipped += 1; return; }
      const clean = {
        q: String(item.q).trim(),
        options: item.options.map(o => String(o).trim()),
        answer: Number(item.answer),
        subject: String(item.subject).trim(),
        explain: item.explain ? String(item.explain).trim() : ''
      };
      if(!isQuestion(clean)){ skipped += 1; return; }
      custom.push(clean);
      imported.push(clean);
    });

    if(imported.length) Store.set('quizcustom', custom);

    if(!Array.isArray(selectedSubjects)) selectedSubjects = [];
    imported.forEach(item => {
      if(!selectedSubjects.includes(item.subject)) selectedSubjects.push(item.subject);
    });

    managerOpen = true;
    customFilter = 'all';
    renderSetup();
    toast('Imported ' + imported.length + ' question' + (imported.length === 1 ? '' : 's') +
      (skipped ? ', skipped ' + skipped : ''), imported.length ? 'success' : 'warn');
  }

  function exportCustom(){
    const list = customQuestions();
    if(!list.length){ toast('No custom questions to export', 'warn'); return; }
    const blob = new Blob([JSON.stringify(list, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'focusflow-my-questions.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast('Exported ' + list.length + ' question' + (list.length === 1 ? '' : 's'), 'success');
  }

  function deleteCustom(index){
    const raw = Store.get('quizcustom', []);
    const list = Array.isArray(raw) ? raw : [];
    if(!Number.isInteger(index) || index < 0 || index >= list.length) return;
    list.splice(index, 1);
    Store.set('quizcustom', list);
    if(editingIndex === index) editingIndex = null;
    else if(editingIndex != null && editingIndex > index) editingIndex -= 1;
    managerOpen = managerIsOpen();
    toast('Question deleted', 'success');
    renderSetup();
  }

  function clearHistory(){
    if(!recentAttempts().length){ toast('No quiz history to clear', 'warn'); return; }
    Store.set('quizzes', []);
    managerOpen = managerIsOpen();
    toast('Quiz history cleared', 'success');
    renderSetup();
  }

  function addCustom(form){
    const data = new FormData(form);
    const q = String(data.get('q') || '').trim();
    const options = [0, 1, 2, 3].map(i => String(data.get('option' + i) || '').trim());
    const answer = parseInt(String(data.get('answer')), 10);
    const subject = String(data.get('subject') || '').trim();
    const explain = String(data.get('explain') || '').trim();

    if(!q || options.some(o => !o) || !subject || !explain){
      toast('Fill in every field to save your question', 'warn');
      return;
    }
    if(!Number.isInteger(answer) || answer < 0 || answer > 3){
      toast('Choose a valid correct option', 'warn');
      return;
    }

    const list = Store.get('quizcustom', []);
    const custom = Array.isArray(list) ? list : [];
    const item = { q, options, answer, subject, explain };
    const editing = Number.isInteger(editingIndex) && editingIndex >= 0 && editingIndex < custom.length;

    if(editing){
      custom[editingIndex] = item;
      Store.set('quizcustom', custom);
      toast('Your question was updated', 'success');
    }else{
      custom.push(item);
      Store.set('quizcustom', custom);
      toast('Your question was added', 'success');
    }
    editingIndex = null;
    managerOpen = managerIsOpen();

    if(!Array.isArray(selectedSubjects)) selectedSubjects = [];
    if(!selectedSubjects.includes(subject)) selectedSubjects.push(subject);

    renderSetup();
  }

  function renderSetup(){
    screen = 'setup';
    clearTimer();
    const box = container();
    if(!box) return;

    const all = allQuestions();
    const customList = customEntries();
    ensureSelected();
    const total = poolQuestions().length;
    const subs = subjects();

    let editEntry = null;
    if(editingIndex != null){
      editEntry = customList.find(entry => entry.index === editingIndex) || null;
      if(!editEntry) editingIndex = null;
    }
    const edit = editEntry ? editEntry.q : null;
    const formData = edit || { q: '', options: ['', '', '', ''], answer: 0, subject: '', explain: '' };

    const subjectChips = subs.map(s => {
      const on = selectedSubjects.includes(s);
      return '<button class="chip' + (on ? ' active' : '') + '" data-quiz-subject="' + escapeHTML(s) +
        '" type="button" aria-pressed="' + on + '">' + escapeHTML(s) + '</button>';
    }).join('');

    const countChips = [5, 10, 20].map(n =>
      '<button class="chip' + (count === n ? ' active' : '') + '" data-quiz-count="' + n +
      '" type="button">' + n + '</button>'
    ).join('');

    const datalist = subjectsFor(all).map(s => '<option value="' + escapeHTML(s) + '"></option>').join('');
    const onlyMineChip = '<button class="chip' + (onlyMine ? ' active' : '') +
      '" data-quiz-only-mine type="button" aria-pressed="' + onlyMine + '"><i class="fa-solid fa-user"></i>' +
      'Only my questions (' + customList.length + ')</button>';

    const answerOptions = [0, 1, 2, 3].map(i =>
      '<option value="' + i + '"' + (Number(formData.answer) === i ? ' selected' : '') + '>Option ' + (i + 1) + '</option>'
    ).join('');

    const addPanel = '<details class="quiz-add"' + (edit ? ' open' : '') + ' data-quiz-add>' +
      '<summary><i class="fa-solid fa-' + (edit ? 'pen' : 'plus') + '"></i>' +
        (edit ? 'Edit my question' : 'Add my own question') + '</summary>' +
      '<form class="card pad quiz-add-body" data-quiz-add-form>' +
        '<div class="quiz-form-grid">' +
          '<label class="quiz-field wide"><span class="label">Question</span>' +
            '<input type="text" name="q" maxlength="240" autocomplete="off" value="' + escapeHTML(formData.q) + '" required></label>' +
          '<label class="quiz-field"><span class="label">Option 1</span>' +
            '<input type="text" name="option0" maxlength="120" autocomplete="off" value="' + escapeHTML(formData.options[0]) + '" required></label>' +
          '<label class="quiz-field"><span class="label">Option 2</span>' +
            '<input type="text" name="option1" maxlength="120" autocomplete="off" value="' + escapeHTML(formData.options[1]) + '" required></label>' +
          '<label class="quiz-field"><span class="label">Option 3</span>' +
            '<input type="text" name="option2" maxlength="120" autocomplete="off" value="' + escapeHTML(formData.options[2]) + '" required></label>' +
          '<label class="quiz-field"><span class="label">Option 4</span>' +
            '<input type="text" name="option3" maxlength="120" autocomplete="off" value="' + escapeHTML(formData.options[3]) + '" required></label>' +
          '<label class="quiz-field"><span class="label">Correct option</span>' +
            '<select name="answer">' + answerOptions + '</select></label>' +
          '<label class="quiz-field"><span class="label">Subject</span>' +
            '<input type="text" name="subject" list="quiz-subject-options" maxlength="24" autocomplete="off" value="' +
              escapeHTML(formData.subject) + '" required></label>' +
          '<label class="quiz-field wide"><span class="label">Explanation</span>' +
            '<input type="text" name="explain" maxlength="240" autocomplete="off" value="' +
              escapeHTML(formData.explain) + '" required></label>' +
        '</div>' +
        '<datalist id="quiz-subject-options">' + datalist + '</datalist>' +
        '<div class="quiz-form-actions">' +
          (edit ? '<button class="btn btn-ghost" data-quiz-cancel-edit type="button">' +
            '<i class="fa-solid fa-xmark"></i>Cancel</button>' : '') +
          '<button class="btn btn-primary" type="submit"><i class="fa-solid fa-floppy-disk"></i>' +
            (edit ? 'Update question' : 'Save question') + '</button>' +
        '</div>' +
      '</form>' +
    '</details>';

    const customSubjects = subjectsFor(customList.map(entry => entry.q));
    if(customFilter !== 'all' && !customSubjects.includes(customFilter)) customFilter = 'all';
    const filteredCustom = customFilter === 'all'
      ? customList
      : customList.filter(entry => entry.q.subject === customFilter);

    const customChips = ['all'].concat(customSubjects).map(s => {
      const on = customFilter === s;
      return '<button class="chip' + (on ? ' active' : '') + '" data-quiz-custom-filter="' + escapeHTML(s) +
        '" type="button" aria-pressed="' + on + '">' + (s === 'all' ? 'All' : escapeHTML(s)) + '</button>';
    }).join('');

    let customRows;
    if(!customList.length){
      customRows = '<div class="empty"><i class="fa-solid fa-list-check"></i>' +
        '<p>No custom questions yet. Add one above or import a JSON file.</p></div>';
    }else if(!filteredCustom.length){
      customRows = '<div class="empty"><i class="fa-solid fa-filter"></i>' +
        '<p>No questions in this subject.</p></div>';
    }else{
      customRows = filteredCustom.map(entry => {
        const item = entry.q;
        return '<div class="quiz-manage-row">' +
          '<div class="quiz-manage-main">' +
            '<p class="quiz-manage-q">' + escapeHTML(item.q) + '</p>' +
            '<p class="quiz-manage-meta"><span class="subj-chip">' + escapeHTML(item.subject) + '</span>' +
              '<span class="quiz-ans">Answer: <b>' + escapeHTML(item.options[item.answer]) + '</b></span></p>' +
          '</div>' +
          '<div class="quiz-manage-actions">' +
            '<button class="icon-btn small" data-quiz-edit="' + entry.index +
              '" type="button" title="Edit question" aria-label="Edit question"><i class="fa-solid fa-pen"></i></button>' +
            '<button class="icon-btn small danger" data-quiz-delete="' + entry.index +
              '" type="button" title="Delete question" aria-label="Delete question"><i class="fa-solid fa-trash"></i></button>' +
          '</div>' +
        '</div>';
      }).join('');
    }

    const managerPanel = '<details class="quiz-add quiz-manager"' + (managerOpen ? ' open' : '') +
      ' data-quiz-manager>' +
      '<summary><i class="fa-solid fa-list-check"></i>My questions <span class="sub mono">' +
        customList.length + '</span></summary>' +
      '<div class="card pad quiz-manager-body">' +
        '<div class="rail-head"><p class="label">My questions</p><span class="sub mono">' +
          customList.length + ' saved</span></div>' +
        (customList.length ? '<div class="chip-row">' + customChips + '</div>' : '') +
        '<div class="quiz-manage-list">' + customRows + '</div>' +
        '<div class="quiz-manager-tools">' +
          '<button class="btn btn-ghost" data-quiz-export type="button">' +
            '<i class="fa-solid fa-download"></i>Export JSON</button>' +
          '<button class="btn btn-ghost" data-quiz-import-btn type="button">' +
            '<i class="fa-solid fa-upload"></i>Import JSON</button>' +
          '<input type="file" accept=".json,application/json" data-quiz-import hidden>' +
        '</div>' +
      '</div>' +
    '</details>';

    const attempts = recentAttempts();
    const attemptRows = attempts.length ? attempts.map(a => {
      const correct = Number(a.correct), attemptTotal = Number(a.total);
      const date = typeof a.date === 'string' && a.date.trim()
        ? a.date
        : (Number.isFinite(Number(a.at)) ? new Date(Number(a.at)).toLocaleDateString() : '');
      return '<div class="log-row">' +
        '<span class="subj-chip">' + escapeHTML(a.subject) + '</span>' +
        '<span class="mode"><i class="fa-regular fa-calendar"></i>' + escapeHTML(date) + '</span>' +
        '<span class="dur">' + correct + '/' + attemptTotal + '</span>' +
      '</div>';
    }).join('') : '<div class="empty"><i class="fa-solid fa-clock"></i>' +
      '<p>No attempts yet. Finish a quiz to see it here.</p></div>';

    const historyPanel = '<div class="card pad quiz-history">' +
      '<div class="rail-head"><p class="label">Recent attempts</p><span class="sub mono">' +
        (attempts.length ? 'Last ' + attempts.length : 'Last 10') + '</span></div>' +
      '<div class="quiz-history-list">' + attemptRows + '</div>' +
      (attempts.length
        ? '<div class="quiz-actions"><button class="btn btn-ghost quiz-clear" data-quiz-clear-history type="button">' +
          '<i class="fa-solid fa-trash"></i>Clear history</button></div>'
        : '') +
    '</div>';

    box.innerHTML = '<div class="quiz-shell">' +
      '<div class="card pad">' +
        '<div class="rail-head"><p class="label">Subjects</p><span class="sub mono">' +
          total + ' question' + (total === 1 ? '' : 's') + ' available</span></div>' +
        (subs.length
          ? '<div class="chip-row">' + subjectChips + '</div>'
          : '<div class="empty"><i class="fa-solid fa-book"></i><p>' +
            (onlyMine ? 'No custom questions yet — add one below or turn off Only my questions' :
              'No subjects yet — add a question below to get started') + '</p></div>') +
        '<p class="label" style="margin-top:20px">Source</p>' +
        '<div class="chip-row">' + onlyMineChip + '</div>' +
        '<p class="label" style="margin-top:12px">Questions per quiz</p>' +
        '<div class="chip-row">' + countChips + '</div>' +
        '<div class="quiz-toggle-row">' +
          '<div><p class="gt-title"><i class="fa-solid fa-clock"></i>30-second timer</p>' +
          '<p class="gt-desc">Give each question 30 seconds. Timeouts count as wrong answers.</p></div>' +
          '<button class="ch-toggle' + (timerOn ? ' on' : '') + '" data-quiz-timer type="button" aria-pressed="' +
            timerOn + '" aria-label="Toggle quiz timer"></button>' +
        '</div>' +
        '<button class="btn btn-primary btn-block quiz-start" data-quiz-start type="button"' +
          (total ? '' : ' disabled') + '><i class="fa-solid fa-play"></i>Start quiz</button>' +
      '</div>' +
      '<div class="quiz-tools">' + addPanel + managerPanel + '</div>' +
      historyPanel +
    '</div>';
  }

  function startQuiz(){
    ensureSelected();
    const pool = poolQuestions().filter(q => selectedSubjects.includes(q.subject));
    if(!pool.length){ toast('No questions available for those subjects', 'warn'); return; }

    const total = Math.min(count, pool.length);
    const questions = shuffle(pool).slice(0, total).map(shuffleQuestion);
    session = {
      questions,
      index: 0,
      answers: new Array(total).fill(null),
      currentSelection: null,
      remaining: null,
      timerOn,
      saved: false
    };
    screen = 'question';
    renderQuestion();
  }

  function renderQuestion(){
    if(!session){ renderSetup(); return; }
    screen = 'question';
    clearTimer();
    const box = container();
    if(!box) return;

    const q = session.questions[session.index];
    const total = session.questions.length;
    const pct = Math.round((session.index / total) * 100);
    const timer = session.timerOn
      ? '<span class="mono quiz-timer' + (session.remaining != null && session.remaining <= 5 ? ' low' : '') +
        '" id="quiz-timer">' + fmtClock(session.remaining != null ? session.remaining : 30) + '</span>'
      : '';

    const options = q.options.map((o, i) => {
      const on = session.currentSelection === i;
      return '<button class="btn btn-ghost quiz-opt' + (on ? ' selected' : '') + '" data-quiz-opt="' + i +
        '" type="button" aria-pressed="' + on + '"><span class="opt-key">' + 'ABCD'[i] + '</span><span>' +
        escapeHTML(o) + '</span></button>';
    }).join('');

    box.innerHTML = '<div class="quiz-shell"><div class="card pad">' +
      '<div class="quiz-progress">' +
        '<div class="rail-head"><span class="label">Question ' + (session.index + 1) + ' of ' + total +
          ' · ' + escapeHTML(q.subject) + '</span>' + timer + '</div>' +
        '<span class="task-progress"><i style="width:' + pct + '%"></i></span>' +
      '</div>' +
      '<p class="quiz-question">' + escapeHTML(q.q) + '</p>' +
      '<div class="quiz-options">' + options + '</div>' +
      '<div class="quiz-actions"><button class="btn btn-primary" data-quiz-next type="button"' +
        (session.currentSelection == null ? ' disabled' : '') + '><i class="fa-solid fa-arrow-right"></i>Next</button></div>' +
    '</div></div>';

    startTimer();
  }

  function submitCurrent(){
    if(!session || screen !== 'question') return;
    clearTimer();
    session.answers[session.index] = session.currentSelection;
    session.index += 1;
    session.currentSelection = null;
    session.remaining = null;

    if(session.index >= session.questions.length){
      finishQuiz();
      return;
    }
    renderQuestion();
  }

  function finishQuiz(){
    clearTimer();
    if(!session) return;
    if(!session.saved){
      const total = session.questions.length;
      const correct = session.questions.reduce((n, q, i) => n + (session.answers[i] === q.answer ? 1 : 0), 0);
      const attempts = Store.get('quizzes', []);
      const list = Array.isArray(attempts) ? attempts : [];
      list.push({
        date: dateKey(),
        subject: selectedSubjects.length === 1 ? selectedSubjects[0] : 'Mixed',
        total,
        correct,
        at: Date.now()
      });
      Store.set('quizzes', list);
      session.saved = true;
    }
    screen = 'result';
    renderResult();
  }

  function renderResult(){
    if(!session){ renderSetup(); return; }
    screen = 'result';
    clearTimer();
    const box = container();
    if(!box) return;

    const questions = session.questions;
    const answers = session.answers;
    const total = questions.length;
    const correct = questions.reduce((n, q, i) => n + (answers[i] === q.answer ? 1 : 0), 0);
    const accuracy = total ? Math.round(correct / total * 100) : 0;

    const bySubject = new Map();
    questions.forEach((q, i) => {
      const row = bySubject.get(q.subject) || { total: 0, correct: 0 };
      row.total += 1;
      if(answers[i] === q.answer) row.correct += 1;
      bySubject.set(q.subject, row);
    });

    const subjectRows = Array.from(bySubject.entries()).map(([name, row]) => {
      const pct = Math.round(row.correct / row.total * 100);
      return '<div class="subject-row"><span class="name">' + escapeHTML(name) +
        '</span><span class="track"><i class="fill" style="width:' + pct + '%;background:' + hueFor(name) +
        '"></i></span><span class="val">' + pct + '%</span></div>';
    }).join('');

    const wrong = [];
    questions.forEach((q, i) => {
      if(answers[i] !== q.answer) wrong.push({ q, given: answers[i] });
    });

    const review = wrong.length ? wrong.map(item => {
      const given = item.given == null
        ? '<b class="warn">No answer</b>'
        : '<b class="danger">' + escapeHTML(item.q.options[item.given]) + '</b>';
      return '<div class="quiz-review-item"><p class="rq">' + escapeHTML(item.q.q) + '</p>' +
        '<p class="ra">Your answer: ' + given + '</p>' +
        '<p class="ra">Correct answer: <b class="ok">' + escapeHTML(item.q.options[item.q.answer]) + '</b></p>' +
        (item.q.explain ? '<p class="ra">' + escapeHTML(item.q.explain) + '</p>' : '') +
      '</div>';
    }).join('') : '<div class="empty"><i class="fa-solid fa-circle-check"></i><p>No wrong answers — perfect score!</p></div>';

    const subjectLabel = selectedSubjects.length === 1 ? selectedSubjects[0] : 'Mixed subjects';

    box.innerHTML = '<div class="quiz-shell">' +
      '<div class="card pad">' +
        '<div class="rail-head"><p class="label">Quiz result</p><span class="sub mono">' +
          escapeHTML(subjectLabel) + '</span></div>' +
        '<div class="quiz-result-head">' +
          '<div><p class="label">Score</p><p class="mono grad-text quiz-result-val">' + correct + '/' + total + '</p></div>' +
          '<div><p class="label">Accuracy</p><p class="mono quiz-result-val">' + accuracy + '%</p></div>' +
        '</div>' +
        '<div class="quiz-acc"><p class="label">By subject</p><div class="quiz-acc-list">' + subjectRows + '</div></div>' +
        '<div class="quiz-actions">' +
          '<button class="btn btn-ghost" data-quiz-new type="button"><i class="fa-solid fa-rotate-left"></i>New quiz</button>' +
          '<button class="btn btn-primary" data-quiz-retry type="button"><i class="fa-solid fa-redo"></i>Retry</button>' +
        '</div>' +
      '</div>' +
      '<div class="card pad">' +
        '<div class="rail-head"><p class="label">Review</p><span class="sub mono">' +
          wrong.length + ' to review</span></div>' +
        '<div class="quiz-review">' + review + '</div>' +
      '</div>' +
    '</div>';
  }

  function onShow(){
    bind();
    if(screen === 'question' && session){ renderQuestion(); return; }
    if(screen === 'result' && session){ renderResult(); return; }
    renderSetup();
  }

  return { addBank, onShow };
})();
window.Quiz = Quiz;
