'use strict';

Quiz.addBank([
  {
    q: 'What is the value of 7 × 8?',
    options: ['54', '56', '48', '64'],
    answer: 1,
    subject: 'Mathematics',
    explain: '7 × 8 = 56.'
  },
  {
    q: 'Solve for x: 2x + 5 = 17.',
    options: ['4', '6', '7', '11'],
    answer: 1,
    subject: 'Mathematics',
    explain: 'Subtract 5 from both sides to get 2x = 12, then divide by 2 to get x = 6.'
  },
  {
    q: 'What is the area of a circle with radius 5? Use π ≈ 3.14.',
    options: ['31.4', '78.5', '25', '15.7'],
    answer: 1,
    subject: 'Mathematics',
    explain: 'Area = πr² = 3.14 × 5² = 3.14 × 25 = 78.5.'
  },
  {
    q: 'What is the square root of 144?',
    options: ['10', '12', '14', '16'],
    answer: 1,
    subject: 'Mathematics',
    explain: '12 × 12 = 144, so the square root is 12.'
  },
  {
    q: 'What is the sum of the interior angles of a triangle?',
    options: ['90°', '180°', '270°', '360°'],
    answer: 1,
    subject: 'Mathematics',
    explain: 'The three interior angles of any triangle always add up to 180°.'
  },
  {
    q: 'What is 15% of 200?',
    options: ['15', '30', '45', '20'],
    answer: 1,
    subject: 'Mathematics',
    explain: '15% of 200 = 0.15 × 200 = 30.'
  },
  {
    q: 'What is the slope of the line y = 3x - 4?',
    options: ['-4', '3', '4', '-3'],
    answer: 1,
    subject: 'Mathematics',
    explain: 'In y = mx + c, the coefficient of x is the slope, so the slope is 3.'
  },
  {
    q: 'What is the highest common factor of 12 and 18?',
    options: ['2', '6', '12', '36'],
    answer: 1,
    subject: 'Mathematics',
    explain: 'The factors common to 12 and 18 include 1, 2, 3, and 6. The highest is 6.'
  },
  {
    q: 'What is the value of 5! (5 factorial)?',
    options: ['20', '60', '120', '25'],
    answer: 2,
    subject: 'Mathematics',
    explain: '5! = 5 × 4 × 3 × 2 × 1 = 120.'
  },
  {
    q: 'A fair die is rolled. What is the probability of getting an even number?',
    options: ['1/6', '1/3', '1/2', '2/3'],
    answer: 2,
    subject: 'Mathematics',
    explain: 'The even outcomes are 2, 4, and 6, so the probability is 3/6 = 1/2.'
  },
  {
    q: 'What is the SI unit of force?',
    options: ['Joule', 'Newton', 'Watt', 'Pascal'],
    answer: 1,
    subject: 'Physics',
    explain: 'Force is measured in newtons (N), named after Isaac Newton.'
  },
  {
    q: 'What is the approximate speed of light in a vacuum?',
    options: ['3 × 10^8 m/s', '3 × 10^6 m/s', '3 × 10^10 m/s', '3 × 10^5 m/s'],
    answer: 0,
    subject: 'Physics',
    explain: 'Light travels at approximately 3 × 10^8 metres per second in a vacuum.'
  },
  {
    q: 'What is the acceleration due to gravity on Earth near the surface?',
    options: ['9.8 m/s²', '1.6 m/s²', '3.7 m/s²', '19.6 m/s²'],
    answer: 0,
    subject: 'Physics',
    explain: 'Near Earth\'s surface, gravitational acceleration is about 9.8 m/s².'
  },
  {
    q: 'Which of these is a scalar quantity?',
    options: ['Velocity', 'Displacement', 'Speed', 'Acceleration'],
    answer: 2,
    subject: 'Physics',
    explain: 'Speed has magnitude but no direction, so it is a scalar quantity.'
  },
  {
    q: 'Newton\'s first law of motion is also known as the law of what?',
    options: ['Motion', 'Inertia', 'Action-reaction', 'Gravitation'],
    answer: 1,
    subject: 'Physics',
    explain: 'Newton\'s first law describes inertia: an object stays at rest or in uniform motion unless acted on by a force.'
  },
  {
    q: 'What is the SI unit of electric current?',
    options: ['Volt', 'Ohm', 'Ampere', 'Coulomb'],
    answer: 2,
    subject: 'Physics',
    explain: 'Electric current is measured in amperes (A).'
  },
  {
    q: 'How much work is done when a force acts perpendicular to displacement?',
    options: ['Maximum', 'Zero', 'Negative', 'Equal to force'],
    answer: 1,
    subject: 'Physics',
    explain: 'Work = force × displacement × cos θ. For θ = 90°, cos 90° = 0, so the work done is zero.'
  },
  {
    q: 'Which formula gives kinetic energy?',
    options: ['mv²', '½mv²', 'mgh', 'Fd'],
    answer: 1,
    subject: 'Physics',
    explain: 'Kinetic energy is KE = ½mv², where m is mass and v is speed.'
  },
  {
    q: 'Which device converts electrical energy into mechanical energy?',
    options: ['Generator', 'Motor', 'Transformer', 'Battery'],
    answer: 1,
    subject: 'Physics',
    explain: 'An electric motor converts electrical energy into mechanical energy.'
  },
  {
    q: 'Sound cannot travel through which medium?',
    options: ['Solid', 'Liquid', 'Gas', 'Vacuum'],
    answer: 3,
    subject: 'Physics',
    explain: 'Sound needs a material medium to travel. A vacuum has no particles, so sound cannot travel through it.'
  },
  {
    q: 'What is the chemical symbol for gold?',
    options: ['Ag', 'Au', 'Fe', 'Cu'],
    answer: 1,
    subject: 'Chemistry',
    explain: 'Gold\'s symbol is Au, from the Latin word aurum.'
  },
  {
    q: 'What is the atomic number of carbon?',
    options: ['6', '8', '12', '14'],
    answer: 0,
    subject: 'Chemistry',
    explain: 'Carbon has 6 protons in its nucleus, so its atomic number is 6.'
  },
  {
    q: 'What is the pH of a neutral solution at 25°C?',
    options: ['0', '7', '14', '1'],
    answer: 1,
    subject: 'Chemistry',
    explain: 'A neutral solution at 25°C has a pH of 7.'
  },
  {
    q: 'What is the chemical formula of water?',
    options: ['H2O2', 'HO2', 'H2O', 'OH'],
    answer: 2,
    subject: 'Chemistry',
    explain: 'Water consists of two hydrogen atoms bonded to one oxygen atom: H2O.'
  },
  {
    q: 'Which gas is essential for combustion?',
    options: ['Nitrogen', 'Oxygen', 'Carbon dioxide', 'Hydrogen'],
    answer: 1,
    subject: 'Chemistry',
    explain: 'Oxygen supports combustion and is required for most burning reactions.'
  },
  {
    q: 'Which gas is most abundant in Earth\'s atmosphere?',
    options: ['Oxygen', 'Nitrogen', 'Carbon dioxide', 'Argon'],
    answer: 1,
    subject: 'Chemistry',
    explain: 'Nitrogen makes up about 78% of Earth\'s atmosphere.'
  },
  {
    q: 'Which of these is a noble gas?',
    options: ['Sodium', 'Chlorine', 'Neon', 'Oxygen'],
    answer: 2,
    subject: 'Chemistry',
    explain: 'Neon is in group 18 of the periodic table, the noble gases.'
  },
  {
    q: 'How many hydrogen atoms are in one molecule of methane?',
    options: ['1', '2', '3', '4'],
    answer: 3,
    subject: 'Chemistry',
    explain: 'Methane has the formula CH4, so it contains four hydrogen atoms.'
  },
  {
    q: 'What is the chemical formula of table salt?',
    options: ['NaCl', 'KCl', 'CaCO3', 'NaOH'],
    answer: 0,
    subject: 'Chemistry',
    explain: 'Table salt is sodium chloride, NaCl.'
  },
  {
    q: 'What is the process called when a solid changes directly into a gas?',
    options: ['Evaporation', 'Sublimation', 'Condensation', 'Melting'],
    answer: 1,
    subject: 'Chemistry',
    explain: 'Sublimation is the direct change from solid to gas without passing through the liquid state.'
  }
]);
