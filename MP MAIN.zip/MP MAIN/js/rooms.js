/* rooms.js — study rooms, live leaderboard, chat and activity feed.
   Demo build: peers are simulated locally with real-time ticking timers. */
'use strict';

const Rooms = (function(){

  const NAMES = ['Aarav','Ishita','Kabir','Mira','Dev','Sana','Jun','Hana','Rio','Elena','Omar','Tara','Nikhil','Yuna','Advait','Zara'];
  const HUES  = ['#E8A33D','#4FB286','#5B9BD5','#C97B63','#A78BDB','#C9A227','#7FBFB0','#C86F8F'];
  const IDXP  = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

  const CHAT_LINES = [
    'anyone up for a 25 minute sprint?',
    'two more pomodoros and I am done for the day',
    'physics rotation questions are brutal today',
    'finally finished the chemistry assignment',
    'my brain is fried, taking a short break',
    'who else is still going? it is getting late',
    'history notes are taking forever',
    'back at it after dinner',
    'that chapter went by quicker than expected',
    'focus is dropping, someone motivate me',
    'just hit my daily goal, feels great',
    'coffee refill number three'
  ];
  const REPLIES = ['nice, keep going','same here honestly','you got this','agreed','let us grind','solid pace','true','good luck with that'];

  let current = null, range = 'today', rtab = 'chat';
  let feed = [], tickT = null, boardTimer = 0;

  const db = () => {
    const d = Store.get('rooms', {});
    let dirty = false;
    Object.keys(d).forEach(k => { if(safeCode(k) !== k){ delete d[k]; dirty = true; } });
    if(dirty) Store.set('rooms', d);
    return d;
  };

  function genCode(){
    let c = '';
    for(let i = 0; i < 6; i++) c += IDXP[Math.floor(Math.random() * IDXP.length)];
    return c;
  }
  function meMember(){
    const u = State.user || { name: 'You', hue: '#E8A33D' };
    return { id:'me', name:u.name, bot:false, hue:u.hue, level:1, todaySec:0, weekSec:0, studying:false, subject:'' };
  }
  function makeBots(n){
    const pool = [...NAMES].sort(() => Math.random() - 0.5).slice(0, n);
    return pool.map(name => {
      const today = Math.random() < 0.15 ? 0 : Math.floor(Math.random() * Math.random() * 170 + 5) * 60;
      return {
        id: 'b' + name + Math.floor(Math.random() * 999),
        name, bot: true, hue: HUES[Math.floor(Math.random() * HUES.length)],
        level: 1 + Math.floor(Math.random() * 16),
        todaySec: today,
        weekSec: today + Math.floor(Math.random() * 9 * 3600),
        studying: Math.random() < 0.65,
        subject: SUBJECTS[Math.floor(Math.random() * SUBJECTS.length)]
      };
    });
  }

  /* ---------- create / join / open / leave ---------- */

  function newRoom(code, name){
    const d = db();
    const room = {
      code, name: (name || 'Study Room').slice(0, 32), createdAt: Date.now(),
      members: [...makeBots(5 + Math.floor(Math.random() * 3)), meMember()],
      chat: []
    };
    seedChat(room);
    d[code] = room;
    Store.set('rooms', d);
    return room;
  }

  function create(name){
    const d = db();
    let code = genCode();
    while(d[code]) code = genCode();
    newRoom(code, name);
    if(window.Tracker) Tracker.checkBadges();
    toast('Room ready — share code ' + code, 'success');
    open(code);
  }

  function join(code){
    code = safeCode((code || '').toUpperCase().trim());
    if(!code){ toast('Room code must be 4-10 letters or numbers', 'warn'); return; }
    const d = db();
    if(!d[code]){
      newRoom(code, 'Room ' + code);
      if(window.Tracker) Tracker.checkBadges();
      toast('Room joined — ' + db()[code].name, 'success');
    }
    open(code);
  }

  function open(code){
    const d = db();
    if(!d[code]){ showList(); return; }
    const isNew = current !== code;
    current = code;
    if(isNew){
      feed = [];
      pushFeed('You joined ' + d[code].name, true);
      seedFeed(d[code]);
    }
    if(location.hash !== '#/rooms/' + code) location.hash = '#/rooms/' + code;
    renderRoom();
    startTick();
  }

  function leave(){
    if(!current) return;
    const d = db();
    delete d[current];
    Store.set('rooms', d);
    toast('You left the room', 'warn');
    current = null;
    stopTick();
    location.hash = '#/rooms';
    showList();
  }

  /* ---------- feed ---------- */

  function pushFeed(text, isMe = false, ts = Date.now()){
    feed.unshift({ text, me: isMe, ts });
    if(feed.length > 22) feed.pop();
  }
  function seedFeed(room){
    const bots = room.members.filter(m => m.bot);
    const acts = [
      m => m.name + ' is studying ' + m.subject,
      m => m.name + ' crossed ' + fmtDur(m.todaySec) + ' today',
      m => m.name + ' completed a pomodoro',
      m => m.name + ' took a short break'
    ];
    for(let i = 0; i < 4; i++){
      const m = bots[Math.floor(Math.random() * bots.length)];
      pushFeed(acts[Math.floor(Math.random() * acts.length)](m), false, Date.now() - Math.floor(Math.random() * 40 * 60000));
    }
  }
  function renderFeed(){
    const box = $('#feed-body'); if(!box) return;
    if(!feed.length){
      box.innerHTML = '<div class="empty"><i class="fa-solid fa-satellite-dish"></i><p>Activity will show up here</p></div>';
      return;
    }
    box.innerHTML = feed.map(f =>
      '<div class="feed-item ' + (f.me ? 'me' : '') + '">' +
        '<span class="fi-dot"></span><span>' + escapeHTML(f.text) + '</span>' +
        '<span class="ago">' + fmtAgo(f.ts) + '</span>' +
      '</div>').join('');
  }

  /* ---------- chat ---------- */

  function seedChat(room){
    const bots = room.members.filter(m => m.bot);
    if(!bots.length) return;
    const lines = ['welcome to ' + room.name, 'we usually run sprints on the hour', 'drop your daily goal when you settle in'];
    room.chat = lines.map((text, i) => {
      const m = bots[i % bots.length];
      return { me:false, name:m.name, hue:m.hue, text, ts: Date.now() - (lines.length - i) * 420000 };
    });
  }

  function addMsg(m, text){
    const d = db();
    const room = d[current];
    if(!room) return;
    room.chat = room.chat || [];
    room.chat.push(Object.assign({ text, ts: Date.now() }, m));
    if(room.chat.length > 80) room.chat = room.chat.slice(-80);
    Store.set('rooms', d);
    if(State.view === 'rooms' && current) renderChat();
  }

  function renderChat(){
    const body = $('#chat-body'); if(!body) return;
    const room = db()[current];
    const msgs = (room && room.chat) || [];
    const nearBottom = body.scrollHeight - body.scrollTop - body.clientHeight < 80;
    if(!msgs.length){
      body.innerHTML = '<div class="empty"><i class="fa-solid fa-comments"></i><p>Say hi to the room</p></div>';
      return;
    }
    body.innerHTML = msgs.map(m =>
      '<div class="msg' + (m.me ? ' me' : '') + '">' +
        '<span class="msg-av" style="background:' + safeColor(m.hue, '#F6B93B') + '">' + escapeHTML(String(m.name).charAt(0).toUpperCase()) + '</span>' +
        '<div class="msg-bub">' +
          '<span class="msg-name">' + escapeHTML(m.name) + ' · ' + fmtAgo(m.ts) + '</span>' +
          '<p>' + escapeHTML(m.text) + '</p>' +
        '</div>' +
      '</div>').join('');
    if(nearBottom) body.scrollTop = body.scrollHeight;
  }

  function setTab(tab){
    rtab = tab;
    $$('#rtab-seg .chip').forEach(c => c.classList.toggle('active', c.dataset.rtab === tab));
    const chat = $('#chat-body'), form = $('#chat-form'), fd = $('#feed-body');
    if(chat) chat.style.display = tab === 'chat' ? 'flex' : 'none';
    if(form) form.style.display = tab === 'chat' ? 'flex' : 'none';
    if(fd)   fd.style.display   = tab === 'feed' ? 'flex' : 'none';
  }

  /* ---------- leaderboard ---------- */

  function myLive(){
    let today = 0, week = 0;
    const keys = new Set();
    for(let i = 0; i < 7; i++){ const d = new Date(); d.setDate(d.getDate() - i); keys.add(dateKey(d)); }
    Store.get('sessions', []).forEach(s => {
      if(s.date === dateKey()) today += s.seconds;
      if(keys.has(s.date)) week += s.seconds;
    });
    if(window.Tracker){
      today = Tracker.todaySeconds();
      week += Tracker.liveSec();
    }
    const level = window.Tracker
      ? Tracker.levelInfo(Store.get('stats', { xp:0, badges:[] }).xp).level : 1;
    return {
      today, week, level,
      studying: !!(window.Tracker && Tracker.isActive()),
      subject: window.Tracker ? Tracker.activeSubject() : ''
    };
  }

  function buildRows(room){
    const mine = myLive();
    const rows = room.members.map(m => m.id === 'me'
      ? Object.assign({}, m, { todaySec:mine.today, weekSec:mine.week, level:mine.level, studying:mine.studying, subject:mine.subject })
      : m);
    rows.sort((a, b) => (range === 'today' ? b.todaySec - a.todaySec : b.weekSec - a.weekSec));
    return rows;
  }

  function renderBoard(){
    const box = $('#board-body'); if(!box) return;
    const room = db()[current]; if(!room) return;
    const rows = buildRows(room);

    /* FLIP — remember old positions, slide into new ones */
    const prev = new Map();
    $$('.member-row', box).forEach(r => prev.set(r.dataset.id, r.getBoundingClientRect().top));

    box.innerHTML = rows.map((m, i) => {
      const rank = i + 1;
      const rankCls = rank === 1 ? 'r1' : rank === 2 ? 'r2' : rank === 3 ? 'r3' : '';
      const time = range === 'today' ? m.todaySec : m.weekSec;
      const stat = m.studying
        ? '<span class="mstat live"><i class="fa-solid fa-circle"></i>' + escapeHTML(m.subject || 'studying') + '</span>'
        : '<span class="mstat">idle</span>';
      return '<div class="member-row ' + (m.id === 'me' ? 'me' : '') + '" data-member="' + escapeHTML(m.id) + '" title="View profile">' +
        '<span class="rank ' + rankCls + ' mono">' + (rank === 1 ? '<i class="fa-solid fa-crown crown"></i>' : '') + rank + '</span>' +
        '<span class="avatar" style="background:' + safeColor(m.hue, '#F6B93B') + '">' + escapeHTML(m.name.charAt(0).toUpperCase()) + '</span>' +
        '<span><span class="mname"><span>' + escapeHTML(m.name) + '</span>' +
          (m.id === 'me' ? '<span class="you-tag">YOU</span>' : '') + '</span>' +
          '<span class="mlv">Level ' + m.level + '</span></span>' +
        '<span class="mtime mono">' + fmtDur(time) + '</span>' +
        stat +
      '</div>';
    }).join('');

    $$('.member-row', box).forEach(r => {
      const before = prev.get(r.dataset.id);
      if(before == null) return;
      const delta = before - r.getBoundingClientRect().top;
      if(Math.abs(delta) < 2) return;
      r.style.transition = 'none';
      r.style.transform = 'translateY(' + delta + 'px)';
      requestAnimationFrame(() => requestAnimationFrame(() => {
        r.style.transition = 'transform .55s cubic-bezier(.22,1,.36,1)';
        r.style.transform = '';
      }));
    });
  }

  function renderRoom(){
    const room = db()[current];
    const view = $('#room-view'), landing = $('#rooms-landing');
    if(!room){ showList(); return; }
    if(landing) landing.style.display = 'none';
    if(view) view.style.display = 'block';
    $('#room-name-label').textContent = room.name;
    $('#room-code-label').textContent = room.code;
    renderBoard(); renderFeed(); renderChat(); setTab(rtab);
  }

  function showList(){
    const view = $('#room-view'), landing = $('#rooms-landing');
    if(view) view.style.display = 'none';
    if(landing) landing.style.display = 'block';
    renderList();
    stopTick();
  }

  function renderList(){
    const box = $('#rooms-list'); if(!box) return;
    const d = db();
    const codes = Object.keys(d);
    if(!codes.length){
      box.innerHTML = '<div class="card"><div class="empty"><i class="fa-solid fa-users"></i><p>No rooms yet — create one or join with a code</p></div></div>';
      return;
    }
    box.innerHTML = '<div class="card">' + codes.map(code => {
      const r = d[code];
      const rows = buildRows(r);
      const myRank = rows.findIndex(m => m.id === 'me') + 1;
      const avs = rows.slice(0, 4).map(m =>
        '<span style="background:' + safeColor(m.hue, '#F6B93B') + '">' + escapeHTML(m.name.charAt(0).toUpperCase()) + '</span>').join('');
      return '<div class="room-row" data-open="' + escapeHTML(code) + '">' +
        '<div><div class="rname">' + escapeHTML(r.name) + '</div>' +
          '<div class="rmeta">' + r.members.length + ' members · created ' + fmtAgo(r.createdAt) + '</div></div>' +
        '<span class="avatars">' + avs + '</span>' +
        '<span class="rrank"><b class="mono">#' + (myRank || '—') + '</b><span>your rank</span></span>' +
        '<i class="go fa-solid fa-chevron-right"></i>' +
      '</div>';
    }).join('') + '</div>';
  }

  /* ---------- simulation tick ---------- */

  function startTick(){ stopTick(); tickT = setInterval(roomTick, 5000); roomTick(); }
  function stopTick(){ if(tickT){ clearInterval(tickT); tickT = null; } }

  function roomTick(){
    if(!current || State.view !== 'rooms') return;
    const d = db();
    const room = d[current];
    if(!room){ stopTick(); return; }
    let changed = false;
    room.members.forEach(m => {
      if(!m.bot) return;
      if(m.studying){
        const inc = 3 + Math.floor(Math.random() * 6);
        m.todaySec += inc; m.weekSec += inc;
      }
      if(Math.random() < 0.05){
        m.studying = !m.studying;
        if(m.studying) m.subject = SUBJECTS[Math.floor(Math.random() * SUBJECTS.length)];
        pushFeed(m.studying ? m.name + ' started studying ' + m.subject : m.name + ' took a break');
        changed = true;
      }else if(m.studying && Math.random() < 0.03){
        pushFeed(m.name + ' completed a pomodoro');
        changed = true;
      }
    });
    if(Math.random() < 0.05){
      const bots = room.members.filter(m => m.bot);
      const m = bots[Math.floor(Math.random() * bots.length)];
      pushFeed(m.name + ' is on ' + fmtDur(m.todaySec) + ' today');
      changed = true;
    }
    if(Math.random() < 0.09){
      const bots = room.members.filter(m => m.bot);
      const m = bots[Math.floor(Math.random() * bots.length)];
      room.chat = room.chat || [];
      room.chat.push({ me:false, name:m.name, hue:m.hue, text: CHAT_LINES[Math.floor(Math.random() * CHAT_LINES.length)], ts: Date.now() });
      if(room.chat.length > 80) room.chat = room.chat.slice(-80);
      changed = true;
    }
    Store.set('rooms', d);
    renderBoard();
    if(changed){ renderFeed(); renderChat(); }
  }

  function onTick(){
    if(!current || State.view !== 'rooms') return;
    const now = Date.now();
    if(now - boardTimer < 4000) return;
    boardTimer = now;
    renderBoard();
  }

  function onMySessionStarted(subject, mode){
    if(!current) return;
    pushFeed('You started ' + (mode === 'pomodoro' ? 'a pomodoro' : 'studying') + ' — ' + subject, true);
    if(State.view === 'rooms'){ renderBoard(); renderFeed(); }
  }
  function onMySessionSaved(sec, subject){
    if(!current) return;
    pushFeed('You logged ' + fmtDur(sec) + ' of ' + subject, true);
    if(State.view === 'rooms'){ renderBoard(); renderFeed(); }
  }

  /* ---------- invite link ---------- */

  function copyInvite(){
    if(!current) return;
    const url = location.href.split('#')[0] + '#/join/' + current;
    copyText(url).then(ok => {
      toast(ok ? 'Invite link copied — send it to your friends'
               : 'Copy blocked — share this code manually: ' + current,
            ok ? 'success' : 'warn');
    });
  }
  function copyText(text){
    if(navigator.clipboard && window.isSecureContext){
      return navigator.clipboard.writeText(text).then(() => true).catch(() => legacyCopy(text));
    }
    return Promise.resolve(legacyCopy(text));
  }
  function legacyCopy(text){
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.cssText = 'position:fixed;opacity:0;top:0;left:0';
    document.body.append(ta);
    ta.focus(); ta.select();
    let ok = false;
    try{ ok = document.execCommand('copy'); }catch(e){}
    ta.remove();
    return ok;
  }

  /* ---------- join modal ---------- */

  function showJoinModal(code){
    const m = $('#join-modal');
    if(!m) return;
    const d = db();
    $('#join-code').textContent = code;
    $('#join-title').textContent = d[code] ? 'Rejoin "' + d[code].name + '"?' : 'Join room ' + code + '?';
    m.style.display = 'flex';
    const confirm = $('#join-confirm'), cancel = $('#join-cancel');
    const close = () => { m.style.display = 'none'; confirm.onclick = cancel.onclick = m.onclick = null; };
    confirm.onclick = () => { close(); join(code); };
    cancel.onclick = close;
    m.onclick = e => { if(e.target === m) close(); };
  }

  /* ---------- bindings ---------- */

  function bind(){
    const cf = $('#create-room-form');
    if(cf) cf.addEventListener('submit', e => {
      e.preventDefault();
      const name = $('#room-name').value.trim() || 'Study Room';
      $('#room-name').value = '';
      create(name);
    });
    const jf = $('#join-room-form');
    if(jf) jf.addEventListener('submit', e => {
      e.preventDefault();
      const code = $('#room-code').value.trim();
      if(code) join(code);
      $('#room-code').value = '';
    });
    const back = $('#room-back');
    if(back) back.addEventListener('click', () => {
      current = null; stopTick();
      location.hash = '#/rooms';
      showList();
    });
    const ci = $('#copy-invite');  if(ci) ci.addEventListener('click', copyInvite);
    const lr = $('#leave-room');   if(lr) lr.addEventListener('click', leave);

    /* member rows open profiles */
    const board = $('#board-body');
    if(board) board.addEventListener('click', e => {
      const row = e.target.closest('[data-member]');
      if(!row) return;
      const room = db()[current];
      if(!room) return;
      const m = room.members.find(x => x.id === row.dataset.member);
      if(!m) return;
      if(window.Profile) (m.id === 'me') ? Profile.show() : Profile.showMember(m);
    });

    $$('#range-seg .chip').forEach(c => c.addEventListener('click', () => {
      range = c.dataset.range;
      $$('#range-seg .chip').forEach(x => x.classList.toggle('active', x === c));
      renderBoard();
    }));
    $$('#rtab-seg .chip').forEach(c => c.addEventListener('click', () => setTab(c.dataset.rtab)));

    const chatForm = $('#chat-form');
    if(chatForm) chatForm.addEventListener('submit', e => {
      e.preventDefault();
      const input = $('#chat-input');
      const text = input.value.trim();
      if(!text) return;
      const u = State.user || { name:'You', hue:'#E8A33D' };
      addMsg({ me:true, name:u.name, hue:u.hue }, text);
      Sound.sfx('pop');
      input.value = '';
      if(Math.random() < 0.85){
        setTimeout(() => {
          if(!current || !db()[current]) return;
          const bots = db()[current].members.filter(m => m.bot);
          if(!bots.length) return;
          const m = bots[Math.floor(Math.random() * bots.length)];
          addMsg({ me:false, name:m.name, hue:m.hue }, REPLIES[Math.floor(Math.random() * REPLIES.length)]);
        }, 1500 + Math.random() * 3500);
      }
    });

    const box = $('#rooms-list');
    if(box) box.addEventListener('click', e => {
      const row = e.target.closest('[data-open]');
      if(row) open(row.dataset.open);
    });
  }

  return {
    bind, create, join, open, showList, renderRoom, showJoinModal,
    onMySessionStarted, onMySessionSaved, onTick,
    setActive(on){ if(on){ if(current) startTick(); } else stopTick(); },
    onShow(){ (location.hash.indexOf('#/rooms/') === 0 && current) ? renderRoom() : showList(); },
    count: () => Object.keys(db()).length
  };
})();
window.Rooms = Rooms;