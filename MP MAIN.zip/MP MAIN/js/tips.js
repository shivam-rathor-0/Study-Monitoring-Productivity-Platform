/* tips.js — rule-based "AI" tips from the last 14 days of sessions, guard reasons
   and logged distractions. No network. Hidden if fewer than 5 sessions.
   Load AFTER dashboard.js and BEFORE app.js. */
'use strict';

const Tips = (function(){

  const DAYS = 14, MIN_SESSIONS = 5, MAX_TIPS = 3;

  /* ---------- data ---------- */
  function recentSessions(){
    const keys = new Set();
    for(let i = 0; i < DAYS; i++){ const d = new Date(); d.setDate(d.getDate() - i); keys.add(dateKey(d)); }
    return Store.get('sessions', []).filter(s => keys.has(s.date) && s.seconds > 0);
  }

  function recentDistractions(){
    const since = Date.now() - DAYS * 86400000;
    return Store.get('distractions', []).filter(d => d && d.at >= since);
  }

  function startHour(s){
    const t = s.endedAt ? s.endedAt - s.seconds * 1000 : null;
    return t ? new Date(t).getHours() : null;
  }

  const avg = arr => arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : 0;

  const BUCKETS = [
    { id: 'morning',   label: 'morning',    from: 5,  to: 12 },
    { id: 'afternoon', label: 'afternoon',  from: 12, to: 17 },
    { id: 'evening',   label: 'evening',    from: 17, to: 22 },
    { id: 'night',     label: 'late night', from: 22, to: 29 }
  ];
  function bucketOf(h){
    if(h == null) return null;
    const x = h < 5 ? h + 24 : h;
    return BUCKETS.find(b => x >= b.from && x < b.to) || null;
  }

  /* ---------- rules ---------- */

  function ruleTimeOfDay(ss){
    const groups = {};
    ss.filter(s => s.focusPct != null).forEach(s => {
      const b = bucketOf(startHour(s));
      if(b) (groups[b.id] = groups[b.id] || { b, v: [] }).v.push(s.focusPct);
    });
    const list = Object.values(groups).filter(g => g.v.length >= 2);
    if(list.length < 2) return null;
    list.sort((a, b) => avg(b.v) - avg(a.v));
    const best = list[0], worst = list[list.length - 1];
    const gap = Math.round(avg(best.v) - avg(worst.v));
    if(gap < 15) return null;
    return {
      icon: 'fa-clock', score: 50 + gap,
      title: 'Your ' + best.b.label + ' sessions are your strongest',
      text: 'Move your hardest subject to the ' + best.b.label + ' and keep ' + worst.b.label + ' for lighter revision.',
      why: 'Avg focus is ' + Math.round(avg(best.v)) + '% in the ' + best.b.label + ' vs ' +
           Math.round(avg(worst.v)) + '% in the ' + worst.b.label + '.'
    };
  }

  function ruleLongSessions(ss){
    const g = ss.filter(s => s.focusPct != null);
    const long = g.filter(s => s.seconds > 45 * 60 && s.mode !== 'pomodoro').map(s => s.focusPct);
    const short = g.filter(s => s.seconds <= 45 * 60).map(s => s.focusPct);
    if(long.length < 2 || short.length < 2) return null;
    const gap = Math.round(avg(short) - avg(long));
    if(gap < 10) return null;
    return {
      icon: 'fa-hourglass-half', score: 45 + gap,
      title: 'Focus drops in long sessions',
      text: 'Try 25/5 Pomodoro, or take a 5-minute break around the 45-minute mark.',
      why: 'Sessions over 45 min average ' + Math.round(avg(long)) + '% focus vs ' + Math.round(avg(short)) + '% for shorter ones.'
    };
  }

  function ruleDrowsy(ss){
    let drowsy = 0, total = 0;
    const byBucket = {};
    ss.forEach(s => {
      if(!s.reasons) return;
      const d = s.reasons['eyes closed'] || 0;
      const t = Object.values(s.reasons).reduce((a, b) => a + b, 0);
      drowsy += d; total += t;
      const b = bucketOf(startHour(s));
      if(b && d) byBucket[b.label] = (byBucket[b.label] || 0) + d;
    });
    if(total < 4 || drowsy / total < 0.5) return null;
    const top = Object.entries(byBucket).sort((a, b) => b[1] - a[1])[0];
    return {
      icon: 'fa-bed', score: 55 + Math.round(drowsy / total * 20),
      title: 'Drowsiness is your main focus breaker',
      text: 'Drink water, stand up for a minute, or study in brighter light' +
            (top ? '. It happens most in the ' + top[0] : '') + '.',
      why: Math.round(drowsy / total * 100) + '% of your AI Guard alerts were "eyes closed".'
    };
  }

  function ruleTopDistraction(){
    const ds = recentDistractions();
    if(ds.length < 3) return null;
    const map = {};
    ds.forEach(d => { map[d.cat] = (map[d.cat] || 0) + 1; });
    const [cat, n] = Object.entries(map).sort((a, b) => b[1] - a[1])[0];
    if(n < 3) return null;
    const c = String(cat).toLowerCase();
    let fix = 'Note it down and deal with it after the session.';
    if(/phone|social|insta|whatsapp|youtube/.test(c)) fix = 'Put your phone in another room or turn on Do Not Disturb before starting.';
    else if(/noise|sound/.test(c)) fix = 'Try the Rain or Lofi ambient sounds, or use earphones.';
    else if(/day ?dream|mind|wander|thought/.test(c)) fix = 'Write a quick "parking lot" note for stray thoughts, then go back to work.';
    return {
      icon: 'fa-bullseye', score: 40 + n * 4,
      title: '"' + cat + '" interrupts you most',
      text: fix,
      why: 'You logged it ' + n + ' times in the last ' + DAYS + ' days.'
    };
  }

  function ruleConsistency(ss){
    const days = new Set(ss.map(s => s.date)).size;
    if(days >= 8) return null;
    return {
      icon: 'fa-calendar-check', score: 30 + (8 - days) * 3,
      title: 'Study a little every day',
      text: 'Pick a fixed daily time, even 20 minutes, to build a streak. Short and regular beats long and rare.',
      why: 'You studied on ' + days + ' of the last ' + DAYS + ' days.'
    };
  }

  function ruleSubjectBalance(ss){
    const map = {};
    let total = 0;
    ss.forEach(s => { map[s.subject] = (map[s.subject] || 0) + s.seconds; total += s.seconds; });
    const rows = Object.entries(map).sort((a, b) => b[1] - a[1]);
    if(rows.length < 2 || total < 3600) return null;
    const pct = Math.round(rows[0][1] / total * 100);
    if(pct < 70) return null;
    return {
      icon: 'fa-scale-balanced', score: 25 + (pct - 70),
      title: 'One subject is taking most of your time',
      text: 'Give your other subjects at least one short session this week so nothing slips.',
      why: rows[0][0] + ' is ' + pct + '% of your last ' + DAYS + ' days.'
    };
  }

  /* ---------- engine ---------- */
  function compute(){
    const ss = recentSessions();
    if(ss.length < MIN_SESSIONS) return [];
    return [ruleTimeOfDay, ruleLongSessions, ruleDrowsy, ruleTopDistraction, ruleConsistency, ruleSubjectBalance]
      .map(r => { try{ return r(ss); }catch(e){ return null; } })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score)
      .slice(0, MAX_TIPS);
  }

  /* ---------- UI ---------- */
  function ensureCard(){
    let card = $('#tips-card');
    if(card) return card;
    const home = $('#view-home');
    if(!home) return null;

    if(!$('#tips-style')){
      const st = document.createElement('style');
      st.id = 'tips-style';
      st.textContent =
        '#tips-card{margin:0 0 16px;padding:16px 18px;border-radius:16px;' +
          'background:var(--glass,var(--surface,rgba(255,255,255,.04)));border:1px solid var(--glass-border,var(--border,rgba(255,255,255,.08)));' +
          'backdrop-filter:var(--glass-blur);-webkit-backdrop-filter:var(--glass-blur)}' +
        '#tips-card .tips-head{display:flex;align-items:center;gap:8px;font-weight:600;margin-bottom:10px}' +
        '#tips-card .tips-head i{color:var(--accent)}' +
        '.tip-item{display:flex;gap:12px;padding:10px 0;border-top:1px solid var(--border,rgba(255,255,255,.06))}' +
        '.tip-item:first-of-type{border-top:0}' +
        '.tip-ico{flex:0 0 34px;height:34px;border-radius:10px;display:grid;place-items:center;' +
          'background:color-mix(in srgb,var(--accent) 16%,transparent);color:var(--accent)}' +
        '.tip-body b{display:block;font-size:.95rem}' +
        '.tip-body p{margin:2px 0 0;font-size:.88rem;opacity:.85}' +
        '.tip-why{display:block;margin-top:4px;font-size:.78rem;opacity:.6}';
      document.head.appendChild(st);
    }

    card = el('section', { id: 'tips-card', 'aria-live': 'polite' });
    const anchor = home.firstElementChild;
    anchor ? anchor.after(card) : home.append(card);
    return card;
  }

  function render(){
    if(State.view !== 'home') return;
    const card = ensureCard();
    if(!card) return;
    const tips = compute();
    if(!tips.length){ card.style.display = 'none'; card.innerHTML = ''; return; }

    card.style.display = '';
    card.innerHTML =
      '<div class="tips-head"><i class="fa-solid fa-lightbulb"></i>Tips for you</div>' +
      tips.map(t =>
        '<div class="tip-item">' +
          '<span class="tip-ico"><i class="fa-solid ' + escapeHTML(t.icon) + '"></i></span>' +
          '<div class="tip-body">' +
            '<b>' + escapeHTML(t.title) + '</b>' +
            '<p>' + escapeHTML(t.text) + '</p>' +
            '<span class="tip-why">Why you\'re seeing this: ' + escapeHTML(t.why) + '</span>' +
          '</div>' +
        '</div>').join('');
  }

  /* re-render whenever the dashboard refreshes (no edit to dashboard.js needed) */
  if(window.Dashboard && typeof Dashboard.refresh === 'function'){
    const orig = Dashboard.refresh;
    Dashboard.refresh = function(){
      orig.apply(this, arguments);
      try{ render(); }catch(e){}
    };
  }

  return { render, compute };
})();
window.Tips = Tips;