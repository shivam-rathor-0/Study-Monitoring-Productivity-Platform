/* guard.js — AI Focus Guard v2.
   One clear signal: green when you are present and facing the screen,
   red when you look away, close your eyes, leave the desk or pick up a phone.

   Design notes:
   • Head-down reading is still focus. We deliberately do not use pitch.
   • FaceMesh runs at roughly 4 fps on a 480×360 camera stream.
   • Pose was removed in v2. It was a third model and added lag for little value.
   • Phone detection is optional and runs rarely (about once every 6 seconds)
     on a small 320×240 frame. If the model is unavailable the face signal
     keeps working.
   • Nothing is drawn on top of the video. The UI is CSS, which keeps the
     camera preview smooth. Video frames never leave the device. */
'use strict';

const Guard = (function(){

  const FACE_URL = 'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/face_mesh.js';
  const TF_URL   = 'https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.22.0/dist/tf.min.js';
  const COCO_URL = 'https://cdn.jsdelivr.net/npm/@tensorflow-models/coco-ssd@2.2.3/dist/coco-ssd.min.js';

  const FACE_OVAL = [10,338,297,332,284,251,389,356,454,323,361,288,397,365,379,378,400,377,152,148,176,149,150,136,172,58,132,93,234,127,162,21,54,103,67,109];

  const SENS = {
    relaxed:  { ear:.14, ylo:.24, yhi:.76, stable:900, drowsy:1700, noface:2400, phoneHold:7000 },
    balanced: { ear:.17, ylo:.30, yhi:.70, stable:600, drowsy:1100, noface:1600, phoneHold:8000 },
    strict:   { ear:.20, ylo:.34, yhi:.66, stable:420, drowsy:800,  noface:1100, phoneHold:9000 }
  };
  const sens = () => SENS[Store.get('settings', {}).guardSens] || SENS.balanced;

  const PHONE_SCORE = .55;
  const PW = 320, PH = 240;

  let running = false, paused = false;
  let video = null, stream = null, mesh = null, tickTimer = null, inflight = false;
  let state = 'init', reason = '', cand = null, candAt = 0, candHold = 0;
  let hist = [], lastFaceAt = 0, reasonLog = {}, lastEmit = '';
  let onChange = null, onFail = null;
  let faceBox = null;

  let phoneEnabled = false, phoneModel = null, phoneLoading = false, phoneDead = false;
  let phoneTimer = null, gotResults = false;
  let phoneCanvas = null, phoneCtx = null, phoneEvery = 6000, nextPhone = 0, phoneUntil = 0;
  let phoneToastShown = false;

  const dist = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  const nowMs = () => performance.now();

  /* ---------- script loader ---------- */
  const loaded = {};
  function loadScript(url){
    if(loaded[url]) return loaded[url];
    loaded[url] = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = url; s.async = true; s.crossOrigin = 'anonymous';
      s.onload = () => resolve();
      s.onerror = () => { delete loaded[url]; reject(new Error('load failed: ' + url)); };
      document.head.appendChild(s);
    });
    return loaded[url];
  }

  /* ---------- status ---------- */
  function textFor(st, why){
    if(st === 'paused') return 'Guard paused';
    if(st === 'focused') return 'Focused';
    if(st === 'away') return 'Away from desk';
    if(why === 'phone') return 'Phone detected';
    if(why === 'drowsy') return 'Eyes closed';
    if(why === 'looking') return 'Looking away';
    if(st === 'distracted') return 'Distracted';
    if(why === 'unavailable') return 'Guard unavailable';
    if(why === 'watching') return 'Watching again';
    return 'Starting camera…';
  }
  function setStatus(st, why){
    const label = textFor(st, why);
    const cls = st === 'focused' ? 'focused'
      : st === 'paused' ? 'paused'
      : st === 'init' ? 'init'
      : st === 'away' ? 'away'
      : 'distracted';
    const chip = $('#cam-status'), ct = $('#cam-status-text');
    if(chip) chip.className = 'cam-status st-' + cls;
    if(ct) ct.textContent = label;
    const sig = $('#guard-signal');
    if(sig) sig.dataset.state = st === 'focused' ? 'focused' : (st === 'init' || st === 'paused') ? 'init' : 'distracted';
    const panel = $('#guard-panel');
    if(panel) panel.dataset.state = st === 'focused' ? 'focused' : (st === 'init' || st === 'paused') ? 'init' : 'distracted';
    const gl = $('#guard-label');
    if(gl) gl.textContent = label;
    const zg = $('#zen-guard');
    if(zg){
      zg.dataset.state = cls;
      const zt = $('#zen-guard-text');
      if(zt) zt.textContent = label;
    }
  }
  function setLoading(on){
    const box = $('#cam-loading');
    if(box) box.hidden = !on;
  }
  function showError(msg){
    const box = $('#cam-error');
    if(box) box.style.display = 'flex';
    const t = $('#cam-error-text');
    if(t) t.textContent = msg;
  }
  function hideError(){
    const box = $('#cam-error');
    if(box) box.style.display = 'none';
  }

  /* ---------- start / stop ---------- */
  function start(cb, fail){
    onChange = cb; onFail = fail;
    running = true; paused = false;
    state = 'init'; reason = ''; cand = null; candAt = 0; candHold = 0;
    hist = []; reasonLog = {}; lastEmit = ''; faceBox = null; gotResults = false;
    lastFaceAt = nowMs(); phoneUntil = 0; nextPhone = 0;
    const c = Store.get('settings', {});
    phoneEnabled = c.guardPhone !== false;

    video = $('#cam-video');
    if(!video) return failOut('Camera preview is missing. Continuing without AI Guard.');
    setLoading(true);
    hideError();
    setStatus('init', 'Starting camera…');

    if(!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia){
      return failOut('Camera API unavailable in this browser. Continuing without AI Guard.');
    }

    navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 480 }, height: { ideal: 360 }, facingMode: 'user' },
      audio: false
    }).then(s => {
      if(!running){ s.getTracks().forEach(t => t.stop()); return; }
      stream = s;
      video.srcObject = s;
      video.play().catch(() => {});
      initMesh();
      if(phoneEnabled){
        phoneTimer = setTimeout(() => { if(running && phoneEnabled) initPhone(); }, 6000);
      }
      if(!tickTimer) loop();
    }).catch(() => {
      failOut('Camera access was denied. Continuing without AI Guard.');
    });
  }

  function stop(){
    running = false; paused = false;
    stopHardware();
  }

  function stopHardware(){
    if(tickTimer){ clearTimeout(tickTimer); tickTimer = null; }
    if(phoneTimer){ clearTimeout(phoneTimer); phoneTimer = null; }
    gotResults = false;
    inflight = false;
    if(stream){ stream.getTracks().forEach(t => t.stop()); stream = null; }
    if(video) video.srcObject = null;
    setLoading(false);
  }

  function failOut(msg){
    running = false;
    stopHardware();
    showError(msg);
    setStatus('init', 'Guard unavailable');
    if(onFail) onFail(msg);
  }

  /* ---------- models ---------- */
  function initMesh(){
    const ready = typeof FaceMesh !== 'undefined' ? Promise.resolve() : loadScript(FACE_URL);
    ready.then(() => {
      let tries = 0;
      (function wait(){
        if(!running) return;
        if(typeof FaceMesh === 'undefined'){
          if(++tries > 40) return failOut('Focus model could not load. Continuing without AI Guard.');
          return setTimeout(wait, 150);
        }
        try{
          if(!mesh){
            mesh = new FaceMesh({ locateFile: f => 'https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/' + f });
            mesh.setOptions({ maxNumFaces: 1, refineLandmarks: false, minDetectionConfidence: .5, minTrackingConfidence: .5 });
            mesh.onResults(onResults);
            setTimeout(() => {
              if(running && !gotResults) failOut('Focus model did not respond. Continuing without AI Guard.');
            }, 14000);
          }
        }catch(e){
          failOut('Focus model could not start. Continuing without AI Guard.');
        }
      })();
    }).catch(() => {
      failOut('Focus model could not load. Check your connection or continue without AI Guard.');
    });
  }

  function initPhone(){
    if(!phoneEnabled || phoneModel || phoneLoading || phoneDead) return;
    phoneLoading = true;
    loadScript(TF_URL)
      .then(() => loadScript(COCO_URL))
      .then(() => {
        if(typeof cocoSsd === 'undefined') throw new Error('cocoSsd missing');
        return cocoSsd.load({ base: 'lite_mobilenet_v2' });
      })
      .then(m => {
        phoneModel = m;
        phoneLoading = false;
        nextPhone = nowMs() + 1200;
      })
      .catch(() => {
        phoneLoading = false;
        phoneDead = true;
        if(running && !phoneToastShown){
          phoneToastShown = true;
          toast('Phone check unavailable — face focus still works', 'warn');
        }
      });
  }

  /* ---------- scheduler: one inference at a time ---------- */
  function loop(){
    if(!running) return;
    tickTimer = setTimeout(loop, 260);
    if(paused || document.hidden) return;
    if(inflight || !video || video.readyState < 2) return;
    const now = nowMs();
    if(phoneEnabled && phoneModel && now >= nextPhone){ runPhone(); return; }
    if(mesh) runFace();
  }

  function runFace(){
    if(!mesh) return;
    inflight = true;
    try{
      mesh.send({ image: video })
        .then(() => { inflight = false; })
        .catch(() => { inflight = false; });
    }catch(e){ inflight = false; }
  }

  function runPhone(){
    if(!phoneModel || !video || video.readyState < 2) return;
    if(!phoneCanvas){
      phoneCanvas = document.createElement('canvas');
      phoneCanvas.width = PW; phoneCanvas.height = PH;
      phoneCtx = phoneCanvas.getContext('2d', { alpha: false });
    }
    inflight = true;
    try{ phoneCtx.drawImage(video, 0, 0, PW, PH); }catch(e){ inflight = false; nextPhone = nowMs() + 12000; return; }
    const t0 = nowMs();
    phoneModel.detect(phoneCanvas, 5, .4)
      .then(preds => {
        inflight = false;
        const took = nowMs() - t0;
        if(took > 450) phoneEvery = Math.min(15000, Math.round(phoneEvery * 2));
        else if(took < 180 && phoneEvery > 5000) phoneEvery = Math.max(5000, phoneEvery - 500);
        nextPhone = nowMs() + phoneEvery;
        onPhone(preds || []);
      })
      .catch(() => {
        inflight = false;
        nextPhone = nowMs() + 12000;
      });
  }

  function onPhone(preds){
    const s = sens();
    for(const p of preds){
      if(p.class !== 'cell phone' || p.score < PHONE_SCORE) continue;
      const [bx, by, bw, bh] = p.bbox;
      const cx = (bx + bw / 2) / PW;
      const cy = (by + bh / 2) / PH;
      if(cy > .8) continue; /* phones lying low on a desk are ignored */
      if(bw * bh > PW * PH * .45) continue;
      let nearFace = true;
      if(faceBox){
        const px = faceBox.w * .9, py = faceBox.h * .9;
        nearFace = cx >= faceBox.x - px && cx <= faceBox.x + faceBox.w + px &&
                   cy >= faceBox.y - py && cy <= faceBox.y + faceBox.h + py;
      }
      if(!nearFace) continue;
      phoneUntil = nowMs() + s.phoneHold;
      propose('distracted', 'phone', 200);
      return;
    }
  }

  /* ---------- face detection ---------- */
  function onResults(res){
    if(!running || paused) return;
    if(!gotResults){ gotResults = true; setLoading(false); }
    const faces = (res && res.multiFaceLandmarks) || [];
    const s = sens();

    if(!faces.length){
      faceBox = null;
      if(nowMs() - lastFaceAt > s.noface) propose('away', 'away', 280);
      return;
    }

    lastFaceAt = nowMs();
    const lm = faces[0];

    /* eye openness — both eyes averaged */
    const earL = dist(lm[159], lm[145]) / Math.max(1e-4, dist(lm[33], lm[133]));
    const earR = dist(lm[386], lm[374]) / Math.max(1e-4, dist(lm[362], lm[263]));
    const ear  = (earL + earR) / 2;
    /* horizontal head turn. Pitch is intentionally ignored: head-down reading is focus. */
    const yaw  = (lm[1].x - lm[234].x) / Math.max(1e-4, lm[454].x - lm[234].x);

    let x0 = 1, y0 = 1, x1 = 0, y1 = 0;
    FACE_OVAL.forEach(i => {
      x0 = Math.min(x0, lm[i].x); x1 = Math.max(x1, lm[i].x);
      y0 = Math.min(y0, lm[i].y); y1 = Math.max(y1, lm[i].y);
    });
    faceBox = { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };

    let raw = 'focused', why = '', hold = s.stable;
    if(ear < s.ear){ raw = 'distracted'; why = 'drowsy'; hold = s.drowsy; }
    else if(yaw < s.ylo || yaw > s.yhi){ raw = 'distracted'; why = 'looking'; hold = s.stable + 200; }

    if(nowMs() < phoneUntil){ raw = 'distracted'; why = 'phone'; hold = 200; }

    propose(raw, why, hold);
  }

  function propose(raw, why, hold){
    hist.push(raw);
    if(hist.length > 8) hist.shift();
    const now = nowMs();
    if(cand !== raw){ cand = raw; candAt = now; candHold = hold; }
    else if(hold > candHold){ candHold = hold; }
    if(cand === state && why === reason) return;
    if(now - candAt < candHold) return;
    if(cand !== 'away' && hist.filter(h => h === cand).length < 3) return;
    commit(cand, why);
  }

  function commit(next, why){
    state = next;
    reason = why || '';
    const key = state + '|' + reason;
    if(key === lastEmit) return;
    lastEmit = key;
    if(next !== 'focused' && reason) reasonLog[reason] = (reasonLog[reason] || 0) + 1;
    setStatus(next, why);
    if(onChange) onChange(next, why);
  }

  /* ---------- pause while the session is paused ---------- */
  function setPaused(p){
    paused = !!p;
    if(!running) return;
    if(paused){
      setStatus('paused', 'paused');
    }else{
      lastFaceAt = nowMs();
      setStatus('init', 'watching');
    }
  }

  document.addEventListener('visibilitychange', () => {
    if(!document.hidden && running && !paused) lastFaceAt = nowMs();
  });

  return {
    start, stop, setPaused,
    attention: () => state,
    reason: () => reason,
    reasons: () => reasonLog,
    isRunning: () => running
  };
})();
window.Guard = Guard;
